@section('title', 'Admission – Bright Beginnings Montessori')
@section('description', 'Learn about the admission process, age criteria, and enrollment details for Bright Beginnings Montessori.')
@section('admission', 'active')
@include('front.layouts.header')

<div class="page-top"></div>

<!-- Custom Styles for Premium Admission Page -->
<style>
    /* Premium Montessori Admission Theme */
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Montserrat:wght@300;400;500;600&family=Great+Vibes&display=swap');

    .admission-page-wrapper {
        background-color: #F7F5F0; /* Cream Background */
        padding-top: 6rem;
        padding-bottom: 6rem;
        font-family: 'Montserrat', sans-serif;
    }

    /* Premium White Card Wrapper */
    .premium-card {
        background: #ffffff;
        border-radius: 8px; /* Elegant, slightly sharp corners */
        box-shadow: 0 10px 40px rgba(0,0,0,0.03);
        border: 1px solid rgba(168, 159, 145, 0.2); /* Soft taupe border */
        overflow: hidden;
    }

    /* Premium Hover Accordion Styles */
    .premium-accordion .accordion-item {
        border-radius: 8px !important;
        margin-bottom: 15px;
        transition: all 0.3s ease-in-out;
        box-shadow: 0 4px 10px rgba(0,0,0,0.02);
        overflow: hidden;
        border: 1px solid rgba(122, 139, 111, 0.2) !important; /* Sage tinted border */
        background-color: #ffffff !important;
    }

    .premium-accordion .accordion-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 25px rgba(122, 139, 111, 0.08);
        border-color: rgba(122, 139, 111, 0.4) !important;
    }

    /* Accordion Button Text Styling */
    .premium-accordion .accordion-button {
        font-family: 'Playfair Display', serif !important;
        font-weight: 500;
        font-size: 1.4rem;
        color: #3C4A3E !important; /* Charcoal */
        background: transparent !important;
        padding: 1.5rem 2rem;
        transition: all 0.3s ease-in-out;
        border-radius: 8px !important;
        box-shadow: none !important;
        letter-spacing: 0.5px;
    }

    .premium-accordion .accordion-button:hover {
        color: #7A8B6F !important; /* Sage Green hover */
    }

    .premium-accordion .accordion-button:not(.collapsed) {
        color: #7A8B6F !important; 
        border-bottom-left-radius: 0 !important;
        border-bottom-right-radius: 0 !important;
        background-color: rgba(122, 139, 111, 0.04) !important;
    }
    
    .premium-accordion .accordion-button::after {
        filter: none;
    }

    /* Content Area Styling */
    .premium-accordion .accordion-collapse {
        border-top: 1px solid rgba(122, 139, 111, 0.1);
        background-color: #ffffff;
    }
    .premium-accordion .accordion-body {
        background-color: #ffffff !important;
        padding: 2.5rem 2rem;
    }

    /* Content Typography */
    p {
        text-align: justify;
    }
    
    .premium-accordion .accordion-body p {
        color: #555555;
        line-height: 1.8;
        margin-bottom: 1rem;
        font-family: 'Montserrat', sans-serif;
        text-align: justify;
    }
    
    .premium-accordion .accordion-body strong {
        color: #3C4A3E;
        font-weight: 600;
    }

    .premium-accordion .accordion-body h5 {
        color: #3C4A3E;
        font-family: 'Playfair Display', serif;
        font-weight: 600;
        margin-top: 1.5rem;
        margin-bottom: 1rem;
    }

    /* Elegant Bullet Points */
    .premium-accordion .accordion-body ul li {
        color: #555555;
        margin-bottom: 0.85rem;
        position: relative;
        padding-left: 1.5rem;
        list-style-type: none;
        line-height: 1.7;
        text-align: justify;
    }
    .premium-accordion .accordion-body ul li::before {
        content: "•";
        color: #7A8B6F; /* Sage Green Bullet */
        font-size: 1.2rem;
        display: inline-block; 
        width: 1em;
        margin-left: -1em;
        position: absolute;
        left: 0;
        top: -2px;
    }
</style>

<section class="admission-page-wrapper">
    <div class="container">
        
        <!-- Header Title -->
        <div class="row mb-5">
            <div class="col-md-12 text-center" data-aos="fade-up">
                <span style="font-family: 'Great Vibes', cursive; font-size: 3rem; color: #A89F91; margin-bottom: -10px; display: block;">Join Our Family</span>
                <h1 class="mt-0 mb-3" style="font-family: 'Playfair Display', serif; font-size: 3.5rem; color: #3C4A3E; font-weight: 500;">Admission Procedures</h1>
                <div style="width: 80px; height: 1px; background-color: #7A8B6F; margin: 0 auto;" class="mt-4"></div>
            </div>
        </div>

        <div class="row g-md-5 mt-1">
            <div class="col-md-12 ">
                <div class="premium-card">
                    <div class="card-body p-4 p-md-5">
                         <div class="in-cnt-pd" data-aos="fade-up">
                 
                            <!-- JUSTIFIED PARAGRAPH -->
                            <p class="mb-5 mx-auto d-block" style="color: #555555; font-size: 1.1rem; max-width: 800px; line-height: 1.8; text-align: justify;">
                                Welcome to Bright Beginnings! We are thrilled that you are considering our Montessori program for your child's early education. Please review the simple steps below to join our vibrant learning community.
                            </p>
                    
                            <div class="accordion premium-accordion" id="accordionAdmission">
                              
                              <!-- Admission Process -->
                              <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    1. Admission Process
                                  </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionAdmission">
                                  <div class="accordion-body">
                                     <p>At <strong>Bright Beginnings</strong>, we ensure a smooth, transparent, and welcoming admission process for both you and your child. We accept applications year-round, subject to seat availability.</p>
                                     
                                     <ul class="m-0 p-0 mt-4">
                                         <li><strong>Step 1 – Enquiry & School Tour:</strong> Families are invited to visit our campus, explore our Montessori environment, and meet our team.</li>
                                         <li><strong>Step 2 – Child Observation / Meet & Greet:</strong> A short age-appropriate observation session helps us understand your child's readiness and needs.</li>
                                         <li><strong>Step 3 – Application Submission:</strong> Complete the admission form and submit the required documents.</li>
                                         <li><strong>Step 4 – Admission Confirmation:</strong> Once approved, parents will receive an admission offer along with fee details.</li>
                                         <li><strong>Step 5 – Orientation & First Day Preparation:</strong> Families receive onboarding information to ensure a smooth transition into our environment.</li>
                                     </ul>
                                  </div>
                                </div>
                              </div>
                              
                              <!-- Age Criteria & Programs -->
                              <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    2. Age Criteria & Programs
                                  </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionAdmission">
                                  <div class="accordion-body">
                                     
                                     <!-- Premium Program Layout -->
                                     <div class="row fw-bold pb-3 mb-4 mt-2" style="border-bottom: 1px solid rgba(168, 159, 145, 0.3); color: #A89F91; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px;">
                                         <div class="col-8">Program</div>
                                         <div class="col-4 text-end">Age</div>
                                     </div>
                                     
                                     <!-- Table Row -->
                                     <div class="row mb-4 align-items-center">
                                         <div class="col-8">
                                             <strong style="color: #3C4A3E; font-size: 1.3rem; font-family: 'Playfair Display', serif;">Montessori Early Childhood</strong>
                                         </div>
                                         <div class="col-4 text-end fw-bold" style="color: #7A8B6F; font-size: 1.1rem;">
                                             2.5 – 6 Years
                                         </div>
                                     </div>
                                     
                                     <!-- Description Paragraph -->
                                     <p class="mb-0 mt-4">
                                         Children are placed in a mixed-age Montessori environment where younger children learn through observation and older children develop leadership, responsibility, and confidence.
                                     </p>
                                     
                                  </div>
                                </div>
                              </div>
                              
                              <!-- Required Documents -->
                              <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                   3. Required Documents
                                  </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionAdmission">
                                  <div class="accordion-body">
                                    <ul class="m-0 p-0">
                                         <li>Completed Admission Form</li>
                                         <li>Child's Passport Copy</li>
                                         <li>Child's Iqama / Residency Copy</li>
                                         <li>Parent's Iqama and Passport Copy</li>
                                         <li>Two Passport-size Photographs</li>
                                         <li>Immunization / Vaccination Record</li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>

@include('front.layouts.footer')
