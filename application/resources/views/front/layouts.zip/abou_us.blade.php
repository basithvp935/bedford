@section('title', 'About Us | Bright Beginnings Montessori - Best KG in Dubai')
@section('description', 'Discover Bright Beginnings Montessori - Best Kindergarten in Dubai. Offering play-based early childhood education and a nurturing environment for toddlers. Enroll today.')
@include('front.layouts.header')

<style>
    /* Import Elegant Serif, Clean Sans-Serif, and Script Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Montserrat:wght@300;400;500;600&family=Great+Vibes&display=swap');

    body {
        font-family: 'Montserrat', sans-serif;
        color: #4A4A4A;
        background-color: #F7F5F0; /* Soft warm cream background */
    }
    
    p {
        text-align: justify;
    }

    h1, h2, h3, h4, h5, h6, .about-main-title {
        font-family: 'Playfair Display', serif;
        color: #3C4A3E; /* Dark Olive/Charcoal */
    }

    /* Banner Box Style for About Us Text - Montessori Theme */
    .about-banner-box {
        background: linear-gradient(135deg, rgba(247, 245, 240, 0.95) 0%, rgba(255, 255, 255, 0.9) 50%, rgba(232, 229, 220, 0.95) 100%);
        border-radius: 20px;
        padding: 4rem 5rem;
        border: 1px solid rgba(168, 159, 145, 0.2); /* Soft Taupe Border */
        box-shadow: 0 10px 30px rgba(0,0,0,0.03);
        transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
        position: relative;
        overflow: visible; /* Visible so beautiful icons can protrude */
    }
    
    @media (max-width: 768px) {
        .about-banner-box {
            padding: 2.5rem 1.5rem;
        }
    }
    
    .about-banner-box:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(122, 139, 111, 0.08);
        border-color: rgba(122, 139, 111, 0.25);
    }
    
    .about-banner-box::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background: radial-gradient(circle at center, rgba(255,255,255,0.7) 0%, transparent 100%);
        z-index: 0;
        border-radius: 20px;
    }
    
    .about-banner-content {
        position: relative;
        z-index: 1;
    }

    /* Hover effect for Mission/Vision boxes */
    .about-box {
        transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
        position: relative;
        z-index: 1;
    }
    .about-box:hover {
        transform: translateY(-6px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.06) !important;
    }

    /* Premium Sage Shade Image Effect */
    .image-sage-shade {
        position: relative;
        border-radius: 20px;
        overflow: hidden;
        border: 4px solid #ffffff;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        display: inline-block;
        width: 100%;
        cursor: pointer;
    }
    
    .image-sage-shade img {
        display: block;
        width: 100%;
        object-fit: cover;
        max-height: 450px;
        object-position: center;
        transition: transform 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
    }
    
    .image-sage-shade::after {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background-color: rgba(122, 139, 111, 0.2); /* Soft Sage Overlay */
        pointer-events: none;
        transition: all 0.4s ease;
    }
    
    /* Interactive Hover Effect */
    .image-sage-shade:hover img {
        transform: scale(1.03); /* Soft zoom in */
    }
    .image-sage-shade:hover::after {
        background-color: rgba(122, 139, 111, 0.05); /* Clears the shade on hover */
    }

    /* Aesthetic Floating Icons */
    .aesthetic-icon {
        position: absolute;
        z-index: 2;
        opacity: 0.9;
        pointer-events: none;
    }

    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
    }

    @media (max-width: 768px) {
        .about-main-title {
            font-size: 2.5rem !important;
        }
    }
</style>

<!-- Fixed Banner -->
<section class="position-relative d-flex align-items-center justify-content-center" style="
    background: url('{{ asset('Front/images/brightban.jpg') }}') center top / cover no-repeat; 
    width: 100vw; 
    margin-left: calc(-50vw + 50%); 
    max-width: 100vw; 
    height: 450px; 
    overflow: hidden;
    background-attachment:fixed;
">
    <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.35); z-index: 1;"></div>
    
    <div style="position: relative; z-index: 2; text-align: center; width: 100%; padding-bottom: 20px;">
        <h1 class="about-main-title" style="font-family: 'Playfair Display', serif; color: #ffffff; font-size: 4.5rem; font-weight: 500; margin: 0; text-shadow: 0px 4px 15px rgba(0,0,0,0.4);">
            Our Story
        </h1>
    </div>

    <!-- Wavy Bottom Shape Divider -->
    <div style="position: absolute; bottom: -2px; left: 0; width: 100%; overflow: hidden; line-height: 0; z-index: 3;">
        <svg viewBox="0 0 1440 100" preserveAspectRatio="none" style="display: block; width: 100%; height: 60px; fill: #F7F5F0;">
            <path d="M0,40 C320,100 820,0 1440,60 L1440,100 L0,100 Z" />
        </svg>
    </div>
</section>

<!-- About Us section with Montessori Elements -->
<section class="about section-100 home-about py-5 position-relative" style="background-color: #F7F5F0; overflow: hidden;">
    
    <!-- Beautiful Watercolor Cloud 1 -->
    <div class="aesthetic-icon" style="top: 2%; left: 5%; opacity: 0.85;">
        <svg width="150" height="80" viewBox="0 0 150 80" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="cloudG1" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0.9"/>
              <stop offset="100%" stop-color="#E8E5DC" stop-opacity="0.9"/>
            </linearGradient>
          </defs>
          <path d="M40,65 C20,65 10,50 20,35 C20,20 40,10 55,20 C70,5 95,5 110,25 C130,25 140,45 125,60 C135,70 120,75 105,65 C95,75 75,70 65,65 C55,75 45,70 40,65 Z" fill="url(#cloudG1)"/>
        </svg>
    </div>

    <!-- Beautiful Watercolor Cloud 2 -->
    <div class="aesthetic-icon" style="top: 15%; right: 3%; opacity: 0.7; transform: scale(0.8);">
        <svg width="150" height="80" viewBox="0 0 150 80" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="cloudG2" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0.9"/>
              <stop offset="100%" stop-color="#E8E5DC" stop-opacity="0.9"/>
            </linearGradient>
          </defs>
          <path d="M40,65 C20,65 10,50 20,35 C20,20 40,10 55,20 C70,5 95,5 110,25 C130,25 140,45 125,60 C135,70 120,75 105,65 C95,75 75,70 65,65 C55,75 45,70 40,65 Z" fill="url(#cloudG2)"/>
        </svg>
    </div>

    <div class="container position-relative" style="z-index: 1;">
        <div class="row g-md-5 mb-5 mt-lg-3 mt-1">
            <div class="col-md-12 position-relative">
                
                <!-- Montessori Wooden Rainbow Toy on top left of banner -->
                <div class="aesthetic-icon" style="top: -30px; left: 40px; opacity: 0.95; transform: scale(1.1); ">
                    <svg width="120" height="80" viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10,80 A50,50 0 0,1 110,80" fill="none" stroke="#D4C5B9" stroke-width="12" stroke-linecap="round"/>
                        <path d="M26,80 A34,34 0 0,1 94,80" fill="none" stroke="#A9B89D" stroke-width="12" stroke-linecap="round"/>
                        <path d="M42,80 A18,18 0 0,1 78,80" fill="none" stroke="#B5AFA1" stroke-width="12" stroke-linecap="round"/>
                        <path d="M58,80 A2,2 0 0,1 62,80" fill="none" stroke="#E8E5DC" stroke-width="12" stroke-linecap="round"/>
                    </svg>
                </div>

                <!-- Elegant Botanical Leaf drawing (Kept from earlier as requested!) -->
                <div class="aesthetic-icon" style="top: -40px; right: 10px; opacity: 0.95; transform: scale(1.1); ">
                    <svg width="180" height="350" viewBox="0 0 180 350" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M140,320 Q90,180 60,60" stroke="#7A8B6F" stroke-width="1.5" stroke-linecap="round" fill="none"/>
                        <path d="M105,230 C70,240 40,210 50,180 C70,160 100,190 105,230 Z" stroke="#7A8B6F" stroke-width="1.2" fill="#F7F5F0" opacity="0.9"/>
                        <path d="M105,230 Q80,200 50,180" stroke="#7A8B6F" stroke-width="1" fill="none"/>
                        <path d="M95,170 C135,165 145,115 125,90 C95,95 75,135 95,170 Z" stroke="#7A8B6F" stroke-width="1.2" fill="#F7F5F0" opacity="0.9"/>
                        <path d="M95,170 Q120,130 125,90" stroke="#7A8B6F" stroke-width="1" fill="none"/>
                        <path d="M65,100 C30,90 20,50 35,30 C60,40 75,70 65,100 Z" stroke="#7A8B6F" stroke-width="1.2" fill="#F7F5F0" opacity="0.9"/>
                        <path d="M65,100 Q45,65 35,30" stroke="#7A8B6F" stroke-width="1" fill="none"/>
                        <path d="M60,70 C90,55 95,20 75,5 C50,20 45,55 60,70 Z" stroke="#7A8B6F" stroke-width="1.2" fill="#F7F5F0" opacity="0.9"/>
                        <path d="M60,70 Q75,35 75,5" stroke="#7A8B6F" stroke-width="1" fill="none"/>
                    </svg>
                </div>

                <div class="about-banner-box w-100 mx-auto" data-aos="fade-up" data-aos-delay="100">
                    <div class="about-banner-content">
                        <!-- NEW LAYOUT: Banner Image Top, Text Below -->
                        <div class="row">
                            <div class="col-12 mb-5">
                                <div class="image-sage-shade w-100" style="border-radius: 15px;">
                                    <img src="{{ asset('Front/images/ab10.jpeg') }}" alt="Our Story" class="img-fluid w-100">
                                </div>
                            </div>

                            <div class="col-12 px-lg-4 text-start">
                                <span class="fw-bold tracking-wider text-uppercase" style="color: #A89F91; letter-spacing: 3px; font-family: 'Montserrat', sans-serif;">OUR STORY.</span>
                                
                                <h2 class="pb-2 mt-2" style="font-family: 'Great Vibes', cursive; color: #9B6AAB; font-size: 3.8rem; font-weight: 400; line-height: 1.2;">A Legacy Reimagined.</h2>
                                
                                <div style="width: 80px; height: 3px; background: linear-gradient(to right, #7A8B6F, #D4C5B9); margin: 0 0 1.5rem 0; border-radius: 2px;"></div>
                                
                                <div class="in-txt text-dark mt-4" style="font-size: 1.15rem; line-height: 1.8; color: #4A4A4A;">
                                    <p>In 1996, when Little Angels opened its doors in Golden Belt, Al Khobar, with a simple belief: every child deserves to be seen, respected, and inspired to love learning.</p>
                                    <p>For decades, Little Angels became a trusted part of the community, known for its warm environment, personal approach, and commitment to nurturing each child's unique potential.</p>
                                    <p>When our doors closed, our journey didn't end—it evolved.</p>
                                    <p>Driven by a passion for authentic Montessori education, we spent years studying, researching, and reimagining what an exceptional early learning environment could be. Inspired by the Montessori philosophy and our own experience as educators and parents, we created the school we had always envisioned.</p>
                                    <p>That vision became <strong style="font-family: 'Playfair Display', serif; font-size: 1.3rem; font-style: italic; color: #3C4A3E; font-weight: 600;">Bright Beginnings Montessori.</strong></p>
                                    <p>Today, we continue our legacy with a renewed purpose: to offer children an authentic Montessori experience in a thoughtfully prepared environment where independence, curiosity, confidence, and a lifelong love of learning can flourish.</p>
                                    <p>Though our name has changed, our commitment remains the same—to know every child, honour every unique journey, and help each one discover the remarkable potential within.</p>
                                    <p class="mb-0"><strong style="font-family: 'Playfair Display', serif; font-size: 1.25rem; color: #3C4A3E; font-weight: 600;">Because great beginnings create bright futures.</strong></p>
                                </div>
                                
                            </div>
                        </div>
                        
                        <div class="row mb-4 mt-5 pt-4">
                            <div class="col-md-10 mx-auto text-center" data-aos="fade-up">
                                <h3 style="color: #3C4A3E; font-size: 1.6rem; font-weight: 500; line-height: 1.5; font-family: 'Playfair Display', serif; font-style: italic; word-spacing: -2px;">What sets us apart isn't just philosophy — it's practice, people, and standards.</h3>
                            </div>
                        </div>
                        
                        <div class="row g-4 px-lg-3 pb-2 mt-2 position-relative">
                            
                            <!-- Montessori Watercolor Caterpillar crawling above boxes -->
                            <div class="aesthetic-icon" style="top: -50px; right: -20px; opacity: 0.9; ">
                                <svg width="150" height="100" viewBox="0 0 150 100" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(-10deg);">
                                  <defs>
                                    <radialGradient id="catG" cx="30%" cy="30%" r="70%">
                                      <stop offset="0%" stop-color="#B2C2A6"/>
                                      <stop offset="100%" stop-color="#7A8B6F"/>
                                    </radialGradient>
                                  </defs>
                                  <path d="M10,80 Q75,40 140,50" stroke="#B5AFA1" stroke-width="2.5" stroke-linecap="round" fill="none"/>
                                  <path d="M40,63 C30,75 25,75 40,63 Z" stroke="#B5AFA1" stroke-width="1.5" fill="#A9B89D"/>
                                  <path d="M100,45 C110,60 120,60 100,45 Z" stroke="#B5AFA1" stroke-width="1.5" fill="#A9B89D"/>
                                  <circle cx="45" cy="55" r="9" fill="url(#catG)"/>
                                  <circle cx="60" cy="50" r="10.5" fill="url(#catG)"/>
                                  <circle cx="76" cy="46" r="11.5" fill="url(#catG)"/>
                                  <circle cx="93" cy="44" r="11.5" fill="url(#catG)"/>
                                  <circle cx="110" cy="45" r="12.5" fill="url(#catG)"/>
                                  <path d="M115,35 Q125,20 130,25 M105,33 Q110,18 115,20" stroke="#4A4A4A" stroke-width="1.5" fill="none" stroke-linecap="round"/>
                                  <circle cx="130" cy="25" r="1.5" fill="#4A4A4A"/>
                                  <circle cx="115" cy="20" r="1.5" fill="#4A4A4A"/>
                                  <circle cx="115" cy="42" r="2" fill="#4A4A4A"/>
                                  <circle cx="45" cy="50" r="1.5" fill="#4A4A4A" opacity="0.6"/>
                                  <circle cx="60" cy="45" r="1.5" fill="#4A4A4A" opacity="0.6"/>
                                  <circle cx="76" cy="40" r="1.5" fill="#4A4A4A" opacity="0.6"/>
                                  <circle cx="93" cy="38" r="1.5" fill="#4A4A4A" opacity="0.6"/>
                                </svg>
                            </div>

                            <!-- Box 1 -->
                            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
                                <div class="about-box h-100 p-4 shadow-sm" style="background: rgba(122, 139, 111, 0.08); border: 1px solid rgba(122, 139, 111, 0.2); border-radius: 20px;">
                                    <i class="bi bi-patch-check mb-3 d-block" style="font-size: 2.2rem; color: #7A8B6F;"></i>
                                    <h5 class="fw-bold mb-3" style="color: #3C4A3E; font-size: 1.15rem; font-family: 'Playfair Display', serif;">AMS-aligned</h5>
                                    <p class="text-dark mb-0" style="opacity: 0.85; font-size: 14px; line-height: 1.7; font-family: 'Montserrat', sans-serif; text-align: justify; word-spacing: -1px; hyphens: auto;">We follow the American Montessori Society framework, one of the most rigorous standards in early education.</p>
                                </div>
                            </div>
                            
                            <!-- Box 2 -->
                            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
                                <div class="about-box h-100 p-4 shadow-sm" style="background: rgba(168, 159, 145, 0.08); border: 1px solid rgba(168, 159, 145, 0.2); border-radius: 20px;">
                                    <i class="bi bi-layers mb-3 d-block" style="font-size: 2.2rem; color: #A89F91;"></i>
                                    <h5 class="fw-bold mb-3" style="color: #3C4A3E; font-size: 1.15rem; font-family: 'Playfair Display', serif;">Bright Thread method</h5>
                                    <p class="text-dark mb-0" style="opacity: 0.85; font-size: 14px; line-height: 1.7; font-family: 'Montserrat', sans-serif; text-align: justify; word-spacing: -1px; hyphens: auto;">Our own signature pedagogy, developed over decades, that personalises the Montessori journey for each child.</p>
                                </div>
                            </div>
                            
                            <!-- Box 3 -->
                            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
                                <div class="about-box h-100 p-4 shadow-sm" style="background: rgba(212, 197, 185, 0.15); border: 1px solid rgba(212, 197, 185, 0.3); border-radius: 20px;">
                                    <i class="bi bi-house-heart mb-3 d-block" style="font-size: 2.2rem; color: #C1AD9D;"></i>
                                    <h5 class="fw-bold mb-3" style="color: #3C4A3E; font-size: 1.15rem; font-family: 'Playfair Display', serif;">Open environment</h5>
                                    <p class="text-dark mb-0" style="opacity: 0.85; font-size: 14px; line-height: 1.7; font-family: 'Montserrat', sans-serif; text-align: justify; word-spacing: -1px; hyphens: auto;">A thoughtfully prepared space where every material serves a purpose and every child feels free to explore.</p>
                                </div>
                            </div>
                            
                            <!-- Box 4 -->
                            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
                                <div class="about-box h-100 p-4 shadow-sm" style="background: rgba(232, 229, 220, 0.4); border: 1px solid rgba(232, 229, 220, 0.8); border-radius: 20px;">
                                    <i class="bi bi-mortarboard mb-3 d-block" style="font-size: 2.2rem; color: #B5AFA1;"></i>
                                    <h5 class="fw-bold mb-3" style="color: #3C4A3E; font-size: 1.15rem; font-family: 'Playfair Display', serif;">Qualified Guides</h5>
                                    <p class="text-dark mb-0" style="opacity: 0.85; font-size: 14px; line-height: 1.7; font-family: 'Montserrat', sans-serif; text-align: justify; word-spacing: -1px; hyphens: auto;">Every facilitator on our team is Montessori-trained and certified — not just familiar with the method, but formed by it.</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Updated Mission, Vision, and Philosophy Section -->
<section class="section-100 pb-5" style="background-color: #F7F5F0;">
    <div class="container">
        <div class="row g-5 position-relative">
            
            <!-- Realistic Fluttering Orange Butterfly near Mission -->
            <div class="aesthetic-icon" style="top: -30px; right: 5%; opacity: 0.95;  animation: float 5s ease-in-out infinite;">
                <svg class="colorful-butterfly" width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" style="overflow: visible; transform: rotate(-15deg) scale(0.8);">
                  <defs>
                    <linearGradient id="wingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stop-color="#FFB347" />
                      <stop offset="60%" stop-color="#FF7B00" />
                      <stop offset="100%" stop-color="#CC4400" />
                    </linearGradient>
                    <linearGradient id="wingGradLower" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stop-color="#FFD180" /> 
                      <stop offset="100%" stop-color="#FF8C00" />
                    </linearGradient>
                  </defs>
                  <!-- Left Wing -->
                  <g style="transform-origin: 50px 50px;">
                    <!-- Upper -->
                    <path d="M50 50 C 20 20, 5 25, 10 40 C 15 60, 40 60, 50 50" fill="url(#wingGrad)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                    <path d="M50 50 C 35 35, 20 35, 15 42" stroke="#222" stroke-width="1.5" fill="none"/>
                    <path d="M50 50 C 25 45, 15 50, 15 50" stroke="#222" stroke-width="1.5" fill="none"/>
                    <!-- Lower -->
                    <path d="M50 50 C 30 65, 20 85, 35 90 C 45 95, 50 70, 50 50" fill="url(#wingGradLower)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                    <path d="M50 50 C 40 70, 30 80, 28 85" stroke="#222" stroke-width="1.5" fill="none"/>
                    <!-- Edge Dots -->
                    <circle cx="12" cy="40" r="1.5" fill="#FFF"/>
                    <circle cx="17" cy="53" r="1.5" fill="#FFF"/>
                    <circle cx="30" cy="86" r="1.5" fill="#FFF"/>
                    <circle cx="40" cy="89" r="1.5" fill="#FFF"/>
                  </g>
                  <!-- Right Wing -->
                  <g style="transform-origin: 50px 50px;">
                    <!-- Upper -->
                    <path d="M50 50 C 80 20, 95 25, 90 40 C 85 60, 60 60, 50 50" fill="url(#wingGrad)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                    <path d="M50 50 C 65 35, 80 35, 85 42" stroke="#222" stroke-width="1.5" fill="none"/>
                    <path d="M50 50 C 75 45, 85 50, 85 50" stroke="#222" stroke-width="1.5" fill="none"/>
                    <!-- Lower -->
                    <path d="M50 50 C 70 65, 80 85, 65 90 C 55 95, 50 70, 50 50" fill="url(#wingGradLower)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                    <path d="M50 50 C 60 70, 70 80, 72 85" stroke="#222" stroke-width="1.5" fill="none"/>
                    <!-- Edge Dots -->
                    <circle cx="88" cy="40" r="1.5" fill="#FFF"/>
                    <circle cx="83" cy="53" r="1.5" fill="#FFF"/>
                    <circle cx="70" cy="86" r="1.5" fill="#FFF"/>
                    <circle cx="60" cy="89" r="1.5" fill="#FFF"/>
                  </g>
                  <!-- Body -->
                  <rect x="47" y="38" width="6" height="24" rx="3" fill="#333"/>
                  <circle cx="50" cy="35" r="4" fill="#333"/>
                  <!-- Antennae -->
                  <path d="M 48 33 Q 40 15, 36 20 M 52 33 Q 60 15, 64 20" stroke="#333" stroke-width="1.5" fill="none" stroke-linecap="round"/>
                </svg>
            </div>

            <!-- Mission Section (Sage Green) -->
            <div class="col-md-12">
                <div class="about-box shadow-sm" style="background: rgba(122, 139, 111, 0.1); border: 1px solid rgba(122, 139, 111, 0.2); border-radius: 20px; padding: 50px;">
                    <div class="row align-items-center">
                        <div class="col-md-5 text-center mb-4 mb-md-0" data-aos="fade-right">
                            <img src="{{ asset('Front/images/mi.jpeg') }}" alt="Mission" class="img-fluid rounded-circle shadow" style="width: 300px; height: 300px; object-fit: cover; border: 8px solid rgba(122, 139, 111, 0.3);">
                        </div>
                        <div class="col-md-7" data-aos="fade-left">
                            <div class="d-flex align-items-center mb-3">
                                <div class="icon-box me-3 d-flex align-items-center justify-content-center shadow-sm" style="background: #7A8B6F; color: #ffffff; width: 60px; height: 60px; border-radius: 50%;">
                                    <i class="bi bi-bullseye" style="font-size: 28px;"></i>
                                </div>
                                <h2 class="mb-0 fw-bold" style="color: #9B6AAB; font-family: 'Playfair Display', serif;">Our Mission</h2>
                            </div>
                            
                            <h4 class="mb-3" style="color: #3C4A3E; font-weight: 500; font-family: 'Playfair Display', serif; font-style: italic;">Nurturing Independent Minds and Joyful Learners. </h4>
                            
                            <p class="text-dark" style="font-size: 16px; line-height: 1.8; opacity: 0.85; color: #4A4A4A;">
                                We believe that children learn best when they are trusted, respected, and empowered to take an active role in their own development.
                            </p>
                            <p class="text-dark mb-0" style="font-size: 16px; line-height: 1.8; opacity: 0.85; color: #4A4A4A;">
                            We strive for resilience, responsibility, creativity, and compassion—laying the foundation for a lifetime of learning.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            


            <!-- Vision Section (Soft Taupe) -->
            <div class="col-md-12">
                <div class="about-box shadow-sm" style="background: rgba(168, 159, 145, 0.1); border: 1px solid rgba(168, 159, 145, 0.2); border-radius: 20px; padding: 50px;">
                    <div class="row align-items-center flex-column-reverse flex-md-row">
                        <div class="col-md-7" data-aos="fade-right">
                            <div class="d-flex align-items-center mb-3 position-relative">
                                <!-- Bunny positioned directly above the Our Vision heading -->
                                <div class="aesthetic-icon" style="top: -85px; left: 40px; opacity: 0.95;  transform: scale(0.65);">
                                    <svg width="110" height="110" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                                      <defs>
                                        <radialGradient id="bunnyG" cx="40%" cy="30%" r="70%">
                                          <stop offset="0%" stop-color="#F2EEE6"/>
                                          <stop offset="70%" stop-color="#DBCDBF"/>
                                          <stop offset="100%" stop-color="#BEB4A6"/>
                                        </radialGradient>
                                      </defs>
                                      <path d="M60,45 Q50,15 55,10 Q65,25 65,45" fill="#BEB4A6"/>
                                      <circle cx="20" cy="80" r="8" fill="#FFFFFF" opacity="0.9"/>
                                      <path d="M35,65 C25,65 20,85 35,95 C55,100 75,95 75,75 C75,55 55,50 35,65 Z" fill="url(#bunnyG)"/>
                                      <path d="M55,45 C75,40 85,55 80,70 C70,75 55,75 45,60 C40,50 45,45 55,45 Z" fill="url(#bunnyG)"/>
                                      <path d="M62,45 Q55,10 63,5 Q73,20 68,45" fill="url(#bunnyG)"/>
                                      <circle cx="72" cy="55" r="2" fill="#4A4A4A"/>
                                      <circle cx="83" cy="64" r="1.5" fill="#8B7E74"/>
                                      <path d="M60,80 Q60,95 65,95 Q70,95 70,85" stroke="#BEB4A6" stroke-width="4" stroke-linecap="round" fill="none"/>
                                    </svg>
                                </div>
                                <div class="icon-box me-3 d-flex align-items-center justify-content-center shadow-sm" style="background: #7A8B6F; color: #ffffff; width: 60px; height: 60px; border-radius: 50%;">
                                    <i class="bi bi-eye" style="font-size: 28px;"></i>
                                </div>
                                <h2 class="mb-0 fw-bold" style="color: #7A8B6F; font-family: 'Playfair Display', serif;">Our Vision</h2>
                            </div>
                            
                            <h4 class="mb-3" style="color: #3C4A3E; font-weight: 500; font-family: 'Playfair Display', serif; font-style: italic;">A Generation That Reaches First and Doubts Second</h4>
                            
                            <p class="text-dark mb-0" style="font-size: 16px; line-height: 1.8; opacity: 0.85; color: #4A4A4A;">
                                A world where children leave us with one unshakeable belief: I am capable. Not because someone told them ; because they lived it, every single day, in an environment built to expect it of them.
                            </p>
                        </div>
                        <div class="col-md-5 text-center mb-4 mb-md-0" data-aos="fade-left">
                            <img src="{{ asset('Front/images/vis.jpeg') }}" alt="Vision" class="img-fluid rounded-circle shadow" style="width: 300px; height: 300px; object-fit: cover; border: 8px solid rgba(168, 159, 145, 0.3);">
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Delicate Abstract Arch behind Philosophy -->
            <div class="aesthetic-icon" style="bottom: 0%; right: -5%; z-index: 0; opacity: 0.7;">
                <svg width="400" height="300" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
                    <path fill="#E8E5DC" d="M0,300 C0,150 150,0 400,0 L400,300 Z" />
                </svg>
            </div>

            <!-- Pastel 3D Stacking Blocks near Philosophy -->
            <div class="aesthetic-icon d-none d-md-block" style="bottom: -30px; right: 0; opacity: 0.95; ">
                <svg width="100" height="130" viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
                  <!-- Sage Green Block -->
                  <path d="M20,110 L50,125 L80,110 L80,80 L50,95 L20,80 Z" fill="#8F9E85"/>
                  <path d="M20,80 L50,95 L80,80 L50,65 Z" fill="#A9B89D"/>
                  <path d="M20,80 L50,95 L50,125 L20,110 Z" fill="#7A8B6F"/>
                  <!-- Blush/Taupe Block -->
                  <path d="M30,80 L50,90 L70,80 L70,55 L50,65 L30,55 Z" fill="#D4C5B9"/>
                  <path d="M30,55 L50,65 L70,55 L50,45 Z" fill="#E8DCD1"/>
                  <path d="M30,55 L50,65 L50,90 L30,80 Z" fill="#C1AD9D"/>
                  <!-- Beige Top Block -->
                  <path d="M35,55 L50,62 L65,55 L65,35 L50,42 L35,35 Z" fill="#E8E5DC"/>
                  <path d="M35,35 L50,42 L65,35 L50,28 Z" fill="#F7F5F0"/>
                  <path d="M35,35 L50,42 L50,62 L35,55 Z" fill="#D4C5B9"/>
                </svg>
            </div>

            <!-- Philosophy Section (Muted Blush/Terracotta) -->
            <div class="col-md-12">
                <div class="about-box shadow-sm" style="background: rgba(212, 197, 185, 0.15); border: 1px solid rgba(212, 197, 185, 0.3); border-radius: 20px; padding: 50px;">
                    <div class="row align-items-center">
                        <div class="col-md-5 text-center mb-4 mb-md-0" data-aos="fade-right">
                            <img src="{{ asset('Front/images/phis.jpeg') }}" alt="Philosophy" class="img-fluid rounded-circle shadow" style="width: 300px; height: 300px; object-fit: cover; border: 8px solid rgba(212, 197, 185, 0.4);">
                        </div>
                        <div class="col-md-7" data-aos="fade-left">
                            <div class="d-flex align-items-center mb-3">
                                <div class="icon-box me-3 d-flex align-items-center justify-content-center shadow-sm" style="background: #A89F91; color: #ffffff; width: 60px; height: 60px; border-radius: 50%;">
                                    <i class="bi bi-lightbulb" style="font-size: 28px;"></i>
                                </div>
                                <h2 class="mb-0 fw-bold" style="color: #A89F91; font-family: 'Playfair Display', serif;">Our Philosophy</h2>
                            </div>
                            
                            <h4 class="mb-3" style="color: #3C4A3E; font-weight: 500; font-family: 'Playfair Display', serif; font-style: italic;">Every Child Is the Only Child</h4>
                            
                            <p class="text-dark mb-0" style="font-size: 16px; line-height: 1.8; opacity: 0.85; color: #4A4A4A;">
                                We believe capability is not given ; it is uncovered. Every child arrives with a unique developmental thread; a set of sensitive periods, a natural pace, a particular way of making sense of the world. Our Guides are trained to find that thread, follow it, and never interrupt it.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="explore section-100 pb-0" style="background-color: #F7F5F0;">
    <div class="container">
        <div class="row d-md-flex align-items-center">
            <div class="col-md-12 text-center" data-aos="fade-left">
                <!-- Earthy tones applied here too -->
                <span class="sxt fw-bold text-uppercase tracking-wider" style="color: #A89F91; font-family: 'Montserrat', sans-serif; letter-spacing: 3px;">Explore</span>
                <h1 class="mt-0 mb-4 fw-600" style="color: #3C4A3E; font-family: 'Playfair Display', serif; letter-spacing: 2px; text-transform: uppercase;">Gallery</h1>
            </div>
            <div class="col-md-12 text-center">
                <div class="row g-1">
                    @foreach ($galleries as $gallery)
                    <div class="col-md-3" data-aos="fade-up" data-aos-delay="100">
                        <div class="hg-img efx mb-0" style="border-radius: 10px; overflow: hidden; border: 2px solid #E8E5DC;">
                            <a href="{{ url('upload/' . $gallery->image) }}" data-fancybox="gallery-a" data-caption="{{ $gallery->title }}">
                                <img src="{{ url('upload/' . $gallery->image) }}" />
                            </a>
                        </div>
                    </div>
                    @endforeach
                </div>

                <a href="{{route('photo_gallery')}}" class="btn mt-4 mb-5" style="background-color: #9B6AAB; color: #fff; border-radius: 30px; padding: 12px 30px; font-family: 'Montserrat', sans-serif; font-weight: 500; letter-spacing: 1px; text-transform: uppercase; font-size: 0.85rem;">View All Photos</a>
            </div>
        </div>
    </div>
</section>

@include('front.layouts.footer')
