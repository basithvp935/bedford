
@section('title', 'Bright Beginnings Ksa - Best Residential school ')
@section('description', 'Discover Bright Beginnings Ksa - Best Residential school. Offering world-class education, holistic development, and a global curriculum to shape future leaders. Enroll today')
@section('home', 'active')

@include('front.layouts.header')
 <div class="bg-grid">
<style>
    /* Import Elegant Serif, Clean Sans-Serif, and Handwritten Script Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Montserrat:wght@300;400;500;600&family=Great+Vibes&display=swap');

    html, body {
        font-family: 'Montserrat', sans-serif;
        color: #4A4A4A;
        background-color: #F7F5F0;
        overflow-x: hidden; /* Prevents scrollbar from the moving clouds */
        width: 100%;
        max-width: 100vw;
    }
    
    p {
        text-align: justify;
    }

    h1, h2, h3, h4, h5, h6, .display-2, .section-heading, .title-heading, .notice-box h5, .overlay-title, .gallery-label {
        font-family: 'Playfair Display', serif;
        color: #9B6AAB; /* Purple */
        font-weight: 400;
    }

    /* Tracked out uppercase styling for main headers */
    .section-heading, .about-title {
        letter-spacing: 3px;
        text-transform: uppercase;
    }

    /* Elegant handwriting font */
    .script-font {
        font-family: 'Great Vibes', cursive;
        color: #9B6AAB; /* Purple */
        font-size: 2.8rem;
        line-height: 1.2;
        font-weight: 400;
        text-transform: none;
        letter-spacing: 1px;
    }

    /* ------------------------------------------- */
    /* Organic Section Background Colors           */
    /* ------------------------------------------- */
    .bg-grid { background-color: #F7F5F0; }
    
    .about.home-about { 
        background-color: #F7F5F0 !important; 
        position: relative; 
        z-index: 1; 
        overflow: hidden; 
    }
    
    .calendar-enhanced { 
        background-color: #E9EDE6 !important; /* Soft Sage Background */
        position: relative; 
        z-index: 1; 
        overflow: hidden; 
    } 
    
    .explore-enhanced { 
        background-color: #F7F5F0 !important; 
        position: relative; 
        z-index: 1; 
    }
    
    .facilities-enhanced { 
        background-color: #F7F5F0 !important; /* Warm cream matching Gallery page */
        position: relative; 
        z-index: 2; /* Increased z-index to sit above the grid */
        overflow: hidden; 
    }
    
    .news-events-enhanced { 
        background-color: #F7F5F0 !important; 
        position: relative; 
        z-index: 1; 
        overflow: hidden; 
    }

    /* ------------------------------------------- */
    /* Icon & Blob Placements                      */
    /* ------------------------------------------- */
    .aesthetic-icon {
        position: absolute;
        z-index: 0;
        opacity: 0.85;
        pointer-events: none;
    }

    @keyframes float {
        0% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(-15px) rotate(2deg); }
        100% { transform: translateY(0px) rotate(0deg); }
    }
    
    @keyframes float-reverse {
        0% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(15px) rotate(-2deg); }
        100% { transform: translateY(0px) rotate(0deg); }
    }
    
    @keyframes slow-spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    /* Horizontal Moving Cloud Animations (Two Speeds for Parallax Effect) */
    @keyframes move-cloud-horizontal-1 {
        0% { left: -25%; transform: translateY(0px) scale(1.1); }
        100% { left: 110%; transform: translateY(0px) scale(1.1); }
    }

    @keyframes move-cloud-horizontal-2 {
        0% { left: -15%; transform: translateY(0px) scale(0.7); }
        100% { left: 115%; transform: translateY(0px) scale(0.7); }
    }
    
    .moving-cloud-1 {
        position: absolute;
        z-index: 0;
        pointer-events: none;
        animation: move-cloud-horizontal-1 32s linear infinite;
        color: #FFFFFF;
        opacity: 0.9;
    }

    .moving-cloud-2 {
        position: absolute;
        z-index: 0;
        pointer-events: none;
        animation: move-cloud-horizontal-2 48s linear infinite;
        color: #F7F5F0;
        opacity: 0.8;
    }

    /* Ensure content stays above the aesthetic background icons */
    .about-portrait-wrap, .about-stats, .in-txt, .about-title, .about h4, .script-font, .event-cnd, .facilities-cards, .news-card {
        position: relative;
        z-index: 2;
    }

    /* Typography & UI adjustments */
    .hero-kids .display-2 {
        line-height: 1.2;
        margin-bottom: 25px;
        text-transform: none;
        letter-spacing: 0.5px;
        font-size: 3.5rem; 
        color: #9B6AAB;
    }

    .hero-kids {
        /* Removed overflow: hidden so butterfly can fly above navbar */
    }

    .hero-kids .display-2 .sun {
        color: #9B6AAB;
        font-weight: 500;
        font-style: italic;
        font-size: 1em;
    }

    .hero-kids .display-2 .plum {
        color: #A89F91;
        font-weight: 400;
    }
    
    .hero-kids p {
        font-family: 'Montserrat', sans-serif;
        font-weight: 300;
        letter-spacing: 2px;
        color: #5A5A5A;
    }

    .kicker, .about-kicker, .section-kicker, .calendar-hero-chip {
        font-family: 'Montserrat', sans-serif !important;
        color: #A89F91 !important;
        letter-spacing: 2px !important;
        text-transform: uppercase;
        font-size: 0.85rem;
    }
    
    .kicker .dot, .about-kicker .dot, .section-kicker .dot, .calendar-hero-chip .dot {
        background-color: #7A8B6F !important;
    }

    .btn-primary.cta, .main-btn {
        background-color: #9B6AAB !important; 
        background-image: none !important;
        border-color: #9B6AAB !important;
        color: #FFFFFF !important;
        border-radius: 30px !important; 
        padding: 12px 30px !important;
        font-family: 'Montserrat', sans-serif !important;
        font-weight: 500 !important;
        letter-spacing: 1px !important;
        text-transform: uppercase !important;
        font-size: 0.85rem !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 4px 15px rgba(181, 141, 180, 0.3) !important;
    }
    
    .btn-primary.cta:hover, .main-btn:hover {
        background-color: #9f7b9e !important;
        background-image: none !important;
        border-color: #9f7b9e !important;
        color: #fff !important;
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(181, 141, 180, 0.4) !important;
    }

    .about-title .t1 { color: #9B6AAB; }
    .about-title .t2 { color: #9B6AAB; font-style: italic; }

    /* Banner Type Box for History / Present (Transparent) */
    .history-box {
        background: transparent;
        border: 1px solid rgba(168, 159, 145, 0.3);
        border-radius: 20px;
        padding: 2.2rem;
        position: relative;
        overflow: hidden;
        transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
    }
    
    .history-box:hover {
        transform: translateY(-3px);
        box-shadow: 0 15px 35px rgba(155, 106, 171, 0.08);
        border-color: rgba(155, 106, 171, 0.3);
    }
    
    .history-box.past {
        border-left: 5px solid #7A8B6F; /* Sage green */
    }
    
    .history-box.present {
        border-left: 5px solid #9B6AAB; /* Purple */
    }

    .about-stats .stat-num {
        color: #7A8B6F;
        font-family: 'Playfair Display', serif;
    }
    
    .about-stats .stat-label {
        font-family: 'Montserrat', sans-serif;
        font-size: 0.85rem;
        letter-spacing: 1px;
        text-transform: uppercase;
        color: #A89F91;
    }
    
    .about-badge-awards {
        background-color: #E8E5DC !important;
        border: 1px solid #D4C5B9 !important;
        color: #3C4A3E !important;
    }
    .about-badge-awards .badge-icon {
        background-color: #7A8B6F !important;
        color: #fff !important;
    }
    .about-badge-awards .badge-number, .about-badge-awards .badge-label {
        color: #3C4A3E !important;
        font-family: 'Playfair Display', serif;
    }

    /* ------------------------------------------- */
    /* Feature Cards Section (NEW)                 */
    /* ------------------------------------------- */
    .features-section {
        background-color: #F7F5F0;
        position: relative;
        z-index: 1;
    }
    .feature-card {
        background: linear-gradient(145deg, #FFFFFF 0%, #FDFCF9 100%);
        border-radius: 20px;
        border: 1px solid #E8E5DC;
        box-shadow: 0 15px 40px rgba(60, 74, 62, 0.04);
        transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
    }
    .feature-card:hover {
        background: #F0E4F4; /* Increased purple intensity */
        transform: translateY(-5px);
        box-shadow: 0 25px 50px rgba(60, 74, 62, 0.08);
    }
    .feature-heading {
        font-family: 'Playfair Display', serif;
        color: #9B6AAB; /* Purple */
        font-weight: 500;
        font-size: 1.5rem;
    }
    .feature-text {
        font-family: 'Montserrat', sans-serif;
        color: #5A5A5A; 
        font-size: 0.95rem;
        line-height: 1.8;
        font-weight: 400;
    }

    /* President Message Section */
    .president-card {
        background: #F5F2EA !important; /* Light cream color matching image */
        border-radius: 20px;
        position: relative;
        overflow: hidden;
        padding: 4rem 3rem !important;
    }
    
    .president-photo-wrap {
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    
    .president-text-box {
        background: rgba(255, 255, 255, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.8);
        border-radius: 15px;
        padding: 2.5rem;
        backdrop-filter: blur(10px);
    }

    .president-kicker-badge {
        background: rgba(122, 139, 111, 0.1);
        border: 1px solid rgba(122, 139, 111, 0.3);
        border-radius: 30px;
        padding: 6px 15px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        font-family: 'Montserrat', sans-serif;
        font-size: 0.75rem;
        letter-spacing: 2px;
        text-transform: uppercase;
        color: #3C4A3E; /* Dark olive text for readability */
        margin-bottom: 15px;
    }
    
    .president-kicker-badge .dot {
        width: 8px;
        height: 8px;
        background-color: #7A8B6F;
        border-radius: 50%;
        display: inline-block;
    }
    
    .president-name-new {
        font-family: 'Playfair Display', serif;
        font-style: italic;
        font-weight: 600;
        color: #9B6AAB;
        font-size: 2.2rem;
        text-transform: uppercase;
        margin-bottom: 20px;
        letter-spacing: 1px;
    }
    
    .president-quote-new p {
        font-family: 'Montserrat', sans-serif;
        font-size: 0.95rem;
        line-height: 1.8;
        color: #5A5A5A;
        margin-bottom: 1rem;
        font-weight: 400;
        text-align: justify;
    }

    /* Fix for mobile text squeezing in Founder's Message */
    @media (max-width: 768px) {
        .president-card {
            padding: 2rem 1rem !important;
        }
        .president-text-box {
            padding: 1.5rem;
        }
        .president-quote-new p {
            font-size: 0.95rem;
        }
    }

    .flash-news {
        background-color: #FFFFFF;
        border-radius: 10px;
        border-left: 4px solid #7A8B6F;
    }
    
    #news-head {
        color: #9B6AAB;
        font-family: 'Montserrat', sans-serif;
    }
    
    .notice-box, .news-card, .facilities-cards .item {
        background-color: #FFFFFF;
        border-radius: 15px;
        border: 1px solid #E8E5DC;
    }
    
    .notice-date {
        color: #A89F91;
        font-family: 'Montserrat', sans-serif;
        font-size: 0.85rem;
    }
    
    .overlay-card .badge-new {
        background-color: #A89F91 !important;
        font-family: 'Montserrat', sans-serif;
        letter-spacing: 1px;
        text-transform: uppercase;
        font-size: 0.75rem;
    }

    .hero-kids .hero-bg .doodle, .hero-kids .hero-bg .cloud, .hero-kids .hero-bg .plane {
        display: none; 
    }

    @media (max-width: 991px) {
        .hero-kids .display-2 {
            font-size: 2.2rem; 
        }
        .hero-flower-mobile {
            left: auto !important;
            right: -10px !important;
        }
        .montessori-sun-wrapper {
            left: 20% !important;
        }
    }

    /* Event Calendar Override */
    .calendar-enhanced .event-cnd {
        background: #F5F2EA !important;
        border: 1px solid #E8E5DC !important;
        box-shadow: 0 15px 40px rgba(60, 74, 62, 0.04) !important;
    }
    
    .calendar-enhanced .event-cnd::after {
        display: none !important; /* Remove the grid overlay if any */
    }

    /* Organic Hero Background Shade */
    .hero-kids .hero-bg::before {
        background: linear-gradient(
            145deg,
            #FDFCF9 0%,
            #F5F2EA 100%
        ) !important;
        opacity: 0.9;
    }
    
    /* Organic Grid Color Override */
    .bg-grid::before {
        background-image:
            linear-gradient(to right, rgba(155, 106, 171, 0.08) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(155, 106, 171, 0.08) 1px, transparent 1px) !important;
    }

    /* Environments Slider Cards Override */
    .facilities-enhanced .item {
        border-radius: 20px;
        overflow: hidden;
        background-color: #F7F5F0 !important; /* Match Photo Gallery background */
        /*box-shadow: 0 10px 30px rgba(0,0,0,0.1);*/
        border: none !important;
        transition: transform 0.3s ease;
        position: relative;
        display: flex;
        flex-direction: column;
        height: 100%;
    }
    
    .facilities-enhanced .item:hover {
        transform: translateY(-5px);
    }
    
    .facilities-enhanced .item .efx-img {
        border-radius: 20px 20px 0 0;
        overflow: hidden;
        width: 100%;
        height: 250px;
        flex-shrink: 0;
    }
    
    .facilities-enhanced .item .efx-img img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .facilities-enhanced .ov-content {
        background: #dee9e8  !important; /* Match Photo Gallery background */
        position: relative !important;
        bottom: auto !important;
        left: auto !important;
        right: auto !important;
        padding: 25px 20px !important;
        margin: 0 !important; 
        border-radius: 0 0 20px 20px !important;
        box-shadow: none !important;
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        min-height: 175px;
        flex-grow: 1;
        text-align: left;
    }
    
    .facilities-enhanced .ov-content::after,
    .facilities-enhanced .ov-content::before {
        display: none !important;
    }
    
    .facilities-enhanced .ov-content .details {
        text-align: left;
        width: 100%;
        background-color: transparent !important;
    }
    
    .facilities-enhanced .ov-content .details h5 {
        color: #3C4A3E !important;
        font-family: 'Playfair Display', serif;
        font-size: 1.3rem;
        margin-bottom: 10px;
        text-transform: none;
        letter-spacing: 0;
        font-weight: 500;
        text-shadow: none;
    }
    
    .facilities-enhanced .ov-content .details p {
        display: block !important;
        color: #5A5A5A !important;
        font-family: 'Playfair Display', serif;
        font-size: 1rem;
        line-height: 1.6;
        margin-bottom: 0;
    }
    
    /* Slider Arrows Override */
    .carrow a {
        color: #9B6AAB !important;
        transition: all 0.3s ease;
    }
    
    .carrow a:hover {
        color: #CBB2D6 !important;
    }
    
    .carrow a svg {
        width: 35px;
        height: 35px;
        stroke-width: 1.5px;
    }

    /* Cards Section Override (Notice & Admission) */
    .cards-section .overlay-card .overlay-title {
        background: #9B6AAB !important;
        font-family: 'Montserrat', sans-serif !important;
        letter-spacing: 1px;
    }
    
    .cards-section .overlay-card .overlay-title::before {
        background: #D4C5B9 !important;
        box-shadow: 0 0 0 4px rgba(212, 197, 185, 0.3) !important;
    }
    
    .notice-box {
        background-color: #FDFCF9 !important;
        border: 1px solid #E8E5DC !important;
        border-radius: 15px !important;
    }

    /* Ultra Realistic 3D Butterfly Animations */
    @keyframes flutter-l {
        0% { transform: rotateY(0deg); }
        100% { transform: rotateY(70deg); }
    }
    @keyframes flutter-r {
        0% { transform: rotateY(0deg); }
        100% { transform: rotateY(-70deg); }
    }
    @keyframes erratic-bounce {
        0% { transform: translateY(0px) rotateX(15deg); }
        100% { transform: translateY(-20px) rotateX(-5deg); }
    }
    @keyframes fly-and-land {
        0% { transform: translate(-50vw, 150px) rotate(25deg) scale(1); opacity: 0; }
        7% { transform: translate(-35vw, 50px) rotate(45deg) scale(1.1); opacity: 1; }
        18% { transform: translate(-20vw, -40px) rotate(10deg) scale(0.9); }
        33% { transform: translate(-10vw, 60px) rotate(35deg) scale(1.1); }
        48% { transform: translate(-2vw, -20px) rotate(5deg) scale(0.95); }
        56% { transform: translate(15px, -30px) rotate(25deg) scale(1); }
        61% { transform: translate(5px, 0px) rotate(0deg) scale(0.85); opacity: 1; }
        67% { transform: translate(5px, 0px) rotate(0deg) scale(0.85); opacity: 1; }
        85% { transform: translate(25vw, -150px) rotate(20deg) scale(0.95); opacity: 1; }
        96% { transform: translate(45vw, -300px) rotate(45deg) scale(1); opacity: 1; }
        100% { transform: translate(48vw, -320px) rotate(45deg) scale(1); opacity: 0; }
    }
    .realistic-butterfly-wrapper {
        position: absolute;
        z-index: 9999;
        pointer-events: none;
        perspective: 800px;
        animation: fly-and-land 16s cubic-bezier(0.45, 0.05, 0.55, 0.95) infinite;
        filter: drop-shadow(0px 15px 8px rgba(0,0,0,0.3));
    }
    .butterfly-3d-body {
        transform-style: preserve-3d;
        animation: erratic-bounce 0.6s infinite ease-in-out alternate;
    }
    
    @keyframes heading-cloud-move {
        0% { transform: translateX(-5vw) translateY(0px) scale(0.9); opacity: 0; }
        10% { transform: translateX(0vw) translateY(-5px) scale(1); opacity: 0.85; }
        60% { transform: translateX(35vw) translateY(5px) scale(1); opacity: 0.85; }
        80% { transform: translateX(45vw) translateY(-5px) scale(0.9); opacity: 0; }
        100% { transform: translateX(50vw) translateY(-5px) scale(0.9); opacity: 0; }
    }
    .heading-cloud-wrapper {
        position: absolute;
        top: -70px;
        left: 0;
        z-index: 1;
        pointer-events: none;
        animation: heading-cloud-move 18s linear infinite;
        filter: drop-shadow(0px 8px 12px rgba(0,0,0,0.04));
    }

    /* Fix iOS Safari Hero Image Missing Bug */
    .portrait .carousel,
    .portrait .carousel-inner,
    .portrait .carousel-item {
        position: absolute !important;
        top: 0;
        left: 0;
        width: 100% !important;
        height: 100% !important;
    }
    .portrait img {
        position: relative !important;
        width: 100% !important;
        height: 100% !important;
        object-fit: cover !important;
        z-index: 1 !important;
    }

    /* News Section Flower Responsive Positioning */
    .news-flower-icon {
        top: -10px; 
        left: -80px; 
        opacity: 0.95; 
        z-index: 0; 
        transform: scale(0.8) rotate(10deg);
    }
    
    @media (max-width: 767px) {
        .news-flower-icon {
            top: -100px;
            left: -15px;
            transform: scale(0.6) rotate(15deg);
            transform-origin: left center;
            opacity: 0.85;
        }
    }
</style>

 <!-- Hero -->
    <main class="hero hero-kids position-relative">
      
      <!-- NEW: Fluffy Montessori Cloud 1 traversing slowly across the Hero (Parallax) -->
      <div class="moving-cloud-1" aria-hidden="true" style="top: 15%;">
        <svg class="montessori-cloud" width="150" height="85" viewBox="0 0 180 100" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <filter id="cloudShadow1" x="-10%" y="-10%" width="120%" height="120%">
              <feDropShadow dx="0" dy="8" stdDeviation="6" flood-color="#A89F91" flood-opacity="0.1"/>
            </filter>
          </defs>
          <g filter="url(#cloudShadow1)" fill="#FDFBF8" opacity="0.9">
            <ellipse cx="45" cy="60" rx="25" ry="20" />
            <ellipse cx="75" cy="45" rx="35" ry="30" />
            <ellipse cx="115" cy="55" rx="30" ry="25" />
            <ellipse cx="145" cy="65" rx="20" ry="15" />
            <rect x="35" y="60" width="115" height="20" rx="10" />
          </g>
        </svg>
      </div>

      <!-- NEW: Fluffy Montessori Cloud 2 traversing horizontally across the Hero (Parallax) -->
      <div class="moving-cloud-2" aria-hidden="true" style="top: 40%;">
        <svg class="montessori-cloud" width="110" height="60" viewBox="0 0 180 100" xmlns="http://www.w3.org/2000/svg">
          <g fill="#FDFBF8" opacity="0.8">
            <ellipse cx="45" cy="60" rx="25" ry="20" />
            <ellipse cx="75" cy="45" rx="35" ry="30" />
            <ellipse cx="115" cy="55" rx="30" ry="25" />
            <ellipse cx="145" cy="65" rx="20" ry="15" />
            <rect x="35" y="60" width="115" height="20" rx="10" />
          </g>
        </svg>
      </div>



      <!-- Montessori Fluffy Cloud Icons in Hero -->
      <div class="aesthetic-icon" aria-hidden="true" style="top: 10%; right: 15%; opacity: 0.8; animation: float 6s ease-in-out infinite;">
        <svg class="montessori-cloud" width="100" height="55" viewBox="0 0 180 100" xmlns="http://www.w3.org/2000/svg">
          <g fill="#FDFBF8">
            <ellipse cx="45" cy="60" rx="25" ry="20" />
            <ellipse cx="75" cy="45" rx="35" ry="30" />
            <ellipse cx="115" cy="55" rx="30" ry="25" />
            <ellipse cx="145" cy="65" rx="20" ry="15" />
            <rect x="35" y="60" width="115" height="20" rx="10" />
          </g>
        </svg>
      </div>
      <div class="aesthetic-icon" aria-hidden="true" style="bottom: 20%; left: 5%; opacity: 0.6; animation: float-reverse 8s ease-in-out infinite;">
        <svg class="montessori-cloud" width="80" height="45" viewBox="0 0 180 100" xmlns="http://www.w3.org/2000/svg">
          <g fill="#F7F5F0">
            <ellipse cx="45" cy="60" rx="25" ry="20" />
            <ellipse cx="75" cy="45" rx="35" ry="30" />
            <ellipse cx="115" cy="55" rx="30" ry="25" />
            <ellipse cx="145" cy="65" rx="20" ry="15" />
            <rect x="35" y="60" width="115" height="20" rx="10" />
          </g>
        </svg>
      </div>

      <div class="hero-bg" aria-hidden="true">
        <!-- Kept empty as original to override default bg styles -->
      </div>
      <div class="container-xxl">
        <div class="row align-items-center g-4 g-lg-5 ">
          <div class="col-lg-6" style="position: relative;">
            <!-- NEW: Realistic Montessori Cloud Above Heading Moving to Flower -->
            <div class="heading-cloud-wrapper" aria-hidden="true">
              <svg class="montessori-cloud" width="160" height="90" viewBox="0 0 180 100" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <filter id="cloudShadow" x="-10%" y="-10%" width="120%" height="120%">
                    <feDropShadow dx="0" dy="8" stdDeviation="6" flood-color="#A89F91" flood-opacity="0.15"/>
                  </filter>
                  <linearGradient id="cloudGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stop-color="#FFFFFF"/>
                    <stop offset="50%" stop-color="#FDFBF8"/>
                    <stop offset="100%" stop-color="#E8E5DC"/>
                  </linearGradient>
                </defs>
                <g filter="url(#cloudShadow)" fill="url(#cloudGrad)">
                  <ellipse cx="45" cy="60" rx="25" ry="20" />
                  <ellipse cx="75" cy="45" rx="35" ry="30" />
                  <ellipse cx="115" cy="55" rx="30" ry="25" />
                  <ellipse cx="145" cy="65" rx="20" ry="15" />
                  <rect x="35" y="60" width="115" height="20" rx="10" />
                </g>
              </svg>
            </div>

            <h1 class="display-2" style="line-height: 1.2; margin-bottom: 1rem;">
              <span class="sun" style="font-family: 'Playfair Display', serif; font-style: italic; font-weight: 500; color: #9B6AAB;">The Montessori Beginning</span><br />
              <span class="plum" style="font-family: 'Playfair Display', serif; font-style: italic; font-weight: 400; color: #605544;">
                Every Child 
                <span style="display: inline-block; position: relative;">
                  Deserves!
                  <!-- NEW: Elegant Montessori Dotted Sun Icon positioned precisely underneath "Deserves!" without moving the button -->
                  <span class="montessori-sun-wrapper d-block text-center" style="position: absolute; left: 50%; transform: translateX(-50%); top: 100%; margin-top: 30px; z-index: 5;">
                    <svg class="montessori-earthy-sun" width="55" height="55" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg" style="animation: slow-spin 30s linear infinite; filter: drop-shadow(0px 3px 5px rgba(186, 156, 126, 0.2));">
                      <defs>
                        <filter id="sunEmboss" x="-20%" y="-20%" width="140%" height="140%">
                          <feDropShadow dx="0" dy="2" stdDeviation="2" flood-color="#A89F91" flood-opacity="0.25"/>
                        </filter>
                      </defs>
                      <!-- Outer Ring with Soft Emboss Shadow -->
                      <circle cx="30" cy="30" r="14" fill="#FDFCF9" stroke="#BA9C7E" stroke-width="1.8" filter="url(#sunEmboss)" />
                      <!-- Inner Dotted Ring -->
                      <circle cx="30" cy="30" r="10.5" fill="none" stroke="#BA9C7E" stroke-width="1.4" stroke-dasharray="0.5 3.5" stroke-linecap="round" />
                      <!-- 8 Radial Sun Rays -->
                      <!-- Top / Bottom -->
                      <line x1="30" y1="11.5" x2="30" y2="6.5" stroke="#BA9C7E" stroke-width="1.6" stroke-linecap="round" />
                      <line x1="30" y1="48.5" x2="30" y2="53.5" stroke="#BA9C7E" stroke-width="1.6" stroke-linecap="round" />
                      <!-- Left / Right -->
                      <line x1="11.5" y1="30" x2="6.5" y2="30" stroke="#BA9C7E" stroke-width="1.6" stroke-linecap="round" />
                      <line x1="48.5" y1="30" x2="53.5" y2="30" stroke="#BA9C7E" stroke-width="1.6" stroke-linecap="round" />
                      <!-- Diagonals -->
                      <line x1="17" y1="17" x2="13.5" y2="13.5" stroke="#BA9C7E" stroke-width="1.6" stroke-linecap="round" />
                      <line x1="43" y1="17" x2="46.5" y2="13.5" stroke="#BA9C7E" stroke-width="1.6" stroke-linecap="round" />
                      <line x1="43" y1="43" x2="46.5" y2="46.5" stroke="#BA9C7E" stroke-width="1.6" stroke-linecap="round" />
                      <line x1="17" y1="43" x2="13.5" y2="46.5" stroke="#BA9C7E" stroke-width="1.6" stroke-linecap="round" />
                    </svg>
                  </span>
                </span>
              </span>
            </h1>

            <div class="hero-actions mt-4 pt-2">
              <a
                class="btn btn-primary cta text-white d-inline-flex align-items-center gap-2"
                href="{{ route('admission') }}"
              >
                Admission<i class="bi bi-arrow-right"></i>
              </a>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="portrait-wrap">
              <div class="hero-shape shape-stripes-top" aria-hidden="true"></div>
              <div class="hero-shape shape-circle-yellow" aria-hidden="true"></div>
              
              <!-- NEW ICON 1: Daisy Flower (from Montessori palette) replacing the Sun -->
              <div class="hero-shape shape-plus-top aesthetic-icon hero-flower-mobile" aria-hidden="true" style="top: -20px; left: -10px; opacity: 0.9; transform: rotate(15deg);">
                <svg width="60" height="80" viewBox="0 0 60 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <!-- Stem -->
                  <path d="M30 30 Q25 55, 30 80" stroke="#7A8B6F" stroke-width="3" fill="none"/>
                  <!-- Leaves -->
                  <path d="M30 60 Q15 50, 10 55 Q20 65, 28 65 Z" fill="#7A8B6F" opacity="0.8"/>
                  <path d="M28 45 Q45 35, 50 40 Q40 50, 32 50 Z" fill="#7A8B6F" opacity="0.8"/>
                  <!-- Petals (Daisy) -->
                  <circle cx="30" cy="15" r="7" fill="#F7F5F0" stroke="#D4C5B9" stroke-width="1"/>
                  <circle cx="20" cy="22" r="7" fill="#F7F5F0" stroke="#D4C5B9" stroke-width="1"/>
                  <circle cx="40" cy="22" r="7" fill="#F7F5F0" stroke="#D4C5B9" stroke-width="1"/>
                  <circle cx="24" cy="33" r="7" fill="#F7F5F0" stroke="#D4C5B9" stroke-width="1"/>
                  <circle cx="36" cy="33" r="7" fill="#F7F5F0" stroke="#D4C5B9" stroke-width="1"/>
                  <!-- Center -->
                  <circle cx="30" cy="25" r="5" fill="#A89F91"/>
                </svg>
              </div>

              <!-- REALISTIC FLUTTERING BUTTERFLY AROUND FLOWER -->
              <div class="realistic-butterfly-wrapper hero-flower-mobile" aria-hidden="true" style="top: -20px; left: -10px;">
                <div class="butterfly-3d-body">
                    <svg class="colorful-butterfly" width="50" height="50" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" style="overflow: visible;">
                      <defs>
                        <linearGradient id="wingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stop-color="#FFB347" />
                          <stop offset="60%" stop-color="#FF7B00" />
                          <stop offset="100%" stop-color="#CC4400" />
                        </linearGradient>
                        <linearGradient id="wingGradLower" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stop-color="#FFD180" /> 
                          <stop offset="100%" stop-color="#FF8C00" />
                        </linearGradient>
                      </defs>
                      <!-- Left Wing -->
                      <g style="transform-origin: 50px 50px; animation: flutter-l 0.12s cubic-bezier(0.2, 0.8, 0.4, 1) infinite alternate;">
                        <!-- Upper -->
                        <path d="M50 50 C 20 20, 5 25, 10 40 C 15 60, 40 60, 50 50" fill="url(#wingGrad)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                        <path d="M50 50 C 35 35, 20 35, 15 42" stroke="#222" stroke-width="1.5" fill="none"/>
                        <path d="M50 50 C 25 45, 15 50, 15 50" stroke="#222" stroke-width="1.5" fill="none"/>
                        <!-- Lower -->
                        <path d="M50 50 C 30 65, 20 85, 35 90 C 45 95, 50 70, 50 50" fill="url(#wingGradLower)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                        <path d="M50 50 C 40 70, 30 80, 28 85" stroke="#222" stroke-width="1.5" fill="none"/>
                        <!-- Edge Dots -->
                        <circle cx="12" cy="40" r="1.5" fill="#FFF"/>
                        <circle cx="17" cy="53" r="1.5" fill="#FFF"/>
                        <circle cx="30" cy="86" r="1.5" fill="#FFF"/>
                        <circle cx="40" cy="89" r="1.5" fill="#FFF"/>
                      </g>
                      <!-- Right Wing -->
                      <g style="transform-origin: 50px 50px; animation: flutter-r 0.12s cubic-bezier(0.2, 0.8, 0.4, 1) infinite alternate;">
                        <!-- Upper -->
                        <path d="M50 50 C 80 20, 95 25, 90 40 C 85 60, 60 60, 50 50" fill="url(#wingGrad)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                        <path d="M50 50 C 65 35, 80 35, 85 42" stroke="#222" stroke-width="1.5" fill="none"/>
                        <path d="M50 50 C 75 45, 85 50, 85 50" stroke="#222" stroke-width="1.5" fill="none"/>
                        <!-- Lower -->
                        <path d="M50 50 C 70 65, 80 85, 65 90 C 55 95, 50 70, 50 50" fill="url(#wingGradLower)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                        <path d="M50 50 C 60 70, 70 80, 72 85" stroke="#222" stroke-width="1.5" fill="none"/>
                        <!-- Edge Dots -->
                        <circle cx="88" cy="40" r="1.5" fill="#FFF"/>
                        <circle cx="83" cy="53" r="1.5" fill="#FFF"/>
                        <circle cx="70" cy="86" r="1.5" fill="#FFF"/>
                        <circle cx="60" cy="89" r="1.5" fill="#FFF"/>
                      </g>
                      <!-- Body -->
                      <rect x="47" y="38" width="6" height="24" rx="3" fill="#333"/>
                      <circle cx="50" cy="35" r="4" fill="#333"/>
                      <!-- Antennae -->
                      <path d="M 48 33 Q 40 15, 36 20 M 52 33 Q 60 15, 64 20" stroke="#333" stroke-width="1.5" fill="none" stroke-linecap="round"/>
                    </svg>
                </div>
              </div>

              <!-- NEW ICON 2: Highly Realistic Wooden Rainbow -->
              <div class="hero-shape aesthetic-icon" aria-hidden="true" style="top: 25%; left: -10%; opacity: 0.95; transform: rotate(-10deg);">
                <svg width="100" height="60" viewBox="0 0 120 75" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <filter id="rainbowShadow" x="-20%" y="-20%" width="140%" height="140%">
                      <feDropShadow dx="0" dy="8" stdDeviation="5" flood-color="#7A6B5D" flood-opacity="0.25"/>
                    </filter>
                    <filter id="blockShadow" x="-10%" y="-10%" width="120%" height="120%">
                      <feDropShadow dx="0" dy="2" stdDeviation="1.5" flood-color="#332211" flood-opacity="0.15"/>
                    </filter>
                    <linearGradient id="themePurple" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stop-color="#B58EBD"/>
                      <stop offset="100%" stop-color="#9B6AAB"/>
                    </linearGradient>
                    <linearGradient id="themeSage" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stop-color="#9CB28F"/>
                      <stop offset="100%" stop-color="#7A8B6F"/>
                    </linearGradient>
                    <linearGradient id="themeBeige" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stop-color="#E6D9CD"/>
                      <stop offset="100%" stop-color="#D4C5B9"/>
                    </linearGradient>
                  </defs>

                  <g filter="url(#rainbowShadow)">
                    <!-- Arch 1: Outer Purple -->
                    <path d="M 10 60 A 50 50 0 0 1 110 60 L 94 60 A 34 34 0 0 0 26 60 Z" 
                          fill="url(#themePurple)" stroke="#8A569C" stroke-width="1.5" stroke-linejoin="round" filter="url(#blockShadow)"/>
                    
                    <!-- Arch 2: Middle Sage Green -->
                    <path d="M 28 60 A 32 32 0 0 1 92 60 L 78 60 A 18 18 0 0 0 42 60 Z" 
                          fill="url(#themeSage)" stroke="#69795F" stroke-width="1.5" stroke-linejoin="round" filter="url(#blockShadow)"/>
                    
                    <!-- Arch 3: Inner Beige -->
                    <path d="M 44 60 A 16 16 0 0 1 76 60 L 66 60 A 6 6 0 0 0 54 60 Z" 
                          fill="url(#themeBeige)" stroke="#C4B2A3" stroke-width="1.5" stroke-linejoin="round" filter="url(#blockShadow)"/>
                  </g>
                </svg>
              </div>

              <div class="portrait" aria-label="Smiling child learning">
                <div id="heroCarousel" class="carousel slide w-100 h-100" data-bs-ride="carousel" data-bs-interval="2000">
                  <div class="carousel-inner w-100 h-100" style="border-radius: inherit;">
                    <div class="carousel-item active w-100 h-100">
                      <img src="{{ asset('Front/images/home.jpg') }}" alt="Smiling child learning 2" style="display: block; width: 100%; height: 100%; object-fit: cover;" />
                    </div>
                    <div class="carousel-item w-100 h-100">
                      <img src="{{ asset('Front/images/children-playing.jpg') }}" alt="Smiling child learning 3" style="display: block; width: 100%; height: 100%; object-fit: cover;" />
                    </div>
                  </div>
                </div>
              </div>

              <div class="hero-shape shape-dots-left" aria-hidden="true">
                <div class="dots-grid"></div>
                <svg class="zigzag-line" width="60" height="15" viewBox="0 0 60 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M2 13L12 3L22 13L32 3L42 13L52 3" stroke="#A89F91" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </div>
              <div class="hero-shape shape-stripes-bottom" aria-hidden="true"></div>
              
              <!-- NEW ICON 3: Wooden Block Tower (from Montessori palette) replacing the Leaf Box -->
              <div class="hero-shape shape-plus-bottom aesthetic-icon" aria-hidden="true" style="bottom: -20px; right: -30px; transform: rotate(10deg);">
                <svg width="50" height="100" viewBox="0 0 50 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <!-- Base Cube -->
                  <rect x="5" y="70" width="40" height="30" fill="#7A8B6F" opacity="0.8"/>
                  <!-- Middle Cube -->
                  <rect x="10" y="45" width="30" height="25" fill="#D4C5B9"/>
                  <!-- Top Cube -->
                  <rect x="15" y="25" width="20" height="20" fill="#A89F91"/>
                  <!-- Triangle Roof -->
                  <polygon points="25,5 10,25 40,25" fill="#E8E5DC"/>
                </svg>
              </div>

              <!-- NEW ICON 4: Organic Leaf Branch (Top Right) -->
              <div class="hero-shape aesthetic-icon" aria-hidden="true" style="top: 15%; right: -45px; opacity: 0.9; transform: rotate(15deg); animation: float 6s ease-in-out infinite;">
                <svg width="70" height="120" viewBox="0 0 50 100" fill="none" stroke="#7A8B6F" stroke-width="1.2" xmlns="http://www.w3.org/2000/svg">
                  <!-- Stem -->
                  <path d="M25 100 Q15 50, 45 0"/>
                  <!-- Leaves -->
                  <path d="M22 80 Q10 75, 5 65 Q15 65, 20 75 Z" fill="#9BA88D"/>
                  <path d="M28 75 Q40 70, 45 60 Q35 60, 30 70 Z" fill="#D4C5B9"/>
                  <path d="M23 60 Q10 55, 5 45 Q15 45, 20 55 Z" fill="#B8C3A9"/>
                  <path d="M27 55 Q40 50, 45 40 Q35 40, 30 50 Z" fill="#9BA88D"/>
                  <path d="M24 40 Q10 35, 5 25 Q15 25, 20 35 Z" fill="#D4C5B9"/>
                  <path d="M30 35 Q40 30, 45 20 Q35 20, 30 30 Z" fill="#B8C3A9"/>
                </svg>
              </div>

            </div>
          </div>
        </div>
      </div>
    </main>

<div class="container news-scroll">
    <div class="row">
        <div class="col-md-12">
            <div class="flash-news shadow-sm" id='abt'>
                <div class="news-title aos-init">
                    <span id="news-head" class="text-uppercase fw-500"> <img src="{{ asset('Front/images/news-icon.png') }}" class="notice-top-border mx-auto" alt=""></span>
                </div>
                <div class="news-text ">
                    <marquee behavior="scroll" scrollamount="4" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
                        <span>
                            <a href="#">
                                <p class=" pe-2 ps-2">
                                    {!! $flash_news->news_title ?? 'Bright Beginnings Ksa' !!}
                                </p>
                            </a>
                        </span>
                    </marquee>
                </div>
            </div>
        </div>
    </div>
</div>


<!--ABOUT-->

<section class="about home-about pt-5 pb-5 about-enhanced image-bg" style="margin-top: -20px;">
    <!-- Organic Background Blob -->
    <div class="aesthetic-icon" aria-hidden="true" style="top: 10%; right: -5%; z-index: -1;">
      <svg width="400" height="400" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
        <path fill="#E8E5DC" opacity="0.6" d="M45.7,-76.1C58.9,-69.3,69.1,-55.4,77.2,-41C85.3,-26.6,91.3,-11.7,89.5,2.6C87.7,16.9,78,30.5,67.6,41.8C57.2,53.1,46,62.1,32.7,69.5C19.4,76.9,4,82.7,-10.8,80.7C-25.6,78.7,-39.8,68.9,-53.4,59C-67,49.1,-80,39.1,-86.3,25.4C-92.6,11.7,-92.2,-5.7,-85.5,-20.3C-78.8,-34.9,-65.8,-46.7,-52.3,-53.8C-38.8,-60.9,-24.8,-63.3,-10.3,-62.4C4.2,-61.5,18.4,-57.3,32.4,-82.9Z" transform="translate(100 100)" />
      </svg>
    </div>

    <!-- NEW: Highly Realistic Blush Pink Watercolor Butterfly (Matching Reference Image) -->
    <div class="aesthetic-icon" style="top: 4%; right: 18%; opacity: 0.95; z-index: 1; transform: rotate(15deg);">
      <svg class="montessori-butterfly" width="70" height="70" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <filter id="bfShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="4" stdDeviation="3" flood-color="#887868" flood-opacity="0.3"/>
          </filter>
          <linearGradient id="blushTopWing" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#EBC4BB" />
            <stop offset="70%" stop-color="#DCA89E" />
            <stop offset="100%" stop-color="#C08479" />
          </linearGradient>
          <linearGradient id="blushTopWingRight" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#EBC4BB" />
            <stop offset="70%" stop-color="#DCA89E" />
            <stop offset="100%" stop-color="#C08479" />
          </linearGradient>
          <linearGradient id="blushBotWing" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#F1D1C6" />
            <stop offset="100%" stop-color="#DCA89E" />
          </linearGradient>
          <linearGradient id="blushBotWingRight" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#F1D1C6" />
            <stop offset="100%" stop-color="#DCA89E" />
          </linearGradient>
        </defs>

        <g filter="url(#bfShadow)">
          <!-- Top Left Wing -->
          <path d="M 58 55 C 40 30, 10 20, 15 45 C 18 60, 30 70, 58 60 Z" fill="url(#blushTopWing)" stroke="#8C6A5D" stroke-width="1.5" stroke-linejoin="round"/>
          <!-- Top Right Wing -->
          <path d="M 62 55 C 80 30, 110 20, 105 45 C 102 60, 90 70, 62 60 Z" fill="url(#blushTopWingRight)" stroke="#8C6A5D" stroke-width="1.5" stroke-linejoin="round"/>
          
          <!-- Bottom Left Wing -->
          <path d="M 58 60 C 40 75, 25 105, 45 100 C 55 98, 60 75, 58 60 Z" fill="url(#blushBotWing)" stroke="#8C6A5D" stroke-width="1.5" stroke-linejoin="round"/>
          <!-- Bottom Right Wing -->
          <path d="M 62 60 C 80 75, 95 105, 75 100 C 65 98, 60 75, 62 60 Z" fill="url(#blushBotWingRight)" stroke="#8C6A5D" stroke-width="1.5" stroke-linejoin="round"/>
          
          <!-- Wing Veins (Left) -->
          <path d="M 58 58 Q 40 40 18 40 M 58 58 Q 35 55 22 55 M 58 62 Q 45 75 40 95 M 58 62 Q 50 80 50 95" stroke="#8C6A5D" stroke-width="0.8" opacity="0.6"/>
          <!-- Wing Veins (Right) -->
          <path d="M 62 58 Q 80 40 102 40 M 62 58 Q 85 55 98 55 M 62 62 Q 75 75 80 95 M 62 62 Q 70 80 70 95" stroke="#8C6A5D" stroke-width="0.8" opacity="0.6"/>
          
          <!-- Wing Edge Dots (Left) -->
          <circle cx="20" cy="48" r="1.5" fill="#FAF5F0"/>
          <circle cx="25" cy="60" r="1.5" fill="#FAF5F0"/>
          <!-- Wing Edge Dots (Right) -->
          <circle cx="100" cy="48" r="1.5" fill="#FAF5F0"/>
          <circle cx="95" cy="60" r="1.5" fill="#FAF5F0"/>
          
          <!-- Body -->
          <rect x="58" y="45" width="4" height="28" rx="2" fill="#5A473D"/>
          
          <!-- Antennae -->
          <path d="M 59 45 Q 52 30 45 25 M 61 45 Q 68 30 75 25" stroke="#5A473D" stroke-width="1.5" fill="none" stroke-linecap="round"/>
          <!-- Antennae Knobs -->
          <circle cx="45" cy="25" r="1.5" fill="#5A473D"/>
          <circle cx="75" cy="25" r="1.5" fill="#5A473D"/>
        </g>
      </svg>
    </div>

    <!-- Organic Botanical Branch Icon -->
    <div class="aesthetic-icon" style="top: 0; right: 10%; opacity: 0.5;">
      <svg width="80" height="150" viewBox="0 0 50 100" fill="none" stroke="#7A8B6F" stroke-width="1" xmlns="http://www.w3.org/2000/svg">
        <path d="M25 100 Q15 50, 45 0"/>
        <path d="M22 80 Q10 75, 5 65 Q15 65, 20 75 Z" fill="#E8E5DC"/>
        <path d="M28 75 Q40 70, 45 60 Q35 60, 30 70 Z" fill="#E8E5DC"/>
        <path d="M23 60 Q10 55, 5 45 Q15 45, 20 55 Z" fill="#E8E5DC"/>
        <path d="M27 55 Q40 50, 45 40 Q35 40, 30 50 Z" fill="#E8E5DC"/>
        <path d="M24 40 Q10 35, 5 25 Q15 25, 20 35 Z" fill="#E8E5DC"/>
        <path d="M30 35 Q40 30, 45 20 Q35 20, 30 30 Z" fill="#E8E5DC"/>
      </svg>
    </div>

    <!-- Realistic Montessori Watercolor Leafy Branch -->
    <div class="aesthetic-icon" style="bottom: 5%; left: 2%; opacity: 0.95; z-index: 1;">
        <svg width="100" height="180" viewBox="-20 -30 140 240" fill="none" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <filter id="plantShadow" x="-20%" y="-20%" width="140%" height="140%">
                    <feDropShadow dx="0" dy="6" stdDeviation="4" flood-color="#7A8B6F" flood-opacity="0.15"/>
                </filter>
                <linearGradient id="leafGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#BBC2B1"/>
                    <stop offset="100%" stop-color="#9BA88D"/>
                </linearGradient>
                <linearGradient id="leafGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#D0CDB8"/>
                    <stop offset="100%" stop-color="#A5AA89"/>
                </linearGradient>
                <linearGradient id="leafGrad3" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#9BA88D"/>
                    <stop offset="100%" stop-color="#7A8B6F"/>
                </linearGradient>
            </defs>

            <g filter="url(#plantShadow)">
                <!-- Main curved stem -->
                <path d="M 50 190 Q 30 100, 70 10" stroke="#7A8B6F" stroke-width="2.5" fill="none" stroke-linecap="round"/>
                
                <!-- Leaves -->
                <!-- Bottom right -->
                <path d="M 46 170 Q 70 160, 85 140 Q 60 145, 46 170 Z" fill="url(#leafGrad1)"/>
                <!-- Bottom left -->
                <path d="M 45 150 Q 20 155, 5 130 Q 30 125, 45 150 Z" fill="url(#leafGrad2)"/>
                
                <!-- Middle right 1 -->
                <path d="M 42 125 Q 70 110, 85 90 Q 60 100, 42 125 Z" fill="url(#leafGrad3)"/>
                <!-- Middle left 1 -->
                <path d="M 43 105 Q 15 110, 5 80 Q 30 85, 43 105 Z" fill="url(#leafGrad1)"/>
                
                <!-- Middle right 2 -->
                <path d="M 49 80 Q 75 60, 90 40 Q 65 55, 49 80 Z" fill="url(#leafGrad2)"/>
                <!-- Middle left 2 -->
                <path d="M 54 60 Q 30 55, 20 30 Q 45 40, 54 60 Z" fill="url(#leafGrad3)"/>
                
                <!-- Top right -->
                <path d="M 62 35 Q 85 20, 95 0 Q 75 15, 62 35 Z" fill="url(#leafGrad1)"/>
                <!-- Top tip leaf -->
                <path d="M 70 10 Q 60 -5, 80 -15 Q 90 -5, 70 10 Z" fill="url(#leafGrad2)"/>
            </g>
        </svg>
    </div>

    <div class="container">
        <div class="row d-md-flex align-items-center g-3 g-md-5">
            <div class="col-md-12 text-center"></div>

            <div class="col-md-8">
                <div data-aos="fade-right">
                   <h6 class="title-heading about-kicker d-flex align-items-center gap-2">
                     <svg width="22" height="22" viewBox="0 0 100 100" fill="none" stroke="#A89F91" stroke-width="4" xmlns="http://www.w3.org/2000/svg">
                       <path d="M50 85 C30 65, 10 45, 15 25 C20 10, 40 10, 50 30 C60 10, 80 10, 85 25 C90 45, 70 65, 50 85 Z"/>
                     </svg>
                     Bright Beginnings Ksa
                   </h6>
                   
                    <h1 class="pb-2 mt-2 about-title d-flex align-items-center gap-3">
                      <span><span class="t1">OUR </span> <span class="t2"> STORY:</span></span>
                      <!-- Montessori Rainbow Icon -->
                      <svg width="50" height="30" viewBox="0 0 100 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 60 A40 40 0 0 1 90 60" stroke="#D4C5B9" stroke-width="10" stroke-linecap="round"/>
                        <path d="M28 60 A22 22 0 0 1 72 60" stroke="#A89F91" stroke-width="10" stroke-linecap="round"/>
                        <path d="M46 60 A4 4 0 0 1 54 60" stroke="#7A8B6F" stroke-width="10" stroke-linecap="round"/>
                      </svg>
                    </h1>
                    
                    <h4 class="mb-2 mt-3" style="font-family: 'Montserrat', sans-serif; font-weight: 500; font-size: 1.1rem; line-height: 1.6; color: #4A4A4A;">
                        30 years of nurturing little minds are reimagined for a new generation.
                    </h4>
                    
                    <!-- New script font application matching the handwritten aesthetic -->
                    <div class="script-font mt-2 mb-4">New name, same heart, even stronger commitment.</div>
                    
                    <style>
                        @media (max-width: 767.98px) {
                            .history-box h6 {
                                letter-spacing: -0.5px !important;
                                word-spacing: 0px !important;
                            }
                            .history-box h4 {
                                letter-spacing: -1px !important;
                                font-size: 1.2rem !important;
                                word-spacing: 0px !important;
                            }
                            .history-box p {
                                text-align: left !important;
                                word-spacing: 0px !important;
                                letter-spacing: 0px !important;
                            }
                        }
                    </style>
                    <div class="in-txt mt-4">
                        <div class="history-box past mb-4">
                            <h6 class="text-uppercase mb-2" style="color: #7A8B6F; letter-spacing: 1px; font-weight: 600; font-family: 'Montserrat', sans-serif; font-size: 0.85rem;">WHERE WE BEGAN &middot; 30 YEARS AGO</h6>
                            <h4 class="mb-3" style="font-size: 1.4rem;">Little Angels Kindergarten, Al Khobar</h4>
                            <p class="mb-0" style="color: #5A5A5A; line-height: 1.8;">We opened our doors with a simple belief: every child learns differently. Our individual teaching system quickly earned the trust of families across the community, making Little Angels a name synonymous with warmth, quality, and care.</p>
                        </div>
                        
                        <div class="history-box present mb-0">
                            <h6 class="text-uppercase mb-2" style="color: #A89F91; letter-spacing: 1px; font-weight: 600; font-family: 'Montserrat', sans-serif; font-size: 0.85rem;">WHERE WE ARE TODAY</h6>
                            <h4 class="mb-3" style="font-size: 1.4rem;">Bright Beginnings Montessori</h4>
                            <p class="mb-0" style="color: #5A5A5A; line-height: 1.8;">The same founding spirit, elevated. We return with a fully authentic Montessori environment and our signature Bright Thread teaching methodology &mdash; a structured, child-centred framework built on everything we learned over three decades.</p>
                        </div>
                    </div>

                    <style>
                        .about-stats .stat {
                            text-align: center;
                            flex: 1;
                        }
                        .about-stats .stat-num {
                            font-size: 2.2rem !important;
                            font-weight: 900 !important;
                            color: #764b8e !important;
                            display: block;
                            margin-bottom: 5px;
                        }
                    </style>
                    <div class="about-stats d-flex gap-3 mt-4" aria-hidden="true">
                            <div class="stat">
                                <div class="stat-num">10K+</div>
                                <div class="stat-label text-uppercase">Children inspired</div>
                            </div>
                            <div class="stat">
                                <div class="stat-num">200+</div>
                                <div class="stat-label text-uppercase">Community Initiatives</div>
                            </div>
                            <div class="stat">
                                <div class="stat-num">30+</div>
                                <div class="stat-label text-uppercase">Years of Service</div>
                            </div>
                        </div>
                    <a href="{{ route('about_us') }}" class="main-btn mt-4">Read more</a>
                </div>
            </div>

            <div class="col-md-4" data-aos="fade-left">
                <div class="about-portrait-wrap">
                    <div class="about-portrait">
                        <img src="{{ asset('Front/images/homepage.jpeg') }}" alt="Bright Beginnings Ksa child studying" />
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FEATURES SECTION -->
<section class="features-section pt-5 pb-5 position-relative overflow-hidden">
    <!-- Pink Butterfly -->
    <div class="aesthetic-icon position-absolute" style="top: 8%; left: 6%; opacity: 0.85; z-index: 0; transform: rotate(-15deg);">
        <svg width="75" height="75" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M50 50C30 30 10 20 15 45C18 60 30 70 50 60Z" fill="#EBC4BB" stroke="#8C6A5D" stroke-width="1.5" stroke-linejoin="round"/>
            <path d="M50 50C70 30 90 20 85 45C82 60 70 70 50 60Z" fill="#EBC4BB" stroke="#8C6A5D" stroke-width="1.5" stroke-linejoin="round"/>
            <path d="M50 50C30 70 20 90 40 85C50 82 55 70 50 50Z" fill="#DCA89E" stroke="#8C6A5D" stroke-width="1.5" stroke-linejoin="round"/>
            <path d="M50 50C70 70 80 90 60 85C50 82 45 70 50 50Z" fill="#DCA89E" stroke="#8C6A5D" stroke-width="1.5" stroke-linejoin="round"/>
            <rect x="48" y="40" width="4" height="25" rx="2" fill="#5A473D"/>
            <path d="M49 40Q45 30 40 25M51 40Q55 30 60 25" stroke="#5A473D" stroke-width="1.5" fill="none" stroke-linecap="round"/>
        </svg>
    </div>
    
    <!-- Botanical Leaves -->
    <div class="aesthetic-icon position-absolute" style="bottom: 5%; right: 4%; opacity: 0.8; z-index: 0; transform: rotate(10deg);">
        <svg width="90" height="90" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M50 100Q45 50 90 10" stroke="#7A8B6F" stroke-width="2" fill="none"/>
            <path d="M48 80C30 80 20 70 30 60C40 50 48 60 48 80Z" fill="#BBC2B1" stroke="#7A8B6F" stroke-width="1.5"/>
            <path d="M52 70C70 70 80 60 70 50C60 40 52 50 52 70Z" fill="#BBC2B1" stroke="#7A8B6F" stroke-width="1.5"/>
            <path d="M45 50C30 50 20 40 30 30C40 20 45 30 45 50Z" fill="#BBC2B1" stroke="#7A8B6F" stroke-width="1.5"/>
            <path d="M60 40C75 40 85 30 75 20C65 10 60 20 60 40Z" fill="#BBC2B1" stroke="#7A8B6F" stroke-width="1.5"/>
        </svg>
    </div>

    <div class="container position-relative" style="z-index: 2;">
        <div class="row g-4">
            
            <!-- Card 1 -->
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
                <div class="feature-card h-100 p-4 p-md-5">
                    <style>
                        .feature-heading {
                            font-family: 'Playfair Display', serif !important;
                            color: #6C4A87 !important;
                            font-size: 1.7rem;
                        }
                        .feature-card {
                            text-align: center;
                        }
                        .feature-text {
                            text-align: center !important;
                            word-spacing: normal !important;
                        }
                    </style>
                    <div class="feature-icon mb-4 d-inline-flex align-items-center justify-content-center" style="width: 80px; height: 80px; border-radius: 50%; background: rgba(122, 139, 111, 0.15);">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#7A8B6F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="2" y1="12" x2="22" y2="12"></line>
                            <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                        </svg>
                    </div>
                    <h4 class="feature-heading mb-3">AMS- Aligned</h4>
                    <p class="feature-text mb-0">
                        We follow the American Montessori Society framework, one of the most rigorous standards in early education.
                    </p>
                </div>
            </div>
            
            <!-- Card 2 -->
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
                <div class="feature-card h-100 p-4 p-md-5">
                    <div class="feature-icon mb-4 d-inline-flex align-items-center justify-content-center" style="width: 80px; height: 80px; border-radius: 50%; background: rgba(118, 75, 142, 0.15);">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#764b8e" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="9" cy="7" r="3"></circle>
                            <path d="M9 10c-3 0-5 2-5 5v2h10v-2c0-3-2-5-5-5z"></path>
                            <polygon points="18 2 20.5 4.5 23 2 21.5 6 24 8.5 20.5 8.5 19 12 17.5 8.5 14 8.5 16.5 6 15 2 17.5 4.5 18 2"></polygon>
                        </svg>
                    </div>
                    <h4 class="feature-heading mb-3">Bright Thread Method</h4>
                    <p class="feature-text mb-0">
                        Our own signature pedagogy, developed over decades, that personalises the Montessori journey for each child.
                    </p>
                </div>
            </div>
            
            <!-- Card 3 -->
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
                <div class="feature-card h-100 p-4 p-md-5">
                    <div class="feature-icon mb-4 d-inline-flex align-items-center justify-content-center" style="width: 80px; height: 80px; border-radius: 50%; background: rgba(220, 168, 88, 0.15);">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#DCA858" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                            <path d="M12 17c-3-2.5-5-4.5-5-6.5a2.5 2.5 0 0 1 5-1.5 2.5 2.5 0 0 1 5 1.5c0 2-2 4-5 6.5z"></path>
                        </svg>
                    </div>
                    <h4 class="feature-heading mb-3">Open Environment</h4>
                    <p class="feature-text mb-0">
                        A thoughtfully prepared space where every material serves a purpose and every child feels free to explore.
                    </p>
                </div>
            </div>
            
        </div>
    </div>
</section>

<section class=" pt-80 pb-80 president-msg position-relative">

    <div class=" pb-5 pt-0 image-bg cards-section">
    <div class="container">
        <div class="row">
              <div class="col-md-4" data-aos="fade-left">
                      <div class="notice-box  shadow-sm h-100">
                    <div class="text-center">
                        <img src="{{ asset('Front/images/notice-top.png') }}" class="notice-top-border mx-auto" alt="">
                        <h3 class="itle-heading about-kicker mb-0">NOTICE</h3>
                    </div>
                    <div class="slick slick-4 mb-0 text-center">
                        @foreach ($notices as $notice)
                            <div class="">
                                <h5 class="fw-800">{{ $notice->title }}</h5>
                                <p  class="notice-desc">{!! $notice->description !!}</p>
                                <span class="notice-date mt-4 d-inline-block " style="margin-bottom: 25px;">{{ \Carbon\Carbon::parse($notice->date)->format('jS M, Y') }}</span>
                            </div>
                        @endforeach
                    </div>
                    <div class="carrow d-flex">
                        <a class="prev" href="#"><i data-feather="arrow-left-circle"></i></a>
                        <a class="next" href="#"><i data-feather="arrow-right-circle"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-md-4" data-aos="fade-up">
                <a href='{{ route('admission') }}' >
                    <div class="card text-center h-100 overlay-card">
                        <div class="badge-new">New</div>
                        <div class="card-body p-2">
                            <img src="https://credozen.in/bright/application/public/Front/images/online-admission.jpg" class="w-100 rounded" alt="">
                            <h6 class="mb-0 text-uppercase overlay-title">Online Admission</h6>
                        </div>
                    </div> 
                </a>
            </div>

            <div class="col-md-4" data-aos="fade-up">
                <a href="{{ route('contact_us') }}" >
                    <div class="card text-center h-100 overlay-card">
                        <div class="badge-new" style="background:#7A8B6F !important;">Contact</div>
                        <div class="card-body p-2">
                            <img src="https://credozen.in/bright/application/public/Front/images/fee-payment.jpg" class="w-100 rounded" alt="">
                            <h6 class="mb-0 text-uppercase overlay-title">Get In Touch</h6>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>

  <div class="container">
        <div class="row">
            <div class="col-md-12">
                
                <!-- President Message Section with Gradient and Glassmorphism -->
                <div class="from-home bg-wow president-card">
                    
                    <!-- NEW: Aesthetic Sun Icon (Top Left) -->
                    <div class="aesthetic-icon" style="top: -20px; left: -20px; opacity: 0.7; transform: rotate(-15deg);">
                        <svg width="100" height="100" viewBox="0 0 100 100" fill="none" stroke="#D4C5B9" stroke-width="2" xmlns="http://www.w3.org/2000/svg">
                          <circle cx="50" cy="50" r="15"/>
                          <path d="M50 20 V5 M50 95 V80 M20 50 H5 M95 50 H80 M28 28 L18 18 M82 82 L72 72 M28 72 L18 82 M82 28 L72 18"/>
                        </svg>
                    </div>

                    <!-- NEW: Aesthetic Botanical Branch Icon (Right Side) -->
                    <div class="aesthetic-icon" style="bottom: 10%; right: -2%; opacity: 0.6; z-index: 0; transform: rotate(-20deg) scale(1.2);">
                        <svg width="100" height="150" viewBox="0 0 50 100" fill="none" stroke="#7A8B6F" stroke-width="1.5" xmlns="http://www.w3.org/2000/svg">
                            <path d="M25 100 Q20 50, 45 0"/>
                            <path d="M22 80 Q10 75, 5 65 Q15 65, 20 75 Z" fill="#E8E5DC"/>
                            <path d="M28 75 Q40 70, 45 60 Q35 60, 30 70 Z" fill="#E8E5DC"/>
                            <path d="M23 60 Q10 55, 5 45 Q15 45, 20 55 Z" fill="#E8E5DC"/>
                            <path d="M27 55 Q40 50, 45 40 Q35 40, 30 50 Z" fill="#E8E5DC"/>
                            <path d="M24 40 Q10 35, 5 25 Q15 25, 20 35 Z" fill="#E8E5DC"/>
                        </svg>
                    </div>

                    <div class="row position-relative" style="z-index: 2;">
                        <div class="col-lg-10 col-xl-9 mx-auto" data-aos="fade-up">
                            <div class="in-cnt-pd text-center">

                                <div class="text-center">
                                    <!-- Custom Gradient Pill Badge -->
                                    <div class="president-kicker-badge">
                                      <span class="dot"></span> FOUNDER'S MESSAGE
                                    </div>
                                   
                                    <h3 class="d-block president-name-new">Nazrath A. G</h3>
                                </div>
                                
                                <!-- Glassmorphism Quote Box -->
                                <div class="president-text-box mt-4 position-relative text-center" style="box-shadow: 0 15px 40px rgba(0,0,0,0.03);">
                                    <!-- Beautiful Orange Butterfly (Top Left Corner) -->
                                    <div class="aesthetic-icon" style="top: -30px; left: -20px; opacity: 0.95; z-index: 10; pointer-events: none; animation: float 5s ease-in-out infinite;">
                                        <svg class="colorful-butterfly" width="65" height="65" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" style="overflow: visible; transform: rotate(-25deg);">
                                            <defs>
                                              <linearGradient id="wingGradPres" x1="0%" y1="0%" x2="100%" y2="100%">
                                                <stop offset="0%" stop-color="#FFB347" />
                                                <stop offset="60%" stop-color="#FF7B00" />
                                                <stop offset="100%" stop-color="#CC4400" />
                                              </linearGradient>
                                              <linearGradient id="wingGradLowerPres" x1="0%" y1="0%" x2="100%" y2="100%">
                                                <stop offset="0%" stop-color="#FFD180" /> 
                                                <stop offset="100%" stop-color="#FF8C00" />
                                              </linearGradient>
                                            </defs>
                                            <g style="transform-origin: 50px 50px;">
                                              <path d="M50 50 C 20 20, 5 25, 10 40 C 15 60, 40 60, 50 50" fill="url(#wingGradPres)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                                              <path d="M50 50 C 35 35, 20 35, 15 42" stroke="#222" stroke-width="1.5" fill="none"/>
                                              <path d="M50 50 C 25 45, 15 50, 15 50" stroke="#222" stroke-width="1.5" fill="none"/>
                                              <path d="M50 50 C 30 65, 20 85, 35 90 C 45 95, 50 70, 50 50" fill="url(#wingGradLowerPres)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                                              <path d="M50 50 C 40 70, 30 80, 28 85" stroke="#222" stroke-width="1.5" fill="none"/>
                                              <circle cx="12" cy="40" r="1.5" fill="#FFF"/>
                                              <circle cx="17" cy="53" r="1.5" fill="#FFF"/>
                                              <circle cx="30" cy="86" r="1.5" fill="#FFF"/>
                                              <circle cx="40" cy="89" r="1.5" fill="#FFF"/>
                                            </g>
                                            <g style="transform-origin: 50px 50px;">
                                              <path d="M50 50 C 80 20, 95 25, 90 40 C 85 60, 60 60, 50 50" fill="url(#wingGradPres)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                                              <path d="M50 50 C 65 35, 80 35, 85 42" stroke="#222" stroke-width="1.5" fill="none"/>
                                              <path d="M50 50 C 75 45, 85 50, 85 50" stroke="#222" stroke-width="1.5" fill="none"/>
                                              <path d="M50 50 C 70 65, 80 85, 65 90 C 55 95, 50 70, 50 50" fill="url(#wingGradLowerPres)" stroke="#222" stroke-width="3" stroke-linejoin="round"/>
                                              <path d="M50 50 C 60 70, 70 80, 72 85" stroke="#222" stroke-width="1.5" fill="none"/>
                                              <circle cx="88" cy="40" r="1.5" fill="#FFF"/>
                                              <circle cx="83" cy="53" r="1.5" fill="#FFF"/>
                                              <circle cx="70" cy="86" r="1.5" fill="#FFF"/>
                                              <circle cx="60" cy="89" r="1.5" fill="#FFF"/>
                                            </g>
                                            <rect x="47" y="38" width="6" height="24" rx="3" fill="#333"/>
                                            <circle cx="50" cy="35" r="4" fill="#333"/>
                                            <path d="M 48 35 Q 40 20 35 15 M 52 35 Q 60 20 65 15" stroke="#333" stroke-width="2" fill="none" stroke-linecap="round"/>
                                        </svg>
                                    </div>
                                    
                                    <!-- Replaced the SVG quote with elegant serif text quote to match the image -->
                                    <div style="font-family: 'Playfair Display', serif; font-size: 5rem; color: #7A8B6F; opacity: 0.4; line-height: 0; margin-bottom: 30px; margin-top: 10px; text-align: center;">&ldquo;</div>
                                    
                                    <div class="president-quote-new" style="text-align: justify; word-spacing: -1px; hyphens: auto;">
                                        <p style="text-align: justify;">As both a Montessori educator and a parent, I longed to find a truly authentic Montessori environment for my own children. One that embraced the philosophy in its truest sense. When I couldn't find the experience I was searching for, I decided to create it.</p>
                                        <p style="text-align: justify;">For many years, I had the privilege of leading Little Angels and when its unexpected closure brought that chapter to an end, I knew the journey wasn't over.</p>
                                        <p style="text-align: justify;">After years of study, research, and careful planning, Bright Beginnings Montessori was born; a thoughtfully prepared environment created to offer children an authentic Montessori experience where they can learn, grow, and flourish.</p>
                                        <p class="mb-0 mt-4" style="font-family: 'Playfair Display', serif; font-size: 1.15rem; font-style: italic; color: #8A6D96; font-weight: 500; text-align: center; word-spacing: normal;">Come and experience the joy of authentic Montessori. We look forward to welcoming you.</p>
                                    </div>
                                    
                                    <div class="mt-4 pt-3 border-top d-flex justify-content-center" style="border-color: rgba(168, 159, 145, 0.3) !important;">
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="script-font" style="font-size: 2.2rem; color: #9B6AAB;">Nazrath</span>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#7A8B6F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="margin-top: 5px;">
                                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                                            </svg>
                                        </div>
                                    </div>    
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!--ENVIRONMENTS-->
<section class="facilities section-100 facilities-enhanced" id='fclty'>
    <!-- Geometric Pyramid Icon Background -->
    <div class="aesthetic-icon" style="top: 20px; right: 5%; opacity: 0.6; z-index: 0;">
      <svg width="80" height="120" viewBox="0 0 100 150" fill="none" stroke="#7A8B6F" stroke-width="2" xmlns="http://www.w3.org/2000/svg">
        <path d="M50 20 L20 80 L80 80 Z"/>
        <path d="M50 20 L50 80"/>
        <path d="M50 80 L80 80 L60 90 L30 90 Z"/>
        <circle cx="50" cy="70" r="10" fill="#E8E5DC"/>
        <circle cx="50" cy="50" r="8" fill="#E8E5DC"/>
        <circle cx="50" cy="35" r="5" fill="#E8E5DC"/>
      </svg>
    </div>

    <!-- ENHANCEMENT: Wooden Stacking Block Icon (Left Side, Matches provided image) -->
    <div class="aesthetic-icon" style="top: 20%; left: -20px; opacity: 0.95; z-index: 1;">
      <svg width="80" height="120" viewBox="0 0 80 120" fill="none" xmlns="http://www.w3.org/2000/svg">
        <!-- Bottom Block -->
        <rect x="15" y="85" width="50" height="25" rx="2" fill="#A89F91" opacity="0.9"/>
        <!-- Second Block -->
        <rect x="20" y="60" width="40" height="25" rx="2" fill="#D4C5B9" opacity="0.9"/>
        <!-- Third Block -->
        <rect x="25" y="35" width="30" height="25" rx="2" fill="#D4C5B9" opacity="0.7"/>
        <!-- Top Triangle Block -->
        <path d="M25 35 L40 15 L55 35 Z" fill="#E8E5DC" opacity="0.9"/>
        <!-- Little star/sparkle for detail -->
        <path d="M65 15 L67 20 L72 22 L67 24 L65 29 L63 24 L58 22 L63 20 Z" fill="#D4C5B9"/>
      </svg>
    </div>

    <div class="facilities-cards">
        <div class="container">
            <div class="row d-md-flex d-flex align-items-center">
                <div class="col-12 text-center mb-4" data-aos="fade-up">
                    <h1 class="pb-2 mt-0 section-heading" style="text-transform: uppercase; color: #8A6D96; letter-spacing: 2px;">Environments</h1>
                    <a href="{{url('facilities')}}" class="main-btn mt-3">View All</a>
                </div>
                <div class="col-md-12">
                    <div class="slick slick-3 mb-4">
                        @foreach ($facilities as $g_index => $facility)
                            <div class="ne h-100">
                                <div class="item efx h-100" data-aos="fade-up" data-aos-delay="{{ $g_index * 100 }}">
                                    <div class="efx-img"><img src="{{ url('upload/' . $facility->img) }}" alt=""></div>
                                    <div class="ov-content">
                                        <div class="details ">
                                            <h5>{{ $facility->title ?? $facility->name ?? '' }}</h5>
                                            <p class="mb-0">
                                                {{$facility->small_description}}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    
                    <!--<div class="carrow d-flex justify-content-center mt-3 gap-3">-->
                    <!--    <a class="prev" href="#"><i data-feather="arrow-left-circle"></i></a>-->
                    <!--    <a class="next" href="#"><i data-feather="arrow-right-circle"></i></a>-->
                    <!--</div>-->
                </div>
            </div>
        </div>
    </div>
</section>

<!--TIMELINE-->
<section class="calendar pt-60 pb-60 calendar-enhanced">
    <!-- Soft Sage Organic Blob Background -->
    <div class="aesthetic-icon" aria-hidden="true" style="top: -20%; right: -10%; z-index: -1;">
      <svg width="400" height="400" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
        <path fill="#F7F5F0" opacity="0.6" d="M51.9,-75.4C66.8,-66.1,78.2,-50.2,85.1,-32.7C92,-15.2,94.4,3.9,89.5,21.3C84.6,38.7,72.4,54.4,57.1,65.2C41.8,76,23.4,81.9,4.4,75.9C-14.6,69.9,-33.9,52,-48.5,38C-63.1,24,-73.1,14,-78.9,-0.6C-84.7,-15.2,-86.3,-34.4,-77.3,-48.9C-68.3,-63.4,-48.7,-73.2,-31.6,-77.9C-14.5,-82.6,0.1,-82.2,16.5,-77.1C32.9,-72.1,47,-64.7,51.9,-75.4Z" transform="translate(100 100)" />
      </svg>
    </div>

    <!-- Montessori Floral Sprig Icon -->
    <div class="aesthetic-icon position-absolute" style="bottom: 5%; right: 25%; opacity: 0.8; z-index: 0;">
      <svg width="60" height="90" viewBox="0 0 60 90" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M30 90 Q30 40 10 10" stroke="#7A8B6F" stroke-width="1.5" fill="none"/>
        <path d="M30 65 Q40 60 45 50 Q35 45 28 55 Z" fill="#E8E5DC"/>
        <path d="M26 45 Q15 40 10 30 Q20 25 28 35 Z" fill="#D4C5B9"/>
        <path d="M22 25 Q35 20 40 10 Q30 5 20 15 Z" fill="#E8E5DC"/>
        <circle cx="10" cy="10" r="4" fill="#A89F91"/>
      </svg>
    </div>

    <div class="container position-relative" style="z-index: 2;">
        <div class="row">
            <div class="col-md-6 mb-4" data-aos="fade-left">
                <div class="event-cnd"> 
                     <span class="section-kicker mb-3 d-inline-flex align-items-center gap-2">
                        <!-- Montessori Flower Icon -->
                        <svg width="20" height="30" viewBox="0 0 50 80" fill="none" stroke="#7A8B6F" stroke-width="3" xmlns="http://www.w3.org/2000/svg">
                          <path d="M25 80 V30"/>
                          <path d="M25 50 Q10 40, 15 60" fill="#E8E5DC"/>
                          <path d="M25 55 Q40 45, 35 65" fill="#E8E5DC"/>
                          <circle cx="25" cy="25" r="7" fill="#D4C5B9" stroke="none"/>
                          <path d="M25 18 A10 10 0 0 1 25 -2 A10 10 0 0 1 25 18" fill="#F7F5F0" stroke="#A89F91"/>
                          <path d="M18 25 A10 10 0 0 1 -2 25 A10 10 0 0 1 18 25" fill="#F7F5F0" stroke="#A89F91"/>
                          <path d="M32 25 A10 10 0 0 0 52 25 A10 10 0 0 0 32 25" fill="#F7F5F0" stroke="#A89F91"/>
                          <path d="M25 32 A10 10 0 0 0 25 52 A10 10 0 0 0 25 32" fill="#F7F5F0" stroke="#A89F91"/>
                        </svg>
                        Event Calendar
                     </span>
                    <div class="in-cnd">
                        <div id="calendar"></div>
                    </div>
                </div>
            </div>
 <div class="col-md-6 mb-4 aos-init aos-animate" data-aos="fade-right">
                <div class="calendar-hero" style="max-height: 450px; height: 100%; border-radius: 15px; overflow: hidden;">
                   <img src="{{ asset('Front/images/children-playing.jpg') }}" alt="" style="width: 100%; height: 100%; object-fit: cover;">
                    <div class="calendar-hero-ov">
                        <span class="calendar-hero-chip"><span class="dot" aria-hidden="true"></span>Highlights</span>
                        <h3 class="calendar-hero-title m-0">A year full of learning, sports &amp; culture</h3>
                        <p class="calendar-hero-sub m-0 text-white">See what's next on the event calendar and never miss a key date.</p>
                    </div>
                </div>
            </div>
    </div>
    </div>
</section>

<!--EXPLORE-->
<section class="explore section-100 explore-enhanced position-relative" id='gallery-sec'>
    
    <!-- NEW: Highly Realistic Sage Green Watercolor Butterfly (Matching Reference Image) -->
    <div class="aesthetic-icon" style="top: 10px; right: 20%; opacity: 0.95; z-index: 1; transform: rotate(15deg);">
      <svg class="montessori-butterfly-sage" width="70" height="70" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <filter id="sageBfShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="4" stdDeviation="3" flood-color="#7A8B6F" flood-opacity="0.25"/>
          </filter>
          <linearGradient id="sageTopWing" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#D0CDB8" />
            <stop offset="60%" stop-color="#A5B095" />
            <stop offset="100%" stop-color="#7A8B6F" />
          </linearGradient>
          <linearGradient id="sageTopWingRight" x1="100%" y1="100%" x2="0%" y2="0%">
            <stop offset="0%" stop-color="#D0CDB8" />
            <stop offset="60%" stop-color="#A5B095" />
            <stop offset="100%" stop-color="#7A8B6F" />
          </linearGradient>
          <linearGradient id="sageBotWing" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#B2BCA1" />
            <stop offset="100%" stop-color="#8F9E82" />
          </linearGradient>
          <linearGradient id="sageBotWingRight" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#B2BCA1" />
            <stop offset="100%" stop-color="#8F9E82" />
          </linearGradient>
        </defs>

        <g filter="url(#sageBfShadow)">
          <!-- Top Left Wing (More Angular/Sweeping) -->
          <path d="M 58 52 C 35 30, 10 15, 12 40 C 15 65, 30 75, 58 58 Z" fill="url(#sageTopWing)" stroke="#6A7A5F" stroke-width="1.2" stroke-linejoin="round"/>
          <!-- Top Right Wing -->
          <path d="M 62 52 C 85 30, 110 15, 108 40 C 105 65, 90 75, 62 58 Z" fill="url(#sageTopWingRight)" stroke="#6A7A5F" stroke-width="1.2" stroke-linejoin="round"/>
          
          <!-- Bottom Left Wing (Slightly Elongated) -->
          <path d="M 58 58 C 45 70, 25 95, 42 105 C 55 110, 60 75, 58 58 Z" fill="url(#sageBotWing)" stroke="#6A7A5F" stroke-width="1.2" stroke-linejoin="round"/>
          <!-- Bottom Right Wing -->
          <path d="M 62 58 C 75 70, 95 95, 78 105 C 65 110, 60 75, 62 58 Z" fill="url(#sageBotWingRight)" stroke="#6A7A5F" stroke-width="1.2" stroke-linejoin="round"/>
          
          <!-- Wing Veins (Left) -->
          <path d="M 58 56 Q 35 40 18 35 M 58 56 Q 35 55 20 52 M 58 60 Q 45 75 35 90 M 58 60 Q 50 85 45 100" stroke="#5A6A4F" stroke-width="0.8" opacity="0.6"/>
          <!-- Wing Veins (Right) -->
          <path d="M 62 56 Q 85 40 102 35 M 62 56 Q 85 55 100 52 M 62 60 Q 75 75 85 90 M 62 60 Q 70 85 75 100" stroke="#5A6A4F" stroke-width="0.8" opacity="0.6"/>
          
          <!-- Wing Edge Dots (Left) -->
          <circle cx="20" cy="40" r="1.5" fill="#FAF5F0" opacity="0.8"/>
          <circle cx="25" cy="55" r="1.2" fill="#FAF5F0" opacity="0.8"/>
          <!-- Wing Edge Dots (Right) -->
          <circle cx="100" cy="40" r="1.5" fill="#FAF5F0" opacity="0.8"/>
          <circle cx="95" cy="55" r="1.2" fill="#FAF5F0" opacity="0.8"/>
          
          <!-- Body -->
          <rect x="58" y="42" width="4" height="30" rx="2" fill="#4A5243"/>
          <circle cx="60" cy="40" r="3.5" fill="#4A5243"/> <!-- Head -->
          
          <!-- Antennae -->
          <path d="M 59 38 Q 50 20 40 15 M 61 38 Q 70 20 80 15" stroke="#4A5243" stroke-width="1.5" fill="none" stroke-linecap="round"/>
          <!-- Antennae Knobs -->
          <circle cx="40" cy="15" r="1.5" fill="#4A5243"/>
          <circle cx="80" cy="15" r="1.5" fill="#4A5243"/>
        </g>
      </svg>
    </div>
    
    <!-- ENHANCEMENT: Cute Watercolor Bunny Icon -->
    <div class="aesthetic-icon" style="bottom: -15px; left: 5%; opacity: 0.95; z-index: 2;">
        <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
          <!-- Back Ear -->
          <path d="M60 40 Q75 10 85 15 Q80 35 65 45" fill="#A89F91" opacity="0.6"/>
          <!-- Back Leg -->
          <path d="M65 70 Q75 90 85 88" stroke="#A89F91" stroke-width="8" stroke-linecap="round" opacity="0.6"/>
          <!-- Body -->
          <path d="M25 80 C10 80 15 55 35 45 C55 35 75 50 75 70 C75 85 40 85 25 80 Z" fill="#D4C5B9" opacity="0.9"/>
          <!-- Front Ear -->
          <path d="M50 43 Q60 5 70 10 Q70 30 55 48" fill="#D4C5B9" opacity="0.9"/>
          <!-- Head -->
          <circle cx="40" cy="50" r="18" fill="#D4C5B9" opacity="0.9"/>
          <!-- Snout -->
          <circle cx="25" cy="53" r="7" fill="#E8E5DC" opacity="0.9"/>
          <circle cx="20" cy="51" r="2" fill="#A89F91"/>
          <!-- Eye -->
          <circle cx="33" cy="46" r="2" fill="#4A4A4A"/>
          <!-- Front Legs -->
          <path d="M30 75 Q30 95 40 92" stroke="#D4C5B9" stroke-width="8" stroke-linecap="round"/>
          <path d="M55 70 Q55 90 65 88" stroke="#D4C5B9" stroke-width="8" stroke-linecap="round"/>
          <!-- Tail -->
          <circle cx="78" cy="65" r="7" fill="#F7F5F0" opacity="0.9"/>
          <circle cx="82" cy="69" r="5" fill="#F7F5F0" opacity="0.7"/>
        </svg>
    </div>

    <div class="container">
        <div class="row d-md-flex d-flex align-items-center">
           <div class="col-md-6 col-12 text-center text-md-start" data-aos="fade-right">
                <span class="section-kicker d-inline-flex align-items-center gap-2 justify-content-center justify-content-md-start">
                  <!-- Montessori Stacking Blocks Icon -->
                  <svg width="20" height="30" viewBox="0 0 40 70" fill="none" stroke="#A89F91" stroke-width="2" xmlns="http://www.w3.org/2000/svg">
                    <rect x="5" y="50" width="30" height="15" fill="#D4C5B9" rx="2"/>
                    <rect x="10" y="35" width="20" height="15" fill="#E8E5DC" rx="2"/>
                    <rect x="15" y="20" width="10" height="15" fill="#F7F5F0" rx="2"/>
                    <polygon points="10,20 30,20 20,5" fill="#7A8B6F" stroke-linejoin="round"/>
                  </svg>
                  Explore
                </span>
                <h1 class="pb-3 mt-0 section-heading" data-aos="fade-right" data-aos-delay="50">Gallery</h1>
            </div>
            <div class="col-md-6 col-12 text-center text-md-end mb-4 mb-md-0" data-aos="fade-left">
                <a href="{{ route('photo_gallery') }}" class="main-btn">View All</a>
            </div>

            <div class="col-md-12">
                <div class="row nopad">
                    @foreach ($galleries as $g_index => $gallery)
                        <div class="col-md-3" data-aos="fade-up" data-aos-delay=" @if ($g_index == 0) 50 @elseif($g_index == 1)100 @elseif($g_index == 2)200 @else 250 @endif">
                            <div class="hg-img efx position-relative gallery-tile"><a href="#"><img src="{{ url('upload/' . $gallery->image) }}" alt="">
                                    <span class="w-100 gallery-label" >{{ $gallery->title }}</span>
                                </a>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>


<section class="facilities news-events-enhanced">
    <!-- Flower moved to heading container -->
    
    <!-- ENHANCEMENT: Soft Watercolor Cloud Icons with Up & Down Float Animation (Updated to Correct Cloud Shape) -->
    <div class="aesthetic-icon" style="top: 15%; right: 5%; opacity: 0.85; z-index: 0; animation: float 6s ease-in-out infinite;">
      <svg width="100" height="60" viewBox="0 0 24 24" fill="#E8E5DC" xmlns="http://www.w3.org/2000/svg">
        <path d="M17.5 19C19.9853 19 22 16.9853 22 14.5C22 12.1331 20.1765 10.1915 17.8631 10.0159C17.3828 6.59829 14.454 4 11 4C7.54602 4 4.61717 6.59829 4.13689 10.0159C1.82346 10.1915 0 12.1331 0 14.5C0 16.9853 2.01472 19 4.5 19H17.5Z"/>
      </svg>
    </div>

    <div class="container">
        <div class="row d-md-flex d-flex ">
            <div class="col-md-6 col-12 text-center text-md-start">
                <div class="pb-3 mt-0 in-cnt-pd position-relative" data-aos="fade-right">
                    <!-- ENHANCEMENT: Montessori Watercolor Pink Floral Sprig -->
                    <div class="aesthetic-icon news-flower-icon">
                      <svg class="montessori-flower" width="120" height="180" viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <defs>
                          <filter id="flowerShadow" x="-20%" y="-20%" width="140%" height="140%">
                            <feDropShadow dx="0" dy="4" stdDeviation="3" flood-color="#887868" flood-opacity="0.2"/>
                          </filter>
                          <linearGradient id="stemGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#95A384" />
                            <stop offset="100%" stop-color="#7A8B6F" />
                          </linearGradient>
                          <linearGradient id="leafGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#A5B095" />
                            <stop offset="100%" stop-color="#7A8B6F" />
                          </linearGradient>
                          <radialGradient id="petalGrad1" cx="30%" cy="30%" r="70%">
                            <stop offset="0%" stop-color="#F9E4E0" />
                            <stop offset="60%" stop-color="#EBC4BB" />
                            <stop offset="100%" stop-color="#DCA89E" />
                          </radialGradient>
                          <radialGradient id="petalGrad2" cx="30%" cy="30%" r="70%">
                            <stop offset="0%" stop-color="#FDF2EF" />
                            <stop offset="70%" stop-color="#F1D1C6" />
                            <stop offset="100%" stop-color="#EBC4BB" />
                          </radialGradient>
                          <radialGradient id="centerGrad" cx="40%" cy="40%" r="60%">
                            <stop offset="0%" stop-color="#E3C380" />
                            <stop offset="60%" stop-color="#C59E51" />
                            <stop offset="100%" stop-color="#9E7831" />
                          </radialGradient>
                        </defs>

                        <g filter="url(#flowerShadow)">
                          <!-- Main Stem -->
                          <path d="M 60 70 Q 55 120 40 180" stroke="url(#stemGrad)" stroke-width="2.5" fill="none" stroke-linecap="round"/>
                          <!-- Side Stem 1 -->
                          <path d="M 55 100 Q 75 90 90 70" stroke="url(#stemGrad)" stroke-width="1.5" fill="none" stroke-linecap="round"/>
                          <!-- Side Stem 2 -->
                          <path d="M 52 130 Q 35 120 20 100" stroke="url(#stemGrad)" stroke-width="1.5" fill="none" stroke-linecap="round"/>
                          <!-- Side Stem 3 -->
                          <path d="M 45 160 Q 65 155 75 140" stroke="url(#stemGrad)" stroke-width="1.5" fill="none" stroke-linecap="round"/>
                          
                          <!-- Leaves on Main Stem -->
                          <path d="M 55 100 Q 65 120 52 130 Q 45 110 55 100 Z" fill="url(#leafGrad)"/>
                          <path d="M 45 160 Q 30 145 42 130 Q 55 145 45 160 Z" fill="url(#leafGrad)"/>
                          
                          <!-- Leaves on Side Stem 1 -->
                          <path d="M 70 85 Q 85 95 95 85 Q 85 75 70 85 Z" fill="url(#leafGrad)"/>
                          <path d="M 80 75 Q 90 60 100 65 Q 95 80 80 75 Z" fill="url(#leafGrad)"/>
                          
                          <!-- Leaves on Side Stem 2 -->
                          <path d="M 35 110 Q 20 120 10 110 Q 20 100 35 110 Z" fill="url(#leafGrad)"/>
                          <path d="M 25 105 Q 15 90 5 95 Q 10 110 25 105 Z" fill="url(#leafGrad)"/>
                          
                          <!-- Leaves on Side Stem 3 -->
                          <path d="M 60 150 Q 80 160 85 145 Q 70 140 60 150 Z" fill="url(#leafGrad)"/>

                          <!-- Main Flower (Top) -->
                          <g transform="translate(60, 65)">
                            <!-- Back Petals -->
                            <path d="M 0 0 C -25 -15, -15 -35, -5 -35 C 5 -35, 10 -25, 0 0 Z" fill="url(#petalGrad2)"/>
                            <path d="M 0 0 C 15 -25, 35 -15, 35 -5 C 35 5, 25 10, 0 0 Z" fill="url(#petalGrad2)"/>
                            <path d="M 0 0 C 25 15, 15 35, 5 35 C -5 35, -10 25, 0 0 Z" fill="url(#petalGrad2)"/>
                            <path d="M 0 0 C -15 25, -35 15, -35 5 C -35 -5, -25 -10, 0 0 Z" fill="url(#petalGrad2)"/>
                            <!-- Front Petals -->
                            <path d="M 0 0 C -15 -35, 15 -35, 0 0 Z" fill="url(#petalGrad1)"/>
                            <path d="M 0 0 C 35 -15, 35 15, 0 0 Z" fill="url(#petalGrad1)"/>
                            <path d="M 0 0 C 15 35, -15 35, 0 0 Z" fill="url(#petalGrad1)"/>
                            <path d="M 0 0 C -35 15, -35 -15, 0 0 Z" fill="url(#petalGrad1)"/>
                            <!-- Petal details -->
                            <path d="M 0 0 L 0 -15 M 0 0 L 15 0 M 0 0 L 0 15 M 0 0 L -15 0" stroke="#C08479" stroke-width="0.5" opacity="0.6"/>
                            <!-- Center -->
                            <circle cx="0" cy="0" r="6" fill="url(#centerGrad)"/>
                            <circle cx="-2" cy="-2" r="1.5" fill="#FAF5F0" opacity="0.6"/>
                            <circle cx="2" cy="1" r="1" fill="#7A5420" opacity="0.5"/>
                            <circle cx="-1" cy="2" r="1" fill="#7A5420" opacity="0.5"/>
                          </g>
                          
                          <!-- Small Bud (Side Stem 1) -->
                          <g transform="translate(90, 70)">
                            <path d="M 0 0 C 10 -5, 15 -15, 5 -20 C -5 -15, 0 -5, 0 0 Z" fill="url(#petalGrad1)"/>
                            <path d="M 0 0 C -5 0, -10 5, 0 0 Z" fill="#95A384"/>
                            <path d="M 0 0 C 5 0, 10 5, 0 0 Z" fill="#95A384"/>
                          </g>
                        </g>
                      </svg>
                    </div>
                    <span class="section-kicker"><span class="dot" aria-hidden="true"></span>UPDATE</span>
                    <h1 class="section-heading">News &amp; Events</h1>
                </div>
            </div>
            <div class="col-md-6 col-12 text-center text-md-end mb-4 mb-md-0" data-aos="fade-left">
                <a href="{{url('news')}}" class="main-btn">View All</a>
            </div>
            <div class="col-md-12">
                <div class="row g-4">
                    @foreach ($newses as $newse)
                        <div class="col-md-3">
                            <div class="card h-100 border-0" style="border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: transform 0.3s ease, box-shadow 0.3s ease;" onmouseover="this.style.transform='translateY(-8px)'; this.style.boxShadow='0 15px 35px rgba(155, 106, 171, 0.15)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 10px 30px rgba(0,0,0,0.05)';">
                                <div class="news-thumb position-relative" style="height: 200px; overflow: hidden;">
                                    <img src="{{ url('upload/' . $newse->thumb_img) }}" alt="{{ $newse->news_title }}" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                                </div>
                                <div class="card-body news-card d-flex flex-column justify-content-between p-4" style="background-color: #ffffff;">
                                    <div>
                                        <h4 class="mb-2" style="color: #9B6AAB; font-family: 'Playfair Display', serif; font-size: 1.35rem; font-weight: 500; line-height: 1.4;">
                                            {{ $newse->news_title }}
                                        </h4>
                                        <p class="mb-3" style="color: #A89F91; font-family: 'Montserrat', sans-serif; font-size: 0.85rem;">
                                            {{ \Carbon\Carbon::parse($newse->news_date)->format('d m, Y') }}
                                        </p>
                                    </div>
                                    <div class="mt-3">
                                        <a href="{{ route('news_details', $newse->news_slug) }}" class="main-btn text-uppercase" style="font-size: 13px; padding: 10px 25px; width: 100%; text-align: center; letter-spacing: 1px;">READ MORE</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>
</div>{{-- /.bg-grid --}}
@include('front.layouts.footer')

