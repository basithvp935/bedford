<!DOCTYPE html>
<html lang="en">

<head>

    <meta name="description" content="@yield('description')">
    <meta name="keywords" content="" />
    <meta name="author" content="">
    <link rel="canonical" href="#">
    <!--<title>@yield('title')</title>-->
    <title>Bright Beginnings Montessori</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    {{-- Favicon: place early so home / root requests resolve correctly --}}
    <link rel="icon" type="image/png" href="{{ asset('Front/images/logo1.png') }}">
    <link rel="shortcut icon" type="image/png" href="{{ asset('Front/images/logo1.png') }}">
    <link rel="apple-touch-icon" href="{{ asset('Front/images/logo1.png') }}">
    
    <!-- NEW: Elegant Serif & Sans-Serif Fonts for Premium Montessori Aesthetic -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('Front/css/bootstrap.min.css') }}">
    <link href="{{ asset('Front/css/custom.css') }}" rel="stylesheet">
    <link href="{{ asset('Front/css/style.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('Front/css/owl.carousel.min.css') }}">
    <link rel="stylesheet" href="{{ asset('Front/css/owl.theme.default.min.css') }}">
    <link rel="stylesheet" href="{{ asset('Front/css/aos.css') }}">
    <link rel="stylesheet" href="{{ asset('Front/css/jquery.fancybox.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('Front/css/slick.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('Front/css/slick-theme.css') }}" />
    
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="{{ asset('Front/css/toaster.css') }}" type="text/css" rel="stylesheet">
    <link href="{{ asset('Front/css/toast.min.css') }}" type="text/css" rel="stylesheet">
    <link href="{{ asset('Front/css/theme.css') }}" type="text/css" rel="stylesheet">
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" type="text/css" rel="stylesheet">

    <!-- Custom Style for Navbar Font & Topbar Social Icons -->
    <style>
        /* NEW: Apply the modern Sans-Serif font to the Desktop Navbar! */
        .navbar-nav .nav-link {
            font-family: 'Montserrat', sans-serif !important;
            font-weight: 500 !important;
            font-size: 0.85rem !important; /* Clean base size */
            padding-left: 0.6rem !important; /* Tighter default spacing */
            padding-right: 0.6rem !important;
            color: #3C4A3E !important; 
            letter-spacing: 1px;
            transition: color 0.3s ease;
            text-transform: uppercase;
            white-space: nowrap !important;
        }

        .navbar-nav .nav-link:hover, .navbar-nav .dropdown-item:hover {
            color: #9B6AAB   !important; 
        }
        
        .navbar-nav .dropdown-item {
            font-family: 'Montserrat', sans-serif !important; 
            font-weight: 500 !important;
            font-size: 0.85rem !important;
            color: #3C4A3E !important;
            white-space: nowrap !important;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Desktop Admission Button - Earthy Style */
        .desktop-admission-btn {
            background-color: #9B6AAB  !important; 
            background-image: none !important;
            border-color: #b58db4 !important; 
            color: #ffffff !important; 
            border-radius: 30px; 
            padding: 8px 20px !important; /* Slimmer default padding */
            font-weight: 500; 
            font-family: 'Montserrat', sans-serif !important; 
            font-size: 0.85rem !important;
            letter-spacing: 1px;
            text-transform: uppercase;
            box-shadow: 0 4px 15px rgba(181, 141, 180, 0.3);
            white-space: nowrap;
            transition: all 0.3s ease;
        }
        
        .desktop-admission-btn:hover {
            background-color: #9f7b9e !important;
            background-image: none !important;
            border-color: #9f7b9e !important;
            color: #ffffff !important;
        }
        
        /* RESPONSIVE FIX: Prevent navbar items from spilling out on laptop screens (up to 1400px) */
        @media (min-width: 992px) and (max-width: 1400px) {
            .navbar-nav .nav-link {
                font-size: 0.8rem !important; /* Slightly shrink font for laptops */
                padding-left: 0.4rem !important; /* Shrink space between links */
                padding-right: 0.4rem !important;
                letter-spacing: 0.5px;
            }
            .desktop-admission-btn {
                padding: 6px 14px !important; /* Shrink button size */
                font-size: 0.75rem !important;
            }
            .nav-pill {
                padding-left: 1rem !important;
                padding-right: 1rem !important;
            }
            /* Reduce gap between logo and links on laptop */
            .nav-pill > .d-flex {
                gap: 0.5rem !important; 
            }
            .brand img {
                max-height: 40px !important; /* Shrink logo slightly on laptop to save space */
            }
        }
        
        /* NEW: Apply the modern Sans-Serif font to the Mobile Navbar! */
        .offcanvas-body .list-group-item {
            font-family: 'Montserrat', sans-serif !important;
            font-weight: 500 !important;
            color: #3C4A3E !important;
            font-size: 1.1rem !important;
            border-color: rgba(0,0,0,0.05);
            text-transform: uppercase;
        }
        
        .offcanvas-body .list-group-item:hover {
            color: #7A8B6F !important;
            background-color: rgba(122, 139, 111, 0.05);
        }

        /* Topbar Social Button Styles */
        .topbar-social-btn {
            width: 32px; 
            height: 32px; 
            background-color: #ffffff; 
            border-radius: 50%; 
            display: inline-flex; 
            align-items: center; 
            justify-content: center; 
            text-decoration: none; 
            line-height: 36px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08); 
            transition: all 0.3s ease;
            font-size: 0.9rem;
            color: #A89F91; /* Soft Taupe */
        }
        
        /* Official Brand Colors */
        .topbar-social-btn.fb { color: #1877F2; }
        .topbar-social-btn.x { color: #000000; }
        .topbar-social-btn.in { color: #0A66C2; }
        .topbar-social-btn.ig { color: #E4405F; }
        .topbar-social-btn.wa { color: #25D366; }

        /* Turns White with Sage background on Hover */
        .topbar-social-btn:hover {
            background-color: #7A8B6F; 
            color: #ffffff !important;
            transform: translateY(-2px);
        }
        
        /* Language Switcher Button Styling */
        .lang-switcher {
            color: #7A8B6F !important; 
            font-family: 'Montserrat', sans-serif !important;
            font-weight: 600 !important;
            font-size: 1.05rem !important;
            display: flex !important;
            align-items: center;
            gap: 5px;
            padding-right: 0 !important; 
        }
        
        .lang-switcher:hover {
            color: #637359 !important;
        }

        .lang-switcher::after {
            display: none !important; 
        }
        
        .lang-dropdown-menu {
            min-width: 90px !important;
            border-radius: 8px !important;
            margin-top: 10px !important; 
            margin-left: 0px !important; 
            padding: 6px 0 !important;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08) !important;
            border: none !important;
            z-index: 99999 !important;
        }
        
        .lang-dropdown-menu .dropdown-item {
            color: #7A8B6F !important;
            font-size: 0.95rem !important;
            font-weight: 600 !important;
            font-family: 'Montserrat', sans-serif !important;
            text-align: center !important;
            transition: all 0.3s ease;
            padding: 4px 10px !important;
        }
        
        .lang-dropdown-menu .dropdown-item:hover {
            background-color: rgba(122, 139, 111, 0.08) !important;
            color: #637359 !important;
        }
    </style>

</head>

<body>
    
     <header class=" smart-header">
     <style>
         .smart-header {
             width: 100%;
             z-index: 1060;
             background: transparent;
             transition: transform 0.5s cubic-bezier(0.25, 1, 0.5, 1), background-color 0.3s ease;
             will-change: transform;
         }
         .smart-header.is-fixed {
             position: fixed;
             top: 0;
             left: 0;
             transform: translateY(-100%);
             background: transparent;
             pointer-events: none;
         }
         .smart-header.is-fixed .topbar {
             pointer-events: auto;
         }
         .smart-header.is-fixed .nav-pill {
             pointer-events: auto;
             box-shadow: 0 10px 30px rgba(0,0,0,0.08); /* Give the pill a shadow when floating */
         }
         .smart-header.is-fixed.nav-down {
             transform: translateY(0);
         }
         .smart-header.is-fixed.nav-up {
             transform: translateY(-100%);
         }
     </style>
     <script>
         document.addEventListener("DOMContentLoaded", function() {
             var lastScrollTop = 0;
             var header = document.querySelector('.smart-header');
             var delta = 10;

             window.addEventListener('scroll', function() {
                 var st = window.pageYOffset || document.documentElement.scrollTop;
                 
                 if (st > 200) {
                     if (!header.classList.contains('is-fixed')) {
                         header.classList.add('is-fixed');
                     }
                     
                     if (Math.abs(lastScrollTop - st) <= delta) return;
                     
                     if (st > lastScrollTop) {
                         // Scroll Down
                         header.classList.remove('nav-down');
                         header.classList.add('nav-up');
                     } else {
                         // Scroll Up
                         if(st + window.innerHeight < document.body.scrollHeight) {
                             header.classList.remove('nav-up');
                             header.classList.add('nav-down');
                         }
                     }
                 } else {
                     // Top of page
                     header.classList.remove('is-fixed');
                     header.classList.remove('nav-up');
                     header.classList.remove('nav-down');
                 }
                 lastScrollTop = st;
             });
         });
     </script>
      <!-- CRITICAL FIX: Added position: relative and z-index: 1050 to force Topbar to sit ON TOP of the nav-pill below it! -->
      <div style="background: #9b6aab; padding: 3px 0px;">
      <div class="container-xxl topbar d-none d-md-block" style="overflow: visible !important; position: relative; z-index: 1050;">
        <div class="row g-2 align-items-center" style="overflow: visible !important;">
          
          <!-- LEFT SIDE: Email -->
          <div class="col-lg-6">
            <div class="d-flex flex-wrap gap-3 d-md-inline-block d-none">
              <a class="chip text-decoration-none" href="mailto:info@brightbeginningsksa.com" style="color: #fff !important; font-weight: 600; padding: 4px 15px; border-radius: 50px;">
                <!-- Updated icon color to Purple -->
                <i class="bi bi-envelope-fill me-1" style="color: #9B6AAB !important; font-size: 1.1rem;"></i>
                <span style="font-family: 'Montserrat', sans-serif; font-size: 0.9rem;">info@brightbeginningsksa.com</span>
              </a>
            </div>
          </div>
          
          <!-- RIGHT SIDE: Phone + Social Icons -->
          <div class="col-lg-6 col-12">
            <div class="d-flex flex-wrap gap-3 justify-content-lg-end align-items-center">
              
              <!-- Phone Number -->
              <a class="chip d-md-inline-block d-none text-decoration-none" href="tel:+966596003218" style="color: #fff !important; font-weight: 600; margin-right: 0.5rem;  padding: 4px 15px; border-radius: 50px;">
                <!-- Updated icon color to Purple -->
                <i class="bi bi-telephone-fill me-1" style="color: #9B6AAB !important; font-size: 1.1rem;"></i> 
                <span style="font-family: 'Montserrat', sans-serif; font-size: 0.9rem;">+966537901050</span> 
              </a>
              
              <!-- Social Media Icons (With Brand Colors!) -->
              <div class="d-flex gap-2">
                <a href="https://www.facebook.com/littleangelsksa" class="topbar-social-btn fb" target='_blank'><i class="bi bi-facebook"></i></a>
                <!--<a href="#" class="topbar-social-btn x"><i class="bi bi-twitter-x"></i></a>-->
                <!--<a href="#" class="topbar-social-btn in"><i class="bi bi-linkedin"></i></a>-->
                <a href="https://www.instagram.com/brightbeginningsksa?igsh=ZnFsNGdpcDFucnVt" class="topbar-social-btn ig" target='_blank'><i class="bi bi-instagram"></i></a>
                <a href="https://wa.me/966537901050" class="topbar-social-btn wa" target='_blank'><i class="bi bi-whatsapp"></i></a>
              </div>

            </div>
          </div>
          
        </div>
      </div>
</div>
      <!-- Main nav pill -->
      <!-- Added position: relative and a lower z-index (1040) so it explicitly stays UNDER the topbar (1050) -->
      <div class="container-xxl mt-1" style="position: relative; z-index: 1040;">
        <nav class="nav-pill px-3 px-lg-4 py-2">
          <!-- ADJUSTED: gap-1 gap-xl-3 provides more flexibility to prevent spilling -->
          <div class="d-flex align-items-center justify-content-between gap-1 gap-xl-3">
            <a class="brand" href="#">
              <img src="{{ asset('Front/images/logo/logo.png') }}" alt="Brand logo" style="max-height: 45px; max-width: 100%;" />
            </a>

            <button
              class="btn btn-soft d-lg-none"
              type="button"
              data-bs-toggle="offcanvas"
              data-bs-target="#mobileNav"
              aria-controls="mobileNav"
            >
              <i class="bi bi-list me-1"></i>
              Menu
            </button>

            <div class="d-none d-lg-flex align-items-center gap-1">
              <ul class="navbar-nav flex-row align-items-center">
                <li class="nav-item">
                  <a class="nav-link" href="{{ route('main') }}">Home</a>
                </li>
                <li class="nav-item dropdown">
                  <a
                    class="nav-link dropdown-toggle"
                    href="#"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                    >Our center</a
                  >
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="{{ route('about_us') }}">Our Story</a></li>
                    <li><a class="dropdown-item" href="{{route('why-choose-us')}}">Why Choose Us</a></li>
                  </ul>
                </li>
                <!-- CHANGED: Removed the dropdown class, toggle functionality, and sub-menu -->
                <li class="nav-item">
                  <a class="nav-link" href="{{ route('facilities') }}"> ENVIRONMENTS</a>
                </li>
                
                <!-- NEW ITEM ADDED HERE: Our Approach -->
                <li class="nav-item">
                  <a class="nav-link" href="https://credozen.in/bright/the-bright-thread"> OUR APPROACH</a>
                </li>

                 <li class="nav-item dropdown">
                  <a
                    class="nav-link dropdown-toggle"
                    href="#"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                    >Admission</a
                  >
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="{{ route('admissionProcedure') }}">Admission Procedure</a></li>
                    <li><a class="dropdown-item" href="{{ route('admission') }}">Admission Form</a></li>
                  </ul>
                </li>
                <li class="nav-item dropdown">
                  <a
                    class="nav-link dropdown-toggle"
                    href="#"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                    >Gallery</a
                  >
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="{{ route('photo_gallery') }}">Photo Gallery</a></li>
                    <li><a class="dropdown-item" href="{{ route('video_gallery') }}">Video Gallery</a></li>
                  </ul>
                </li>
                 <li class="nav-item">
                  <a class="nav-link" href="{{route('contact_us')}}">Contact Us</a>
                </li>
                <!-- ADDED MISSING DESKTOP LANGUAGE SWITCHER -->
                <li class="nav-item dropdown d-none">
                  <a
                    class="nav-link dropdown-toggle lang-switcher"
                    href="#"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    <i class="bi bi-globe me-1" style="font-size: 1.1rem;"></i>
                    <span id="desktopLangText">EN</span>
                  </a>
                  <ul class="dropdown-menu lang-dropdown-menu">
                    <li>
                      <a
                        class="dropdown-item"
                        href="#"
                        id="desktopLangOption"
                        onclick="switchLanguage(event)"
                        >Arabic</a
                      >
                    </li>
                  </ul>
                </li>
              </ul>
            </div>

            <!-- FIXED ADMISSION BUTTON (Desktop) -->
            <div class="d-none d-lg-flex align-items-center">
              <a
                class="btn cta desktop-admission-btn d-inline-flex align-items-center gap-2"
                href="{{ route('admission') }}"
              >
                Admission<i class="bi bi-arrow-right"></i>
              </a>
            </div>
            
          </div>
        </nav>
      </div>
    </header>

  <!-- Mobile offcanvas -->
  <div class="offcanvas offcanvas-end" tabindex="-1" id="mobileNav" aria-labelledby="mobileNavLabel">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="mobileNavLabel"
        style="color: #3C4A3E; font-family: 'Playfair Display', serif; font-weight: 600;">
        Menu
      </h5>
      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <div class="d-flex align-items-center gap-3 mb-3">
        <img src="{{ asset('Front/images/logo/logo.png') }}" alt="Brand logo" style="height: 34px; width: auto" />
      </div>
      <div class="list-group">
        <a class="list-group-item list-group-item-action" href="{{ route('main') }}">Home</a>
        
        <!-- Mobile Our Center Dropdown -->
        <a class="list-group-item list-group-item-action dropdown-toggle" data-bs-toggle="collapse" href="#mobileOurCenterCollapse" role="button" aria-expanded="false" aria-controls="mobileOurCenterCollapse">Our Center</a>
        <div class="collapse" id="mobileOurCenterCollapse">
          <a class="list-group-item list-group-item-action border-0 ps-4 bg-light" href="{{ route('about_us') }}" style="font-family: 'Montserrat', sans-serif !important; font-size: 0.9rem !important;">Our Story</a>
          <a class="list-group-item list-group-item-action border-0 ps-4 bg-light" href="{{ route('why-choose-us') }}" style="font-family: 'Montserrat', sans-serif !important; font-size: 0.9rem !important;">Why Choose Us</a>
        </div>

        <a class="list-group-item list-group-item-action" href="{{ route('facilities') }}">Environments</a>
        
        <a class="list-group-item list-group-item-action" href="https://credozen.in/bright/the-bright-thread">Our Approach</a>

        <!-- Mobile Admission Dropdown -->
        <a class="list-group-item list-group-item-action dropdown-toggle" data-bs-toggle="collapse" href="#mobileAdmissionCollapse" role="button" aria-expanded="false" aria-controls="mobileAdmissionCollapse">Admission</a>
        <div class="collapse" id="mobileAdmissionCollapse">
          <a class="list-group-item list-group-item-action border-0 ps-4 bg-light" href="{{ route('admissionProcedure') }}" style="font-family: 'Montserrat', sans-serif !important; font-size: 0.9rem !important;">Admission Procedure</a>
          <a class="list-group-item list-group-item-action border-0 ps-4 bg-light" href="{{ route('admission') }}" style="font-family: 'Montserrat', sans-serif !important; font-size: 0.9rem !important;">Admission Form</a>
        </div>
        
        <!-- Mobile Gallery Dropdown -->
        <a class="list-group-item list-group-item-action dropdown-toggle" data-bs-toggle="collapse" href="#mobileGalleryCollapse" role="button" aria-expanded="false" aria-controls="mobileGalleryCollapse">Gallery</a>
        <div class="collapse" id="mobileGalleryCollapse">
          <a class="list-group-item list-group-item-action border-0 ps-4 bg-light" href="{{ route('photo_gallery') }}" style="font-family: 'Montserrat', sans-serif !important; font-size: 0.9rem !important;">Photo Gallery</a>
          <a class="list-group-item list-group-item-action border-0 ps-4 bg-light" href="{{ route('video_gallery') }}" style="font-family: 'Montserrat', sans-serif !important; font-size: 0.9rem !important;">Video Gallery</a>
        </div>
        
        <a class="list-group-item list-group-item-action" href="{{ route('contact_us') }}">Contact Us</a>
        
        <!-- Mobile Language Dropdown -->
        <a class="list-group-item list-group-item-action d-flex align-items-center gap-2 dropdown-toggle d-none" data-bs-toggle="collapse" href="#mobileLangCollapse" role="button" aria-expanded="false" aria-controls="mobileLangCollapse" style="color: #7A8B6F !important; font-family: 'Montserrat', sans-serif !important; font-weight: 600 !important;">
          <i class="bi bi-globe" style="font-size: 1.2rem;"></i> <span id="mobileLangText">EN</span> <i class="bi bi-chevron-down ms-auto" style="font-size: 0.85rem;"></i>
        </a>
        <div class="collapse d-none" id="mobileLangCollapse">
          <a class="list-group-item list-group-item-action border-0 ps-5 bg-light" href="#" style="color: #7A8B6F !important; font-family: 'Montserrat', sans-serif !important; font-weight: 500 !important; font-size: 0.9rem !important;" id="mobileLangOption" onclick="switchLanguage(event)">Arabic</a>
        </div>
        
      </div>
      
      <!-- FIXED ADMISSION BUTTON (Mobile) -->
      <div class="d-grid gap-2 mt-3">
        <a class="btn cta text-center" 
           style="background-color: #9B6AAB !important; background-image: none !important; border-color: #9B6AAB !important; color: #ffffff !important; border-radius: 50px; padding: 12px; font-weight: 500; font-family: 'Montserrat', sans-serif; letter-spacing: 1px; text-transform: uppercase; box-shadow: 0 4px 15px rgba(181, 141, 180, 0.3);" 
           href="{{ route('admission') }}">Admission</a>
      </div>
      
    </div>
  </div>
   
    @php
    $academic_calendar = App\Models\HomePage::find(1);
    @endphp

    <!-- JS script to handle visual language swapping! -->
    <script>
        function switchLanguage(e) {
            e.preventDefault(); // Prevent page reload
            
            // Get elements
            const desktopText = document.getElementById('desktopLangText');
            const desktopOption = document.getElementById('desktopLangOption');
            const mobileText = document.getElementById('mobileLangText');
            const mobileOption = document.getElementById('mobileLangOption');
            
            if (desktopText && desktopText.innerText.trim() === 'EN') {
                // Switch to Arabic View
                if(desktopText) desktopText.innerText = 'AR';
                if(desktopOption) desktopOption.innerText = 'English';
                if(mobileText) mobileText.innerText = 'AR';
                if(mobileOption) mobileOption.innerText = 'English';
            } else {
                // Switch back to English View
                if(desktopText) desktopText.innerText = 'EN';
                if(desktopOption) desktopOption.innerText = 'Arabic';
                if(mobileText) mobileText.innerText = 'EN';
                if(mobileOption) mobileOption.innerText = 'Arabic';
            }
        }
    </script>
</body>
</html>
