@section('title', 'Admission Form | Bright Beginnings Montessori')
@section('admission', 'active')
@include('front.layouts.header')

<!-- Flatpickr Custom Date Picker CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

<!-- Full Width Fixed Banner -->
<section class="position-relative" style="
    background: url('{{ asset('Front/images/brightban.jpg') }}') center top / cover no-repeat !important;
    width: 100%; 
    height: 450px !important;
    margin-top: 0 !important;
    margin-bottom: 0 !important;
    border: none !important;
    overflow: hidden;
    background-attachment:fixed
">
</section>

<!-- Custom Styles for Premium Admission Form -->
<style>
    .admission-form-wrapper {
        background-color: #f4faff;
        background-image: 
            linear-gradient(rgba(13, 190, 185, 0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(13, 190, 185, 0.04) 1px, transparent 1px);
        background-size: 40px 40px;
        padding-top: 5rem;
        padding-bottom: 5rem;
    }

    .premium-form-container {
        background: #ffffff;
        border-radius: 20px;
        padding: 2.25rem 4rem; /* TIGHTENED: Reduced top padding from 3rem to 2.25rem */
        box-shadow: 0 10px 40px rgba(0,0,0,0.04);
        border: 1px solid rgba(13, 190, 185, 0.1);
    }

    @media (max-width: 768px) {
        .premium-form-container {
            padding: 1.5rem 1.5rem;
        }
    }

    .form-section-title {
        color: #1a2b4c;
        font-weight: 800;
        font-size: 1.6rem;
        margin-top: 2.5rem;
        margin-bottom: 1.5rem;
        padding-bottom: 0.75rem;
        border-bottom: 2px solid rgba(157, 116, 180, 0.2);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* TIGHTENED: Overriding the margin to 0 for the first title since @csrf breaks :first-child */
    .form-section-title.first-title {
        margin-top: 0 !important;
    }

    .form-subtitle {
        color: #1a2b4c;
        font-weight: 700;
        font-size: 1.1rem;
        margin-bottom: 1.5rem;
        text-transform: uppercase;
    }

    .premium-form-label {
        font-weight: 600;
        color: #475569;
        margin-bottom: 0.4rem;
        font-size: 0.9rem;
    }

    .premium-form-control {
        border-radius: 8px;
        border: 1px solid #cbd5e1;
        padding: 0.65rem 1rem;
        transition: all 0.3s ease;
        background-color: #f8fafc;
        width: 100%;
        color: #1e293b;
    }

    .premium-form-control:focus {
        border-color: #0DBEB9;
        box-shadow: 0 0 0 4px rgba(13, 190, 185, 0.1);
        background-color: #ffffff;
        outline: none;
    }

    /* Flatpickr Custom Theme Overrides */
    .flatpickr-day.selected {
        background: #0DBEB9 !important;
        border-color: #0DBEB9 !important;
    }
    .custom-datepicker {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%2364748b' class='bi bi-calendar' viewBox='0 0 16 16'%3E%3Cpath d='M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 1rem center;
        background-size: 16px;
        cursor: pointer;
    }

    .form-group {
        margin-bottom: 1.25rem;
    }

    /* Sibling Row Styles */
    .sibling-row {
        background-color: #f8fafc;
        padding: 1rem;
        border-radius: 10px;
        border: 1px dashed #cbd5e1;
        margin-bottom: 1rem;
    }

    .btn-add-sibling {
        background-color: #64748b;
        color: white;
        border-radius: 6px;
        font-weight: 600;
        padding: 0.5rem 1rem;
        border: none;
        transition: all 0.3s;
    }

    .btn-add-sibling:hover {
        background-color: #475569;
        color: white;
    }

    .btn-remove-sibling {
        background-color: #ffffff;
        color: #ef4444;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        width: 100%;
        height: calc(1.5em + 1.3rem + 2px);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        transition: all 0.3s;
        margin-top: 26px; /* align with inputs */
    }

    .btn-remove-sibling:hover {
        background-color: #fee2e2;
        border-color: #ef4444;
    }

    /* Custom File Upload */
    .custom-file-upload {
        border: 1px solid #cbd5e1;
        display: flex;
        align-items: center;
        border-radius: 8px;
        background-color: #f8fafc;
        overflow: hidden;
        transition: all 0.3s;
    }
    .custom-file-upload:hover {
        border-color: #9D74B4;
    }
    .custom-file-upload input[type="file"] {
        display: none;
    }
    .custom-file-label {
        background-color: #e2e8f0;
        padding: 0.65rem 1rem;
        color: #475569;
        font-weight: 600;
        cursor: pointer;
        margin: 0;
        border-right: 1px solid #cbd5e1;
        transition: all 0.3s;
        white-space: nowrap;
    }
    .custom-file-label:hover {
        background-color: #cbd5e1;
    }
    .custom-file-text {
        padding: 0.65rem 1rem;
        color: #94a3b8;
        font-size: 0.9rem;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    /* Submit Button */
    .btn-submit-app {
        background: linear-gradient(135deg, #0DBEB9, #9D74B4);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 1rem 2.5rem;
        font-size: 1.1rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 1px;
        transition: all 0.4s ease;
        box-shadow: 0 10px 20px rgba(157, 116, 180, 0.2);
    }
    .btn-submit-app:hover {
        transform: translateY(-3px);
        box-shadow: 0 15px 25px rgba(13, 190, 185, 0.3);
        color: white;
    }
</style>

<section class="admission-form-wrapper">
    <div class="container">
        
        <div class="row mb-3">
            <div class="col-md-12 text-center" data-aos="fade-up">
                <span class="text-uppercase fw-bold" style="color: #0DBEB9; letter-spacing: 2px;">Join Our Family</span>
                <h1 class="fw-bold display-5 mt-2 mb-2" style="color: #9D74B4;">Admission Form</h1>
                <div style="width: 60px; height: 4px; background-color: #9D74B4; margin: 0 auto; border-radius: 2px;"></div>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="premium-form-container" data-aos="fade-up" data-aos-delay="100">
                    
                    <form action="#" method="POST" enctype="multipart/form-data">
                        @csrf
                        
                        <!-- ================= 1. STUDENT PROFILE ================= -->
                        <h3 class="form-section-title first-title">Student Profile</h3>
                        
                        <div class="row">
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Name Of the Student:</label>
                                <input type="text" name="student_name" class="premium-form-control" required>
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Nationality:</label>
                                <input type="text" name="nationality" class="premium-form-control">
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Gender:</label>
                                <select name="gender" class="premium-form-control">
                                    <option value="">Select...</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Passport No:</label>
                                <input type="text" name="student_passport" class="premium-form-control">
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Date of Expiry:</label>
                                <input type="text" name="student_passport_expiry" class="premium-form-control custom-datepicker" placeholder="dd/mm/yyyy">
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Res. Visa No:</label>
                                <input type="text" name="res_visa_no" class="premium-form-control">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Date of Expiry:</label>
                                <input type="text" name="res_visa_expiry" class="premium-form-control custom-datepicker" placeholder="dd/mm/yyyy">
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Age:</label>
                                <input type="number" name="age" class="premium-form-control">
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Blood Group:</label>
                                <input type="text" name="blood_group" class="premium-form-control">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label class="premium-form-label">Home Language(s):</label>
                                <input type="text" name="home_languages" class="premium-form-control">
                            </div>
                            <div class="col-md-6 form-group">
                                <label class="premium-form-label">Previous Nursery/School attended:</label>
                                <input type="text" name="previous_school" class="premium-form-control">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label class="premium-form-label">Any ongoing medical conditions or physical needs?</label>
                                <input type="text" name="medical_conditions" class="premium-form-control">
                            </div>
                            <div class="col-md-6 form-group">
                                <label class="premium-form-label">Any known allergies:</label>
                                <input type="text" name="allergies" class="premium-form-control">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label class="premium-form-label">Does your child carry an EpiPen or emergency medication? If Yes, Details:</label>
                                <input type="text" name="epipen_details" class="premium-form-control">
                            </div>
                            <div class="col-md-6 form-group">
                                <label class="premium-form-label">Any identified learning difficulty or IEP (Individual education program)? If Yes, Details:</label>
                                <input type="text" name="learning_difficulty" class="premium-form-control">
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Transport Facility:</label>
                                <select name="transport_facility" class="premium-form-control">
                                    <option value="">Select...</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Area of Residence:</label>
                                <input type="text" name="area_of_residence" class="premium-form-control">
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Boarding Point:</label>
                                <input type="text" name="boarding_point" class="premium-form-control">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Pin Number:</label>
                                <input type="text" name="pin_number" class="premium-form-control">
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Street Number:</label>
                                <input type="text" name="street_number" class="premium-form-control">
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Building Number:</label>
                                <input type="text" name="building_number" class="premium-form-control">
                            </div>
                        </div>


                        <!-- ================= 2. SIBLING DETAILS ================= -->
                        <h3 class="form-section-title">Sibling Details</h3>
                        
                        <div id="siblings-container">
                            <div class="sibling-row">
                                <div class="row">
                                    <div class="col-md-5 form-group mb-md-0">
                                        <input type="text" name="sibling_reg[]" class="premium-form-control" placeholder="Registration Number">
                                    </div>
                                    <div class="col-md-6 form-group mb-md-0">
                                        <input type="text" name="sibling_name[]" class="premium-form-control" placeholder="Student Name">
                                    </div>
                                    <div class="col-md-1 form-group mb-0">
                                        <button type="button" class="btn-remove-sibling" style="margin-top:0;" onclick="this.closest('.sibling-row').remove()">
                                            <i class="bi bi-dash"></i> -
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="text-end mb-4">
                            <button type="button" class="btn-add-sibling" id="addSiblingBtn">Add Sibling +</button>
                        </div>


                        <!-- ================= 3. PARENT DETAILS ================= -->
                        <h3 class="form-section-title">Parent Details</h3>
                        
                        <div class="row">
                            <!-- FATHER DETAILS -->
                            <div class="col-md-6 pe-md-4">
                                <h5 class="form-subtitle">Father's/Guardian's Details</h5>
                                
                                <div class="form-group">
                                    <label class="premium-form-label">Father Name:</label>
                                    <input type="text" name="father_name" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Father Mobile No:</label>
                                    <input type="text" name="father_mobile" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Father Email:</label>
                                    <input type="email" name="father_email" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Passport No:</label>
                                    <input type="text" name="father_passport" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Date of Expiry:</label>
                                    <input type="text" name="father_passport_expiry" class="premium-form-control custom-datepicker" placeholder="dd/mm/yyyy">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Residence/National ID:</label>
                                    <input type="text" name="father_eid" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Date of Expiry:</label>
                                    <input type="text" name="father_eid_expiry" class="premium-form-control custom-datepicker" placeholder="dd/mm/yyyy">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Father Occupation:</label>
                                    <input type="text" name="father_occupation" class="premium-form-control">
                                </div>
                            </div>

                            <!-- MOTHER DETAILS -->
                            <div class="col-md-6 ps-md-4" style="border-left: 1px solid #e2e8f0;">
                                <h5 class="form-subtitle">Mother's Details</h5>
                                
                                <div class="form-group">
                                    <label class="premium-form-label">Mother Name:</label>
                                    <input type="text" name="mother_name" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Mother Mobile No:</label>
                                    <input type="text" name="mother_mobile" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Mother Email:</label>
                                    <input type="email" name="mother_email" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Passport No:</label>
                                    <input type="text" name="mother_passport" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Date of Expiry:</label>
                                    <input type="text" name="mother_passport_expiry" class="premium-form-control custom-datepicker" placeholder="dd/mm/yyyy">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Residence/National ID:</label>
                                    <input type="text" name="mother_eid" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Date of Expiry:</label>
                                    <input type="text" name="mother_eid_expiry" class="premium-form-control custom-datepicker" placeholder="dd/mm/yyyy">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Mother Occupation:</label>
                                    <input type="text" name="mother_occupation" class="premium-form-control">
                                </div>
                            </div>
                        </div>


                        <!-- ================= 4. EMERGENCY CONTACT ================= -->
                        <h3 class="form-section-title">Emergency Contact (Other than parents)</h3>
                        
                        <div class="row">
                            <!-- Contact 1 -->
                            <div class="col-md-6 pe-md-4">
                                <h5 class="form-subtitle">Contact 1</h5>
                                
                                <div class="form-group">
                                    <label class="premium-form-label">Name:</label>
                                    <input type="text" name="emerg1_name" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Relationship to child:</label>
                                    <input type="text" name="emerg1_relation" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Phone number:</label>
                                    <input type="text" name="emerg1_phone" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Authorized to collect the child:</label>
                                    <select name="emerg1_authorized" class="premium-form-control">
                                        <option value="">Select...</option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Contact 2 -->
                            <div class="col-md-6 ps-md-4" style="border-left: 1px solid #e2e8f0;">
                                <h5 class="form-subtitle">Contact 2</h5>
                                
                                <div class="form-group">
                                    <label class="premium-form-label">Name:</label>
                                    <input type="text" name="emerg2_name" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Relationship to child:</label>
                                    <input type="text" name="emerg2_relation" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Phone number:</label>
                                    <input type="text" name="emerg2_phone" class="premium-form-control">
                                </div>
                                <div class="form-group">
                                    <label class="premium-form-label">Authorized to collect the child:</label>
                                    <select name="emerg2_authorized" class="premium-form-control">
                                        <option value="">Select...</option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <!-- ================= 5. CONSENT ================= -->
                        <h3 class="form-section-title">Consent</h3>
                        
                        <div class="row">
                            <div class="col-md-12">
                                <h5 class="form-subtitle" style="text-transform: none; margin-bottom: 0.5rem; font-weight: 700; color: #1a2b4c;">Photo and video content:</h5>
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">For school use:</label>
                                <select name="consent_school_use" class="premium-form-control">
                                    <option value="">Select...</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">For website/social media:</label>
                                <select name="consent_web_media" class="premium-form-control">
                                    <option value="">Select...</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">For printed materials:</label>
                                <select name="consent_printed" class="premium-form-control">
                                    <option value="">Select...</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-12 form-group">
                                <label class="premium-form-label" style="font-size: 1.05rem;">First aid and emergency medical treatment consent:</label>
                                <select name="consent_first_aid" class="premium-form-control" style="max-width: 300px;">
                                    <option value="">Select...</option>
                                    <option value="I give consent">I give consent</option>
                                    <option value="I do not give consent">I do not give consent</option>
                                </select>
                            </div>
                        </div>


                        <!-- ================= 6. DOCUMENTS ================= -->
                        <h4 class="form-section-title">Upload Documents</h4>
                        <p style="color: #64748b; margin-top: -1rem; margin-bottom: 1.5rem;">The details of documents to be submitted are given below</p>
                        
                        <div class="row">
                            <!-- Row 1 -->
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Child's Passport</label>
                                <div class="custom-file-upload">
                                    <label for="child_passport_doc" class="custom-file-label">Choose File</label>
                                    <span class="custom-file-text" id="child_passport_doc_text">No file chosen</span>
                                    <input type="file" name="child_passport_doc" id="child_passport_doc" onchange="document.getElementById('child_passport_doc_text').innerText = this.files[0] ? this.files[0].name : 'No file chosen'">
                                </div>
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Child's Residence/National ID</label>
                                <div class="custom-file-upload">
                                    <label for="child_residence_doc" class="custom-file-label">Choose File</label>
                                    <span class="custom-file-text" id="child_residence_doc_text">No file chosen</span>
                                    <input type="file" name="child_residence_doc" id="child_residence_doc" onchange="document.getElementById('child_residence_doc_text').innerText = this.files[0] ? this.files[0].name : 'No file chosen'">
                                </div>
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Child’s Passport Size Photograph</label>
                                <div class="custom-file-upload">
                                    <label for="child_photo_doc" class="custom-file-label">Choose File</label>
                                    <span class="custom-file-text" id="child_photo_doc_text">No file chosen</span>
                                    <input type="file" name="child_photo_doc" id="child_photo_doc" onchange="document.getElementById('child_photo_doc_text').innerText = this.files[0] ? this.files[0].name : 'No file chosen'">
                                </div>
                            </div>
                            
                            <!-- Row 2 -->
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Father’s Passport or Residence/National ID</label>
                                <div class="custom-file-upload">
                                    <label for="father_doc" class="custom-file-label">Choose File</label>
                                    <span class="custom-file-text" id="father_doc_text">No file chosen</span>
                                    <input type="file" name="father_doc" id="father_doc" onchange="document.getElementById('father_doc_text').innerText = this.files[0] ? this.files[0].name : 'No file chosen'">
                                </div>
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Mother’s Passport or Residence/National ID</label>
                                <div class="custom-file-upload">
                                    <label for="mother_doc" class="custom-file-label">Choose File</label>
                                    <span class="custom-file-text" id="mother_doc_text">No file chosen</span>
                                    <input type="file" name="mother_doc" id="mother_doc" onchange="document.getElementById('mother_doc_text').innerText = this.files[0] ? this.files[0].name : 'No file chosen'">
                                </div>
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="premium-form-label">Immunization / Vaccination Record</label>
                                <div class="custom-file-upload">
                                    <label for="immunization_doc" class="custom-file-label">Choose File</label>
                                    <span class="custom-file-text" id="immunization_doc_text">No file chosen</span>
                                    <input type="file" name="immunization_doc" id="immunization_doc" onchange="document.getElementById('immunization_doc_text').innerText = this.files[0] ? this.files[0].name : 'No file chosen'">
                                </div>
                            </div>
                        </div>

                        <hr class="my-4" style="border-color: #cbd5e1;">

                        <!-- ================= 7. MISC & SUBMIT ================= -->
                        <div class="row mb-4">
                            <div class="col-md-12 form-group">
                                <label class="premium-form-label">How did you come to know about this school?</label>
                                <select name="source" class="premium-form-control">
                                    <option value="Website">Website</option>
                                    <option value="Social Media">Social Media</option>
                                    <option value="Friends/Family">Friends/Family</option>
                                    <option value="Advertisement">Advertisement</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-5">
                            <div class="col-md-12">
                                <button type="submit" class="btn-submit-app">SUBMIT APPLICATION</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Flatpickr Custom Date Picker & Sibling Button Script Initialization -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        
        // 1. Initialize Datepicker
        flatpickr(".custom-datepicker", {
            dateFormat: "d/m/Y",
            allowInput: true,
            disableMobile: "true" 
        });

        // 2. Add Sibling Button Logic
        const addSiblingBtn = document.getElementById('addSiblingBtn');
        const siblingsContainer = document.getElementById('siblings-container');

        if(addSiblingBtn && siblingsContainer) {
            addSiblingBtn.addEventListener('click', function() {
                
                // Create a new row
                const newRow = document.createElement('div');
                newRow.className = 'sibling-row';
                
                // Insert the updated HTML structure for a sibling row
                newRow.innerHTML = `
                    <div class="row">
                        <div class="col-md-5 form-group mb-md-0">
                            <input type="text" name="sibling_reg[]" class="premium-form-control" placeholder="Registration Number">
                        </div>
                        <div class="col-md-6 form-group mb-md-0">
                            <input type="text" name="sibling_name[]" class="premium-form-control" placeholder="Student Name">
                        </div>
                        <div class="col-md-1 form-group mb-0">
                            <button type="button" class="btn-remove-sibling" style="margin-top:0;" onclick="this.closest('.sibling-row').remove()">
                                <i class="bi bi-dash"></i> -
                            </button>
                        </div>
                    </div>
                `;
                
                // Add a smooth fade-in animation
                newRow.style.opacity = 0;
                newRow.style.transition = "opacity 0.3s ease";
                siblingsContainer.appendChild(newRow);
                
                // Trigger the animation
                setTimeout(() => {
                    newRow.style.opacity = 1;
                }, 10);
                
            });
        }
        
    });
</script>

@include('front.layouts.footer')
