@section('title', 'Contact Us – Bright Beginnings')
@section('description', 'Get in touch with Bright Beginnings. Contact us for admissions, inquiries, or more information about our world-class early childhood education.')
@section('contact_us', 'active')
@include('front.layouts.header')

<!-- Fixed Banner for Contact Page -->
<section class="position-relative" style="
    background: url('{{ asset('Front/images/banner8.jpg') }}') center top / cover no-repeat !important;
    width: 100vw; 
    margin-left: calc(-50vw + 50%); 
    max-width: 100vw; 
    height: 450px !important;
    margin-top: 0 !important;
    margin-bottom: 0 !important;
    border: none !important;
    overflow: hidden;
     background-attachment:fixed
">
</section>

<!-- Custom Styles for Premium Contact Page -->
<style>
    /* Premium Contact Page Background */
    .contact-page-wrapper {
        background-color: #f4faff;
        background-image: 
            linear-gradient(rgba(13, 190, 185, 0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(13, 190, 185, 0.04) 1px, transparent 1px);
        background-size: 40px 40px;
        background-position: center top;
        padding-top: 5rem;
        padding-bottom: 5rem;
    }

    /* Form Container */
    .premium-contact-form {
        background: #ffffff;
        border-radius: 20px;
        padding: 3rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.03);
        border: 1px solid rgba(13, 190, 185, 0.1);
        height: 100%;
    }

    /* Premium Inputs */
    .premium-contact-form .form-control {
        border-radius: 12px;
        padding: 0.9rem 1.2rem;
        border: 1px solid rgba(0,0,0,0.08);
        background-color: #f8fafc;
        transition: all 0.3s ease;
        font-size: 0.95rem;
        color: #1a2b4c;
    }
    
    .premium-contact-form .form-control::placeholder {
        color: #94a3b8;
    }
    
    .premium-contact-form .form-control:focus {
        background-color: #ffffff;
        border-color: #9D74B4;
        box-shadow: 0 0 0 4px rgba(157, 116, 180, 0.1);
        outline: none;
    }

    /* Submit Button */
    .btn-premium-submit {
        background-color: #9D74B4 !important;
        border-color: #9D74B4 !important;
        color: #ffffff !important;
        border-radius: 50px;
        padding: 14px 30px;
        font-weight: 700;
        font-size: 1.05rem;
        letter-spacing: 0.5px;
        box-shadow: 0 4px 15px rgba(157, 116, 180, 0.3);
        transition: all 0.3s ease;
    }
    .btn-premium-submit:hover:not(:disabled) {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(157, 116, 180, 0.4);
        color: #ffffff !important;
    }
    .btn-premium-submit:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }

    /* Contact Detail Cards */
    .contact-info-card {
        background: #ffffff;
        border-radius: 16px;
        padding: 1.75rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 4px 15px rgba(0,0,0,0.02);
        border: 1px solid rgba(13, 190, 185, 0.1);
        transition: all 0.3s ease;
        display: flex;
        align-items: flex-start;
    }
    
    .contact-info-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 25px rgba(13, 190, 185, 0.1);
        border-color: rgba(13, 190, 185, 0.3);
    }

    /* Icon Box with Exact Logo Colors */
    .contact-icon-box {
        width: 55px;
        height: 55px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        margin-right: 1.25rem;
    }
    
    /* Applying the 3 Logo Colors to the Icons */
    .icon-purple {
        background-color: rgba(157, 116, 180, 0.12);
        color: #9D74B4;
    }
    .icon-surf {
        background-color: rgba(13, 190, 185, 0.12);
        color: #0DBEB9;
    }
    .icon-gold {
        background-color: rgba(196, 192, 104, 0.12);
        color: #C4C068;
    }

    .contact-info-text h5 {
        font-size: 1.1rem;
        font-weight: 700;
        color: #1a2b4c; /* Navy Blue */
        margin-bottom: 0.35rem;
    }
    .contact-info-text p {
        color: #64748b;
        margin-bottom: 0;
        font-size: 0.95rem;
        line-height: 1.6;
    }

    /* Map Container */
    .map-container {
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0,0,0,0.04);
        border: 1px solid rgba(13, 190, 185, 0.15);
        margin-top: 2rem;
        background: #fff;
        padding: 10px; /* Polaroid effect */
    }
    .map-container iframe {
        border-radius: 12px;
    }
    
    /* Error Text Styling */
    .error {
        color: #e3342f;
        font-size: 0.85rem;
        margin-top: 0.25rem;
        display: block;
    }
</style>

<section class="contact-page-wrapper">
    <div class="container">
        
        <!-- Header Title -->
        <div class="row mb-5">
            <div class="col-md-12 text-center" data-aos="fade-up">
                <span class="text-uppercase fw-bold" style="color: #0DBEB9; letter-spacing: 2px;">Get In Touch</span>
                <h1 class="fw-bold display-5 mt-2" style="color: #9D74B4;">Bright Beginnings</h1>
                <div style="width: 60px; height: 4px; background-color: #9D74B4; margin: 0 auto; border-radius: 2px;" class="mt-3"></div>
            </div>
        </div>

        <div class="row g-4 g-md-5">
            <!-- Contact Form -->
            <div class="col-lg-7">
                <div class="premium-contact-form" data-aos="fade-right">
                    <h4 class="fw-bold mb-4" style="color: #1a2b4c;">Send Us a Message</h4>
                    
                    <form method="post" action="{{ route('contactus_store') }}" autocomplete="off" enctype="multipart/form-data">
                        @csrf
                        <div class="mb-4">
                            <input type="text" class="form-control" name="name" value="{{old('name')}}" placeholder="Your Full Name" required>
                            @if ($errors->has('name'))
                                <span class="error">{{ $errors->first('name') }}</span>
                            @endif
                        </div>
                        
                        <div class="row">
                            <div class="col-md-5">
                                <div class="mb-4">
                                    <input type="text" class="form-control" name="class" value="{{old('class')}}" placeholder="Child's Class/Age" required>
                                    @if ($errors->has('class'))
                                        <span class="error">{{ $errors->first('class') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div class="mb-4">
                                    <input type="text" class="form-control" name="phone" value="{{old('phone')}}" placeholder="Phone Number" required>
                                    @if ($errors->has('phone'))
                                        <span class="error">{{ $errors->first('phone') }}</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <input type="email" class="form-control" name="email" value="{{old('email')}}" placeholder="Email Address" required>
                            @if ($errors->has('email'))
                                <span class="error">{{ $errors->first('email') }}</span>
                            @endif
                        </div>
                        
                        <div class="mb-4">
                            <textarea placeholder="Type your message or inquiry here..." class="form-control" name="message" rows="4" required>{{old('message')}}</textarea>
                            @if ($errors->has('message'))
                                <span class="error">{{ $errors->first('message') }}</span>
                            @endif
                        </div>
                        
                        <div class="mb-4">
                            <div class="g-recaptcha"
                                style="transform:scale(0.85);transform-origin:0;-webkit-transform:scale(0.85);-webkit-transform-origin:0 0;"
                                data-sitekey="{{ env('RecaptchaSitekey') }}" data-callback="recaptchaCallback">
                            </div>
                        </div>
                        
                        <!-- Added id="Submit_btn" so the JS Recaptcha code actually works! -->
                        <button type="submit" id="Submit_btn" class="btn btn-premium-submit w-100" disabled>Submit Message</button>
                    </form>
                </div>
            </div>

            <!-- Contact Information Cards -->
            <div class="col-lg-5">
                <div class="contact-details h-100 d-flex flex-column justify-content-center">
                    
                    <!-- Telephone Card (Purple) -->
                    <div class="contact-info-card" data-aos="fade-left" data-aos-delay="100">
                        <div class="contact-icon-box icon-purple">
                            <i class="bi bi-telephone-fill fs-4"></i>
                        </div>
                        <div class="contact-info-text">
                            <h5>Telephone</h5>
                            <p>+966 59 600 3218<br>+966 53 790 1050</p>
                        </div>
                    </div>

                    <!-- Email Card (Surf) -->
                    <div class="contact-info-card" data-aos="fade-left" data-aos-delay="200">
                        <div class="contact-icon-box icon-surf">
                            <i class="bi bi-envelope-fill fs-4"></i>
                        </div>
                        <div class="contact-info-text">
                            <h5>Office Email</h5>
                            <p>info@brightbeginningsksa.com</p>
                        </div>
                    </div>

                    <!-- Address Card (Gold) -->
                    <div class="contact-info-card" data-aos="fade-left" data-aos-delay="300">
                        <div class="contact-icon-box icon-gold">
                            <i class="bi bi-geo-alt-fill fs-4"></i>
                        </div>
                        <div class="contact-info-text">
                            <h5>Address</h5>
                            <p>Al Khobar, Ar Rakha Al Janubiyah<br>Kingdom of Saudi Arabia<br><span style="font-family: Arial, sans-serif;">الخبر، حي الراكة الجنوبية، المملكة العربية السعودية</span></p>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- Google Map Section (Updated to Al Khobar) -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="map-container" data-aos="fade-up">
                   <iframe src="https://maps.google.com/maps?q=Al%20Khobar,%20Ar%20Rakah%20Al%20Janubiyah,%20Saudi%20Arabia&t=&z=14&ie=UTF8&iwloc=&output=embed" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>

    </div>
</section>

@include('front.layouts.footer')

<script>
    function recaptchaCallback() {
        var bookbutton = document.getElementById("Submit_btn");
        if (bookbutton) {
            bookbutton.disabled = false;
        }
    }

    $(function() {
        $("input[name='phone']").on('input', function(e) {
            $(this).val($(this).val().replace(/[^0-9]/g, ''));
        });
        
        // Failsafe: if recaptcha fails to load or isn't configured, enable the button after 3 seconds anyway
        setTimeout(function() {
            var btn = document.getElementById("Submit_btn");
            if(btn && btn.disabled && !document.querySelector('.g-recaptcha iframe')) {
                btn.disabled = false;
            }
        }, 3000);
    });
</script>
