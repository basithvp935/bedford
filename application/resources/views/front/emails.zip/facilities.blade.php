@section('title', 'Our Environment - Bright Beginnings Montessori')
@section('description', 'Explore our beautifully prepared Montessori Lab at Bright Beginnings, divided into Sensorial, Practical Life, Language, Mathematics, and Cultural & Science areas.')
@section('environment', 'active')
@include('front.layouts.header')

<style>
    /* ==========================================
       NEW HERO BANNER (CENTERED HEADING) 
       ========================================== */
    .environment-banner {
        position: relative;
        width: 100vw;
        margin-left: calc(-50vw + 50%);
        max-width: 100vw;
        height: 450px; 
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        background-attachment: fixed;
    }

    .banner-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.4); 
        z-index: 1;
    }

    .banner-text {
        position: relative;
        z-index: 2;
        text-align: center;
        width: 100%;
    }

    .banner-title {
        font-family: 'Georgia', serif; 
        color: #ffffff;
        font-size: 3rem; 
        font-weight: 700;
        margin: 0;
        text-transform: capitalize;
        text-shadow: 2px 2px 10px rgba(0,0,0,0.4);
    }

    @media (max-width: 768px) {
        .banner-title {
            font-size: 1.8rem; 
        }
        .environment-banner {
            height: 300px;
        }
    }

    /* ========================================== */

    /* Premium Admission Button matching the Second Image */
    .btn-admission {
        background: linear-gradient(90deg, #8F65B8, #7445A5); /* Exact purple from your image */
        color: #ffffff !important;
        font-family: 'Nunito', sans-serif; /* Rounded, friendly font */
        font-weight: 700;
        font-size: 1.3rem;
        padding: 14px 45px;
        border-radius: 50px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        text-decoration: none;
        border: none;
        box-shadow: 0 8px 20px rgba(116, 69, 165, 0.3);
        transition: all 0.3s ease;
    }

    .btn-admission:hover {
        transform: translateY(-3px);
        box-shadow: 0 12px 25px rgba(116, 69, 165, 0.4);
        background: linear-gradient(90deg, #7A53A0, #61398D);
        color: #ffffff !important;
    }
    
    .btn-admission span {
        font-size: 1.5rem;
        line-height: 1;
        margin-bottom: 2px;
    }

    /* Learning Area Cards - Full Image Overlay Animation */
    .learning-card {
        position: relative;
        border-radius: 15px; /* Clean rounded corners */
        overflow: hidden;
        background: #000; /* Black background to help text pop */
        border: 2px solid transparent; /* Base border for the color theme */
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
        cursor: pointer;
        padding: 0;
        height: 280px; /* Decreased height as requested */
        display: block; 
        font-family: 'Nunito', sans-serif;
    }

    .learning-card .img-wrapper {
        width: 100%;
        height: 100%; /* Image takes full card height */
        position: absolute;
        top: 0;
        left: 0;
        overflow: hidden;
    }

    /* Dark shade over the image so white text is readable */
    .learning-card .img-wrapper::after {
        content: '';
        position: absolute;
        inset: 0;
        background: rgba(0, 0, 0, 0.45); /* Normal dark shade */
        transition: all 0.4s ease;
        z-index: 1;
    }

    .learning-card .card-img-top {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
    }

    /* Title Centered OVER the Image */
    .learning-card .title-overlay {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: transparent;
        color: #ffffff; /* Pure white font */
        padding: 0;
        font-weight: 800;
        font-size: 1.8rem;
        z-index: 3;
        text-shadow: 0 4px 15px rgba(0,0,0,0.6);
        transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
        margin: 0;
        width: 100%;
        text-align: center;
        letter-spacing: 1px;
    }

    /* Content Wrapper for Description (Now OVER the image) */
    .learning-card .card-content-wrapper {
        position: absolute;
        inset: 0; /* Cover the whole card */
        padding: 2rem 1.5rem;
        display: flex;
        flex-direction: column;
        justify-content: flex-end; /* Push text to bottom half */
        align-items: center;
        text-align: center;
        z-index: 4;
        pointer-events: none; /* Let hover register on learning-card instead */
        background: transparent;
    }

    .learning-card p {
        opacity: 0;
        visibility: hidden;
        transform: translateY(20px); /* Start slightly lower */
        margin: 0;
        color: #ffffff; /* White text for description over image */
        font-size: 1.05rem;
        line-height: 1.6;
        text-shadow: 0 2px 10px rgba(0,0,0,0.8);
        transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
    }

    /* Hover & Mobile Active Effects */
    .learning-card:hover, .learning-card:focus-within, .learning-card:active {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.2);
    }
    
    .learning-card:hover .card-img-top, .learning-card:focus-within .card-img-top, .learning-card:active .card-img-top {
        transform: scale(1.1); /* Zoom image smoothly */
    }
    
    .learning-card:hover .img-wrapper::after, .learning-card:focus-within .img-wrapper::after, .learning-card:active .img-wrapper::after {
        background: rgba(0, 0, 0, 0.75); /* Darken image strongly so description is easy to read */
    }
    
    /* Slide the Title Up! */
    .learning-card:hover .title-overlay, .learning-card:focus-within .title-overlay, .learning-card:active .title-overlay {
        top: 22%; /* Slide title beautifully up to the top */
        transform: translate(-50%, -50%) scale(0.95);
        text-shadow: 0 6px 20px rgba(0,0,0,0.8);
    }
    
    /* Bring in the description text */
    .learning-card:hover p, .learning-card:focus-within p, .learning-card:active p {
        opacity: 1;
        visibility: visible;
        transform: translateY(0); /* Slide up into position */
    }

    /* 5 Colors - Used for beautiful border/glow effects on hover */
    .card-purple { border-color: rgba(157, 116, 180, 0); }
    .card-purple:hover, .card-purple:focus-within { border-color: #9D74B4; box-shadow: 0 15px 35px rgba(157, 116, 180, 0.3); }

    .card-yellow { border-color: rgba(234, 179, 8, 0); }
    .card-yellow:hover, .card-yellow:focus-within { border-color: #EAB308; box-shadow: 0 15px 35px rgba(234, 179, 8, 0.3); }

    .card-blue { border-color: rgba(59, 130, 246, 0); }
    .card-blue:hover, .card-blue:focus-within { border-color: #3B82F6; box-shadow: 0 15px 35px rgba(59, 130, 246, 0.3); }

    .card-green { border-color: rgba(13, 190, 185, 0); }
    .card-green:hover, .card-green:focus-within { border-color: #0DBEB9; box-shadow: 0 15px 35px rgba(13, 190, 185, 0.3); }

    .card-orange { border-color: rgba(249, 115, 22, 0); }
    .card-orange:hover, .card-orange:focus-within { border-color: #F97316; box-shadow: 0 15px 35px rgba(249, 115, 22, 0.3); }
    
    /* Optional hint on mobile */
    @media (max-width: 768px) {
        .learning-card::after {
            content: "Tap to view";
            position: absolute;
            bottom: 10px;
            font-size: 0.8rem;
            color: rgba(255, 255, 255, 0.8);
            opacity: 1;
            transition: opacity 0.3s ease;
            text-align: center;
            width: 100%;
            z-index: 10;
        }
        .learning-card:hover::after, .learning-card:focus-within::after, .learning-card:active::after {
            opacity: 0;
        }
    }
</style>

<div class="environment-page-wrapper">
    
    <!-- NEW HERO BANNER (Full Width with Centered Text) -->
    <section class="environment-banner" style="background: url('{{ asset('Front/images/brightban.jpg') }}') center top / cover no-repeat;">
        <div class="banner-overlay"></div>
        <div class="banner-text">
            <h1 class="banner-title">Our Environment</h1>
        </div>
    </section>

    <section class="environment-page py-5">
        <div class="container">
            
            <!-- Hero Section -->
            <div class="row mb-5 pb-4 mt-4 align-items-center">
                <div class="col-md-6 mb-4 mb-md-0" data-aos="fade-right">
                    <h2 class="fw-bold mb-4" style="color: #9D74B4; font-size: 2.2rem; font-family: 'Nunito', sans-serif;">Our Montessori Lab</h2>
                    <p style="color: #475569; font-size: 1.15rem; line-height: 1.8;">
                        The Montessori Lab is the heart of Bright Beginnings—a beautifully prepared environment filled with authentic AMI-approved Montessori materials designed by Maria Montessori.
                    </p>
                    <p style="color: #475569; font-size: 1.15rem; line-height: 1.8;">
                        Thoughtfully divided into five key learning areas, our lab encourages children to explore, discover, and grow at their own pace through hands-on experiences and purposeful work.
                    </p>
                    <p style="color: #475569; font-size: 1.15rem; line-height: 1.8;">
                        Combined with our <strong>Bright Thread Philosophy</strong>, these materials empower children to become independent, capable, and confident learners.
                    </p>
                </div>
                <div class="col-md-6" data-aos="fade-left">
                    <img src="{{ asset('Front/images/lab1.jpg') }}" class="img-fluid w-100 shadow-lg" style="border-radius: 20px; border: 4px solid #fff;" alt="Montessori Lab">
                </div>
            </div>

            <!-- 5 Key Learning Areas -->
            <div class="row mb-4">
                <div class="col-md-12 text-center" data-aos="fade-up">
                    <h3 class="fw-bold mb-5" style="color: #1a2b4c; font-family: 'Nunito', sans-serif;">Five Key Learning Areas</h3>
                </div>
            </div>

            <!-- Removed justify-content-center to align items to the left -->
            <div class="row g-4" data-aos="fade-up" data-aos-delay="100">
                
                <!-- Card 1: Sensorial -->
                <div class="col-lg-4 col-md-6">
                    <div class="learning-card card-purple" tabindex="0">
                        <div class="img-wrapper">
                            <img src="{{ asset('Front/images/sensoriall.jpeg') }}" alt="Sensorial Area" class="card-img-top">
                            <h4 class="title-overlay">Sensorial</h4>
                        </div>
                        <div class="card-content-wrapper">
                            <p>Children refine their senses through iconic Montessori materials such as the Pink Tower, Knobbed Cylinders, Color Tablets, and Sound Boxes, developing concentration, observation, language, and early mathematical thinking.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Card 2: Practical Life -->
                <div class="col-lg-4 col-md-6">
                    <div class="learning-card card-yellow" tabindex="0">
                        <div class="img-wrapper">
                            <img src="{{ asset('Front/images/practicall.jpeg') }}" alt="Practical Life Area" class="card-img-top">
                            <h4 class="title-overlay">Practical Life</h4>
                        </div>
                        <div class="card-content-wrapper">
                            <p>Through real-life activities such as pouring, polishing, sweeping, flower arranging, and working with Dressing Frames, children build independence, coordination, confidence, and responsibility.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Card 3: Language -->
                <div class="col-lg-4 col-md-6">
                    <div class="learning-card card-blue" tabindex="0">
                        <div class="img-wrapper">
                            <img src="{{ asset('Front/images/language.jpeg') }}" alt="Language Area" class="card-img-top">
                            <h4 class="title-overlay">Language</h4>
                        </div>
                        <div class="card-content-wrapper">
                            <p>Using Montessori materials such as Sandpaper Letters, the Movable Alphabet, and Object Boxes, alongside Read Write Inc. Phonics, children develop strong communication, reading, writing, and storytelling skills in a joyful and engaging way.</p>
                        </div>
                    </div>
                </div>

                <!-- Card 4: Mathematics -->
                <div class="col-lg-4 col-md-6">
                    <div class="learning-card card-green" tabindex="0">
                        <div class="img-wrapper">
                            <img src="{{ asset('Front/images/maths.jpeg') }}" alt="Mathematics Area" class="card-img-top">
                            <h4 class="title-overlay">Mathematics</h4>
                        </div>
                        <div class="card-content-wrapper">
                            <p>Concrete materials such as the Golden Beads, Bead Chains, Number Rods, and Stamp Game help children understand mathematical concepts through hands-on exploration, building confidence and a genuine love of numbers.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Card 5: Cultural & Science -->
                <div class="col-lg-4 col-md-6">
                    <div class="learning-card card-orange" tabindex="0">
                        <div class="img-wrapper">
                            <img src="{{ asset('Front/images/culturall.jpeg') }}" alt="Cultural and Science Area" class="card-img-top">
                            <h4 class="title-overlay">Cultural & Science</h4>
                        </div>
                        <div class="card-content-wrapper">
                            <p>Children explore geography, nature, science, history, and world cultures through maps, globes, landform models, botany materials, and zoology cards, nurturing curiosity, wonder, and a lifelong love of learning.</p>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Quote Section & Admission Button -->
            <div class="text-center mt-5 pt-5" data-aos="fade-up">
                <div style="background: rgba(157, 116, 180, 0.05); border-left: 5px solid #9D74B4; padding: 2.5rem; border-radius: 0 20px 20px 0; display: inline-block; max-width: 900px; box-shadow: 0 10px 30px rgba(0,0,0,0.02); margin-bottom: 3rem;">
                    <h3 class="fst-italic mb-0" style="color: #1a2b4c; line-height: 1.6; font-weight: 600;">"The senses, being the explorers of the world, open the way to knowledge."</h3>
                    <p class="mb-0 mt-4 fw-bold text-uppercase tracking-wider" style="color: #9D74B4; letter-spacing: 1px;">— Maria Montessori</p>
                </div>
                
                <!-- Beautiful Purple Admission Button -->
                <div>
                    <a href="{{ route('admission') }}" class="btn-admission">
                        Admission <span>&rarr;</span>
                    </a>
                </div>
            </div>

        </div>
    </section>
</div>

@include('front.layouts.footer')
