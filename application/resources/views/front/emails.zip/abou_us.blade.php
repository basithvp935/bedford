@section('title', 'About Us | Bright Beginnings Montessori - Best KG in Dubai')
@section('description', 'Discover Bright Beginnings Montessori - Best Kindergarten in Dubai. Offering play-based early childhood education and a nurturing environment for toddlers. Enroll today.')
@include('front.layouts.header')

<style>
    /* Banner Box Style for About Us Text */
    .about-banner-box {
        background: linear-gradient(135deg, rgba(13, 190, 185, 0.08) 0%, rgba(255, 255, 255, 0.5) 50%, rgba(157, 116, 180, 0.08) 100%);
        border-radius: 20px;
        padding: 3rem 4rem;
        border: 1px solid rgba(157, 116, 180, 0.15);
        box-shadow: 0 10px 30px rgba(0,0,0,0.03);
        transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
        position: relative;
        overflow: hidden;
    }
    
    @media (max-width: 768px) {
        .about-banner-box {
            padding: 2rem;
        }
    }
    
    .about-banner-box:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(13, 190, 185, 0.15);
        border-color: rgba(13, 190, 185, 0.4);
        background: linear-gradient(135deg, rgba(13, 190, 185, 0.12) 0%, rgba(255, 255, 255, 0.7) 50%, rgba(157, 116, 180, 0.12) 100%);
    }
    
    .about-banner-box::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background: radial-gradient(circle at center, rgba(255,255,255,0.8) 0%, transparent 100%);
        z-index: 0;
    }
    
    .about-banner-content {
        position: relative;
        z-index: 1;
    }

    /* Hover effect for Mission/Vision boxes */
    .about-box {
        transition: all 0.3s ease;
    }
    .about-box:hover {
        transform: translateY(-6px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.06) !important;
    }

    /* NEW: Premium Purple Shade Image Effect */
    .image-purple-shade {
        position: relative;
        border-radius: 20px;
        overflow: hidden;
        border: 4px solid #ffffff;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        display: inline-block;
        width: 100%;
        cursor: pointer;
    }
    .image-purple-shade img {
        display: block;
        width: 100%;
        object-fit: cover;
        max-height: 450px;
        object-position: center;
        transition: transform 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
    }
    .image-purple-shade::after {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background-color: rgba(157, 116, 180, 0.3); /* Bright Beginnings Purple Overlay! */
        pointer-events: none;
        transition: all 0.4s ease;
    }
    
    /* Interactive Hover Effect */
    .image-purple-shade:hover img {
        transform: scale(1.05); /* Soft zoom in */
    }
    .image-purple-shade:hover::after {
        background-color: rgba(157, 116, 180, 0.05); /* Clears the shade on hover */
    }

    /* Responsive Title - Decreased font size to match other banners */
    @media (max-width: 768px) {
        .about-main-title {
            font-size: 1.8rem !important;
        }
    }
</style>

<!-- Fixed Banner: Text is now centered perfectly inside the image -->
<section class="position-relative d-flex align-items-center justify-content-center" style="
    background: url('{{ asset('Front/images/brightban.jpg') }}') center top / cover no-repeat; 
    width: 100vw; 
    margin-left: calc(-50vw + 50%); 
    max-width: 100vw; 
    height: 450px; 
    overflow: hidden;
    background-attachment:fixed;
">
    <!-- Overlay to ensure the white text pops nicely over the image -->
    <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.4); z-index: 1;"></div>
    
    <!-- Centered Heading - Decreased font size from 5rem to 3rem -->
    <div style="position: relative; z-index: 2; text-align: center; width: 100%;">
        <h1 class="about-main-title" style="font-family: 'Georgia', serif; color: #ffffff; font-size: 3rem; font-weight: 700; margin: 0; text-shadow: 2px 2px 10px rgba(0,0,0,0.4);">
            About Us
        </h1>
    </div>
</section>

<!-- About Us section with Premium Soft Blue Theme Background added -->
<section class="about section-100 home-about py-5" style="
    background-color: #f4faff;
    background-image: 
        linear-gradient(rgba(13, 110, 253, 0.04) 1px, transparent 1px),
        linear-gradient(90deg, rgba(13, 110, 253, 0.04) 1px, transparent 1px);
    background-size: 40px 40px;
    background-position: center top;
">
    <div class="container">
        
        <!-- The old standalone 'About Us' heading was removed since it is now inside the banner image above. -->

        <div class="row g-md-5 mb-5 mt-lg-3 mt-1">
            <div class="col-md-12">
                <!-- Expanded width banner box (removed max-width) -->
                <div class="about-banner-box w-100 mx-auto" data-aos="fade-up" data-aos-delay="100">
                    <div class="about-banner-content">
                        
                        <!-- NEW LAYOUT: Banner Image Top, Text Below -->
                        <div class="row">
                            
                            <!-- Top: Banner Image -->
                            <div class="col-12 mb-5">
                                <div class="image-purple-shade w-100" style="border-radius: 15px;">
                                    <img src="{{ asset('Front/images/lege.jpg') }}" alt="Our Story" class="img-fluid w-100">
                                </div>
                            </div>

                            <!-- Bottom: Content -->
                            <div class="col-12 px-lg-4 text-start">
                                <span class="fw-bold tracking-wider text-uppercase" style="color: #9D74B4; letter-spacing: 2px;">OUR STORY.</span>
                                <h2 class="pb-2 mt-2 fw-bold" style="color: #1a2b4c; font-size: 2.2rem;">A Legacy Reimagined</h2>
                                
                                <div style="width: 80px; height: 4px; background: linear-gradient(to right, #9D74B4, #0DBEB9); margin: 0 0 1.5rem 0; border-radius: 2px;"></div>
                                
                                <div class="in-txt text-dark mt-4" style="font-size: 1.15rem; line-height: 1.8;">
                                    <p>In 1996, Little Angels first opened its doors in Golden Belt, Al Khobar, with a simple belief: every child deserves an education that recognizes their individuality, nurtures their potential, and inspires a lifelong love of learning.</p>
                                    
                                    <p>Over the years, Little Angels became more than a school. It became a trusted part of the community, known for its warm environment, personalized approach, and commitment to seeing each child as a unique learner. Our reputation wasn't built through advertising—it was built through generations of families who experienced the difference for themselves.</p>
                                    
                                    <p>When our doors temporarily closed, our journey did not stop.</p>
                                    
                                    <p>Instead, we embarked on a mission to discover what truly authentic early childhood education should look like. We travelled deeper into educational research, explored leading Montessori practices, and asked ourselves a challenging question:</p>
                                    
                                    <p style="font-style: italic; color: #555; padding-left: 20px; border-left: 3px solid #0DBEB9; margin: 2rem 0;">If we were to begin again, what would be the very best learning environment we could create for children?</p>
                                    
                                    <p>The answer became <strong style="font-weight: bold;">Bright Beginnings Montessori.</strong></p>
                                    
                                    <p>Today, we return with the same heart that families have trusted for over 30 years, strengthened by a renewed vision and a commitment to authentic Montessori education.</p>
                                    
                                    <p>We searched for authenticity—and built it ourselves.</p>
                                    
                                    <p>Throughout our search, we sought an authentic Montessori environment that embodied the true principles of the Montessori philosophy. When we realised that the standard we envisioned did not yet exist locally, we made a decision:</p>
                                    
                                    <p>We would create it ourselves.</p>
                                    
                                    <p class="mb-4">Every classroom, every material, and every learning space has been intentionally designed to support independence, concentration, curiosity,<br class="d-none d-lg-block"> and purposeful exploration. Nothing exists merely for display; everything serves a meaningful role in a child's developmental journey.</p>
                                    
                                    <p class="mb-0">At the center of this experience is our signature Bright Thread Methodology—an approach developed from decades of educational experience<br class="d-none d-lg-block"> that carefully weaves together Montessori principles, individualized learning, meaningful challenge, and genuine child-led discovery.</p>
                                </div>
                                
                            </div>
                            
                        </div>
                        
                        <!-- NEW SECTION MOVED INSIDE THE BOX: What sets us apart (4 Boxes) -->
                        <div class="row mb-4 mt-5 pt-3">
                            <div class="col-md-10 mx-auto text-center" data-aos="fade-up">
                                <h3 style="color: #555; font-size: 1.4rem; font-weight: 500; line-height: 1.5; letter-spacing: 0.5px;">What sets us apart isn't just philosophy — it's practice, people, and standards.</h3>
                            </div>
                        </div>
                        
                        <div class="row g-4 px-lg-3 pb-2">
                            <!-- Box 1 (Purple Theme) -->
                            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
                                <div class="about-box h-100 p-4 shadow-sm" style="background: rgba(157, 116, 180, 0.08); border: 1px solid rgba(157, 116, 180, 0.15); border-radius: 20px;">
                                    <i class="bi bi-patch-check mb-3 d-block" style="font-size: 2.2rem; color: #9D74B4;"></i>
                                    <h5 class="fw-bold mb-3" style="color: #1a2b4c; font-size: 1.15rem;">AMS-aligned</h5>
                                    <p class="text-dark mb-0" style="opacity: 0.85; font-size: 15px; line-height: 1.7;">We follow the American Montessori Society framework, one of the most rigorous standards in early education.</p>
                                </div>
                            </div>
                            
                            <!-- Box 2 (Teal Theme) -->
                            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
                                <div class="about-box h-100 p-4 shadow-sm" style="background: rgba(13, 190, 185, 0.08); border: 1px solid rgba(13, 190, 185, 0.15); border-radius: 20px;">
                                    <i class="bi bi-mortarboard mb-3 d-block" style="font-size: 2.2rem; color: #0DBEB9;"></i>
                                    <h5 class="fw-bold mb-3" style="color: #1a2b4c; font-size: 1.15rem;">Qualified teachers</h5>
                                    <p class="text-dark mb-0" style="opacity: 0.85; font-size: 15px; line-height: 1.7;">Every educator on our team is Montessori-trained and certified — not just familiar with the method, but formed by it.</p>
                                </div>
                            </div>
                            
                            <!-- Box 3 (Purple Theme) -->
                            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
                                <div class="about-box h-100 p-4 shadow-sm" style="background: rgba(157, 116, 180, 0.08); border: 1px solid rgba(157, 116, 180, 0.15); border-radius: 20px;">
                                    <i class="bi bi-layers mb-3 d-block" style="font-size: 2.2rem; color: #9D74B4;"></i>
                                    <h5 class="fw-bold mb-3" style="color: #1a2b4c; font-size: 1.15rem;">Bright Thread method</h5>
                                    <p class="text-dark mb-0" style="opacity: 0.85; font-size: 15px; line-height: 1.7;">Our own signature pedagogy, developed over decades, that personalises the Montessori journey for each child.</p>
                                </div>
                            </div>
                            
                            <!-- Box 4 (Teal Theme) -->
                            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
                                <div class="about-box h-100 p-4 shadow-sm" style="background: rgba(13, 190, 185, 0.08); border: 1px solid rgba(13, 190, 185, 0.15); border-radius: 20px;">
                                    <i class="bi bi-house-heart mb-3 d-block" style="font-size: 2.2rem; color: #0DBEB9;"></i>
                                    <h5 class="fw-bold mb-3" style="color: #1a2b4c; font-size: 1.15rem;">Open environment</h5>
                                    <p class="text-dark mb-0" style="opacity: 0.85; font-size: 15px; line-height: 1.7;">A thoughtfully prepared space where every material serves a purpose and every child feels free to explore.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Concluding paragraphs aligned left below boxes -->
                        <div class="row mt-5 pt-3 pb-2">
                            <div class="col-12 px-lg-4 text-start" data-aos="fade-up">
                                <div class="in-txt text-dark" style="font-size: 1.15rem; line-height: 1.8;">
                                    <p>Bright Beginnings Montessori is more than a new name.</p>
                                    
                                    <p>It is the continuation of a legacy that began in 1996, reimagined for a new generation of learners.</p>
                                    
                                    <p>We remain committed to knowing every child by name, respecting every child's pace, and helping every child discover the confidence, capability, and joy that already exists within them.</p>
                                    
                                    <p class="mb-0">Because great beginnings create bright futures.</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Updated Mission, Vision, and Philosophy Section -->
<section class="section-100 pb-5">
    <div class="container">
        <div class="row g-5">
            <!-- Mission Section (Exact Logo Purple) -->
            <div class="col-md-12">
                <div class="about-box shadow-sm" style="background: rgba(157, 116, 180, 0.15); border: 1px solid rgba(157, 116, 180, 0.2); border-radius: 20px; padding: 50px;">
                    <div class="row align-items-center">
                        <div class="col-md-5 text-center mb-4 mb-md-0" data-aos="fade-right">
                            <img src="{{ asset('Front/images/m.jpg') }}" alt="Mission" class="img-fluid rounded-circle shadow" style="width: 300px; height: 300px; object-fit: cover; border: 8px solid rgba(157, 116, 180, 0.3);">
                        </div>
                        <div class="col-md-7" data-aos="fade-left">
                            <div class="d-flex align-items-center mb-3">
                                <div class="icon-box me-3 d-flex align-items-center justify-content-center shadow-sm" style="background: #9D74B4; color: #ffffff; width: 60px; height: 60px; border-radius: 50%;">
                                    <i class="bi bi-bullseye" style="font-size: 28px;"></i>
                                </div>
                                <h2 class="mb-0 fw-bold" style="color: #9D74B4;">Our Mission</h2>
                            </div>
                            
                            <h4 class="mb-3" style="color: #444; font-weight: 600;">Nurturing Independent Minds and Joyful Learners</h4>
                            
                            <p class="text-dark" style="font-size: 17px; line-height: 1.8; opacity: 0.85;">
                                At Bright Beginnings Montessori, we believe that children learn best when they are trusted, respected, and empowered to take an active role in their own development.
                            </p>
                            <p class="text-dark mb-0" style="font-size: 17px; line-height: 1.8; opacity: 0.85;">
                                We strive to nurture not only academic growth, but also resilience, responsibility, creativity, and compassion—laying the foundation for a lifetime of learning, self-belief, and meaningful contribution to the world around them.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Vision Section (Exact Logo Surf/Teal) -->
            <div class="col-md-12">
                <div class="about-box shadow-sm" style="background: rgba(13, 190, 185, 0.15); border: 1px solid rgba(13, 190, 185, 0.2); border-radius: 20px; padding: 50px;">
                    <div class="row align-items-center flex-column-reverse flex-md-row">
                        <div class="col-md-7" data-aos="fade-right">
                            <div class="d-flex align-items-center mb-3">
                                <div class="icon-box me-3 d-flex align-items-center justify-content-center shadow-sm" style="background: #0DBEB9; color: #ffffff; width: 60px; height: 60px; border-radius: 50%;">
                                    <i class="bi bi-eye" style="font-size: 28px;"></i>
                                </div>
                                <h2 class="mb-0 fw-bold" style="color: #0DBEB9;">Our Vision</h2>
                            </div>
                            
                            <h4 class="mb-3" style="color: #444; font-weight: 600;">A Generation That Reaches First and Doubts Second</h4>
                            
                            <p class="text-dark mb-0" style="font-size: 17px; line-height: 1.8; opacity: 0.85;">
                                A world where children leave us with one unshakeable belief: I am capable. Not because someone told them — because they lived it, every single day, in an environment built to expect it of them.
                            </p>
                        </div>
                        <div class="col-md-5 text-center mb-4 mb-md-0" data-aos="fade-left">
                            <img src="{{ asset('Front/images/vv.jpg') }}" alt="Vision" class="img-fluid rounded-circle shadow" style="width: 300px; height: 300px; object-fit: cover; border: 8px solid rgba(13, 190, 185, 0.3);">
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Philosophy Section (Premium Deep Blue) -->
            <div class="col-md-12">
                <div class="about-box shadow-sm" style="background: rgba(26, 43, 76, 0.05); border: 1px solid rgba(26, 43, 76, 0.1); border-radius: 20px; padding: 50px;">
                    <div class="row align-items-center">
                        <div class="col-md-5 text-center mb-4 mb-md-0" data-aos="fade-right">
                            <img src="{{ asset('Front/images/philo.jpg') }}" alt="Philosophy" class="img-fluid rounded-circle shadow" style="width: 300px; height: 300px; object-fit: cover; border: 8px solid rgba(26, 43, 76, 0.15);">
                        </div>
                        <div class="col-md-7" data-aos="fade-left">
                            <div class="d-flex align-items-center mb-3">
                                <div class="icon-box me-3 d-flex align-items-center justify-content-center shadow-sm" style="background: #1a2b4c; color: #ffffff; width: 60px; height: 60px; border-radius: 50%;">
                                    <i class="bi bi-lightbulb" style="font-size: 28px;"></i>
                                </div>
                                <h2 class="mb-0 fw-bold" style="color: #1a2b4c;">Our Philosophy</h2>
                            </div>
                            
                            <h4 class="mb-3" style="color: #444; font-weight: 600;">Every Child Is the Only Child</h4>
                            
                            <p class="text-dark mb-0" style="font-size: 17px; line-height: 1.8; opacity: 0.85;">
                                We believe capability is not given — it is uncovered. Every child arrives with a unique developmental thread: a set of sensitive periods, a natural pace, a particular way of making sense of the world. Our Guides are trained to find that thread, follow it, and never interrupt it.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="explore section-100 pb-0 ">
    <div class="container">
        <div class="row d-md-flex align-items-center">
            <div class="col-md-12 text-center" data-aos="fade-left">
                <!-- Applied logo colors for perfect page consistency -->
                <span class="sxt fw-bold text-uppercase tracking-wider" style="color: #9D74B4;">Explore</span>
                <h1 class="mt-0 mb-4 fw-600" style="color: #1a2b4c;">Gallery</h1>

            </div>
            <div class="col-md-12 text-center   ">
                <div class="row g-1">
                    @foreach ($galleries as $gallery)
                    <div class="col-md-3" data-aos="fade-up" data-aos-delay="100">
                        <div class="hg-img efx mb-0">
                            <a href="{{ url('upload/' . $gallery->image) }}" data-fancybox="gallery-a" data-caption="{{ $gallery->title }}">
                                <img src="{{ url('upload/' . $gallery->image) }}" />
                            </a>
                        </div>
                    </div>
                    @endforeach
                </div>

                <a href="{{route('photo_gallery')}}" class="mbtn-blue mt-4 mb-5" style="background-color: #0DBEB9; border-color: #0DBEB9;">View All Photos</a>
            </div>
        </div>
    </div>
</section>

@include('front.layouts.footer')
