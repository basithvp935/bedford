@include('front.layouts.header')

<section class="explore gallery-page section-100 ">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-12 " data-aos="fade-left">
                <span class="sxt">Explore</span>
                <h1 class="mt-0 mb-3 fw-600"> Video Gallery</h1>

                   </div>

            @foreach($videoGallery as $item)
                   <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                            <div class="gallery-list h-auto">
                                <iframe class="m-0 p-0" width="100%" height="268" src="https://www.youtube.com/embed/{{$item->iframe}}" title="H.E The Indian Ambassador addresses ISG students on 77th Independence Day" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                                   <p class="bg-white p-3 lh-base"> {{$item->description}}</p>
                            </div>

                        </div>
            @endforeach

            </div>

        </div>

</section>

@include('front.layouts.footer')
