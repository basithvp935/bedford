@section('title', 'Gallery - Dayapuram Residential School - Best Residential school ')
@section('description', 'Explore the gallery of Dayapuram Residential School , showcasing our state-of-the-art facilities, vibrant student life, and enriching extracurricular activities.')
@section('circulars', 'active')
@include('front.layouts.header')

<section class="explore gallery-page section-100 ">
    <div class="container">
        <!--<div class="row ">-->
        <!--    <div class="col-md-12">-->
        <!--        <img src="{{ asset('Front/images/noble.jpg') }}" class="about-img mb-3 mb-md-5" alt="">-->
        <!--    </div>-->
        <!--</div>-->
        
        <div class="row g-md-5 mt-2">
            <div class="col-md-12 " data-aos="fade-left">
                <span class="sxt">Explore</span>
                <h1 class="mt-0 mb-4 fw-600">Gallery</h1>
                <div class="row g-3">
                    
                    
                    @foreach ($galleries as $gallery)
                        <div class="col-md-3" data-aos="fade-up" data-aos-delay="100">
                            <div class="gallery-list">
                                <img src="{{ url('upload/' . $gallery->image) }}" />
                            </div>
                            <!--<a href="{{route('photo_gallery_details',$gallery->id)}}" class="gallery-btn mt-2">{{ $gallery->title }}</a>-->
                            <a href="{{route('photo_gallery_details',$gallery->id)}}" class="gallery-btn mt-2">{{ $gallery->title }}</a>
                        </div>
                    @endforeach
                </div>
            </div>
            <!--<div class="col-md-4" data-aos="fade-left">-->
            <!--    <div class="imp-list">-->
            <!--        <h6> <img src="{{ asset('Front/images/icons/calendar.svg')}}" class="d-inline me-2 " alt=""> Important Date</h6>-->
            <!--        @foreach ($newses as $newse)-->
            <!--        <div class="flex mb-3">-->
            <!--            <div class="ps-3">-->
            <!--                <img class="star-img " src="{{ asset('Front/images/icons/star.svg')}}" alt="">-->
            <!--            </div>-->
            <!--            <div class="px-3">-->
            <!--                <h5>{{\Carbon\Carbon::parse($newse->date)->format('d m,Y')}}</h5>-->
            <!--                <p>{{$newse->title}}</p>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--        @endforeach-->
            <!--    </div>-->
            <!--</div>-->
        </div>
    </div>
</section>

@include('front.layouts.footer')
