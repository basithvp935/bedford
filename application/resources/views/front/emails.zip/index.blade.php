@section('title', 'Bright Beginnings Ksa - Best Residential school ')
@section('description', 'Discover Bright Beginnings Ksa - Best Residential school. Offering world-class education, holistic development, and a global curriculum to shape future leaders. Enroll today')
@section('home', 'active')
 <div class="bg-grid">
@include('front.layouts.header')
 <!-- Hero -->
    <main class="hero hero-kids">
      <div class="hero-bg" aria-hidden="true">
        <span class="cloud c1"></span>
        <span class="cloud c2"></span>
        <span class="cloud c3"></span>
        <span class="cloud c4"></span>
        <span class="cloud c5"></span>
        <span class="cloud c6"></span>
        <!-- <span class="kite k1"></span>
        <span class="kite k2"></span> -->
        <span class="plane p1"></span>
        <span class="doodle d1"></span>
        <span class="doodle d2"></span>
        <span class="doodle d3"></span>
      </div>
      <div class="container-xxl">
        <div class="row align-items-center g-4 g-lg-5 ">
          <div class="col-lg-6">
            <div class="kicker">
              <span class="dot"></span>
              <span>Learning Support</span>
            </div>
            <h1 class="display-2">
              <span class="sun">Bright </span><br />
              <span class="plum">Beginings?</span>
            </h1>
            <p>
             WHERE A LIFETIME OF LEARNING BEGINS
            </p>
            <div class="hero-actions">
              <a
                class="btn btn-primary cta text-white d-inline-flex align-items-center gap-2"
                href="#"
              >
                Addmission<i class="bi bi-arrow-right"></i>
              </a>
              <!-- <a
                class="btn btn-soft d-inline-flex align-items-center gap-2"
                href="#"
              >
                How it works <i class="bi bi-play-circle"></i>
              </a> -->
            </div>
          </div>

          <div class="col-lg-6">
            <div class="portrait-wrap">
              <!-- Decorative Background shapes (Mockup Design) -->
              <div class="hero-shape shape-stripes-top" aria-hidden="true"></div>
              <div class="hero-shape shape-circle-yellow" aria-hidden="true"></div>
              
              <!-- Top Toy SVG Icon (Cone version) replacing the + -->
              <div class="hero-shape shape-plus-top" aria-hidden="true">
                <svg width="40" height="45" viewBox="0 0 100 120" xmlns="http://www.w3.org/2000/svg">
                  <!-- Red Cone -->
                  <path d="M 36 40 L 45 12 Q 50 2 55 12 L 64 40 Z" fill="#ff1744"/>
                  <!-- Orange Ring -->
                  <rect x="30" y="34" width="40" height="16" rx="8" fill="#ff9100"/>
                  <!-- Yellow Ring -->
                  <rect x="24" y="48" width="52" height="16" rx="8" fill="#ffea00"/>
                  <!-- Green Ring -->
                  <rect x="18" y="62" width="64" height="16" rx="8" fill="#00e676"/>
                  <!-- Blue Ring -->
                  <rect x="12" y="76" width="76" height="16" rx="8" fill="#00b0ff"/>
                  <!-- Purple Ring -->
                  <rect x="6" y="90" width="88" height="16" rx="8" fill="#d500f9"/>
                  <!-- Red Ring -->
                  <rect x="0" y="104" width="100" height="16" rx="8" fill="#ff1744"/>
                </svg>
              </div>

              <div class="portrait" aria-label="Smiling child learning">
                <!-- Image Slider (3 Images, 3 seconds interval) -->
                <div id="heroCarousel" class="carousel slide w-100 h-100" data-bs-ride="carousel" data-bs-interval="3000">
                  <div class="carousel-inner w-100 h-100" style="border-radius: inherit;">
                    
                    <div class="carousel-item active w-100 h-100">
                      <img
                        src="{{ asset('Front/images/hero.png') }}"
                        alt="Smiling child learning 1"
                        style="display: block; width: 100%; height: 100%; object-fit: cover;"
                      />
                    </div>
                    
                    <div class="carousel-item w-100 h-100">
                      <img
                        src="{{ asset('Front/images/home.jpg') }}"
                        alt="Smiling child learning 2"
                        style="display: block; width: 100%; height: 100%; object-fit: cover;"
                      />
                    </div>
                    
                    <div class="carousel-item w-100 h-100">
                      <img
                        src="{{ asset('Front/images/children-playing.jpg') }}"
                        alt="Smiling child learning 3"
                        style="display: block; width: 100%; height: 100%; object-fit: cover;"
                      />
                    </div>

                  </div>
                </div>
              </div>

              <!-- Decorative Foreground shapes (Mockup Design) -->
              <div class="hero-shape shape-dots-left" aria-hidden="true">
                <div class="dots-grid"></div>
                <svg class="zigzag-line" width="60" height="15" viewBox="0 0 60 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M2 13L12 3L22 13L32 3L42 13L52 3" stroke="#0cbab9" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </div>
              <div class="hero-shape shape-stripes-bottom" aria-hidden="true"></div>
              
              <!-- Bottom Toy SVG Icon (Cone version) replacing the + -->
              <div class="hero-shape shape-plus-bottom" aria-hidden="true">
                <svg width="40" height="45" viewBox="0 0 100 120" xmlns="http://www.w3.org/2000/svg">
                  <!-- Red Cone -->
                  <path d="M 36 40 L 45 12 Q 50 2 55 12 L 64 40 Z" fill="#ff1744"/>
                  <!-- Orange Ring -->
                  <rect x="30" y="34" width="40" height="16" rx="8" fill="#ff9100"/>
                  <!-- Yellow Ring -->
                  <rect x="24" y="48" width="52" height="16" rx="8" fill="#ffea00"/>
                  <!-- Green Ring -->
                  <rect x="18" y="62" width="64" height="16" rx="8" fill="#00e676"/>
                  <!-- Blue Ring -->
                  <rect x="12" y="76" width="76" height="16" rx="8" fill="#00b0ff"/>
                  <!-- Purple Ring -->
                  <rect x="6" y="90" width="88" height="16" rx="8" fill="#d500f9"/>
                  <!-- Red Ring -->
                  <rect x="0" y="104" width="100" height="16" rx="8" fill="#ff1744"/>
                </svg>
              </div>

              <div class="floaty" aria-hidden="true">
                <div class="sticker s1"><i class="bi bi-pencil-fill"></i></div>
                <div class="sticker s2"><i class="bi bi-book-fill"></i></div>
                <div class="sticker s3"><i class="bi bi-stars"></i></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>

<div class="container news-scroll">
    <div class="row">
        <div class="col-md-12">
            <div class="flash-news shadow-sm" id='abt'>
                <div class="news-title aos-init">
                    <span id="news-head" class="text-uppercase fw-500"> <img src="{{ asset('Front/images/news-icon.png') }}" class="notice-top-border mx-auto" alt=""></span>
                </div>
                <div class="news-text ">
                    <marquee behavior="scroll" scrollamount="4" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
                        <span>
                            <a href="#">
                                <p class=" pe-2 ps-2">
                                    <!--WELCOME TO Bright Beginnings Ksa-->
                                    {!! $flash_news->news_title ?? 'Bright Beginnings Ksa' !!}
                                </p>
                                <!--<span style="font-size: 22px; font-weight: 400"></span>-->
                            </a>
                        </span>
                    </marquee>
                </div>
            </div>
        </div>
    </div>
</div>


<!--ABOUT-->

<section class="about home-about pt-5 pb-5 about-enhanced image-bg" style="margin-top: -20px;">
    <div class="container">
        <div class="row d-md-flex align-items-center g-3 g-md-5">
            <div class="col-md-12 text-center">
          
            </div>

            <div class="col-md-8">
                <div data-aos="fade-right">
                   <h6 class="title-heading about-kicker"><span class="dot" aria-hidden="true"></span>Bright Beginnings Ksa</h6>
                    <h1 class="pb-2 mt- about-title"><span class="t1">OUR </span> <span class="t2"> STORY:</span></h1>
                    
                    <div class="in-txt mt-4">
                        <div class="mb-4">
                            <h6 class="text-uppercase mb-2" style="color: #3b987b; letter-spacing: 1px;">WHERE WE BEGAN &middot; 30 YEARS AGO</h6>
                            <h4 class="mb-2">Little Angels Kindergarten, Al Khobar</h4>
                            <p class="mb-0">We opened our doors with a simple belief: every child learns differently. Our individual teaching system quickly earned the trust of families across the community, making Little Angels a name synonymous with warmth, quality, and care.</p>
                        </div>
                        
                        <div class="mb-0">
                            <h6 class="text-uppercase mb-2" style="color: #7e63b6; letter-spacing: 1px;">WHERE WE ARE TODAY</h6>
                            <h4 class="mb-2">Bright Beginnings Montessori</h4>
                            <p class="mb-0">The same founding spirit, elevated. We return with a fully authentic Montessori environment and our signature Bright Thread teaching methodology — a structured, child-centred framework built on everything we learned over three decades.</p>
                        </div>
                    </div>

                    <div class="about-stats d-flex gap-3 mt-4" aria-hidden="true">
                            <div class="stat">
                                <div class="stat-num">10K </div>
                                <div class="stat-label">+ Children inspired </div>
                            </div>
                            <div class="stat">
                                <div class="stat-num">200</div>
                                <div class="stat-label">+ Community Initiatives </div>
                            </div>
                            <div class="stat">
                                <div class="stat-num">30</div>
                                <div class="stat-label">+ Years of Service</div>
                            </div>
                        </div>
                    <a href="#" class="main-btn mt-4">Read more</a>
                </div>
            </div>

          
            <div class="col-md-4" data-aos="fade-left">
                <div class="about-portrait-wrap">
                    <!-- Main organic image card (Mockup Design) -->
                    <div class="about-portrait">
                        <img src="{{ asset('Front/images/home-about.jpg') }}" alt="Bright Beginnings Ksa child studying" />
                        
                        <!-- Floating Awards Badge (Mockup Design) -->
                        <div class="about-badge-awards">
                            <div class="badge-icon">
                                <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="trophy-svg">
                                    <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"></path>
                                    <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"></path>
                                    <path d="M4 22h16"></path>
                                    <path d="M10 14.66V17c0 .55-.45 1-1 1H4v2h16v-2h-5c-.55 0-1-.45-1-1v-2.34"></path>
                                    <path d="M12 2a6 6 0 0 1 6 6v5a6 6 0 0 1-6-6V8a6 6 0 0 1 6-6z"></path>
                                </svg>
                            </div>
                            <div class="badge-content">
                                <span class="badge-number">+23</span>
                                <span class="badge-label">Awards</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>




<section class=" pt-80 pb-80 president-msg">
    <div class=" pb-5 pt-0 image-bg cards-section">
    <div class="container">
        <div class="row">
              <div class="col-md-4" data-aos="fade-left">
                      <div class="notice-box  shadow-sm h-100">
                    <div class="text-center">

                        <img src="{{ asset('Front/images/notice-top.png') }}" class="notice-top-border mx-auto" alt="">

                        <h3 class="itle-heading about-kicker mb-0">NOTICE</h3>
                    </div>
                    <div class="slick slick-4 mb-0 text-center">
                        @foreach ($notices as $notice)
                            <div class="">
                                <h5 class="fw-800">{{ $notice->title }}</h5>
                                <p  class="notice-desc">{!! $notice->description !!}</p>
                                <span class="notice-date mt-4 d-inline-block " style="margin-bottom: 25px;">{{ \Carbon\Carbon::parse($notice->date)->format('jS M, Y') }}</span>

                            </div>
                        @endforeach

                    </div>
                    <div class="carrow d-flex">


                        <a class="prev" href="#"><i data-feather="arrow-left-circle"></i></a>
                        <a class="next" href="#"><i data-feather="arrow-right-circle"></i></a>
                    </div>
                </div>
            
            </div>

            <div class="col-md-4" data-aos="fade-up">
                <a href='#' >
                    <div class="card text-center h-100 overlay-card">
                        <div class="badge-new">New</div>
                        <div class="card-body p-2">
                            <img src="https://credozen.in/bright/application/public/Front/images/online-admission.jpg" class="w-100 rounded" alt="">
                            <h6 class="mb-0 text-uppercase overlay-title">Online Admission</h6>
                        </div>
                    </div> 
                </a>
            </div>

            <div class="col-md-4" data-aos="fade-up">
                <a href='#' >
                    <div class="card text-center h-100 overlay-card">
                        <div class="badge-new" style="background:var(--c-navy);">Pay</div>
                        <div class="card-body p-2">
                            <img src="https://credozen.in/bright/application/public/Front/images/fee-payment.jpg" class="w-100 rounded" alt="">
                            <h6 class="mb-0 text-uppercase overlay-title">Fee Payment</h6>
                        </div>
                    </div>
                </a>
            </div>

        </div>
       
    </div>
</div>

  <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="from-home bg-wow p-md-5 p-4 president-card">
                    <div class="row d-md-flex align-items-center g-md-5 g-4">
                        <div class="col-md-4 " data-aos="fade-right">
                            <div class="president-photo-wrap">
                                <img src="https://ruralpromise.appstate.edu/app/uploads/2026/02/headshot-default2.jpg" alt="" class="president-photo">
                            </div>
                        </div>
                        <div class="col-md-8" data-aos="fade-right">
                            <div class="in-cnt-pd">

                                <h6 class="president-kicker mb-2"><span class="dot" aria-hidden="true"></span>Founder’s Message</h6>
                                

                               
                                <h3 class="d-block mb-3 president-name">Nazrath A. G</h3>
                                <div class="in-txt text-white president-quote">
                                    <p>Every child who walks through our doors arrives with limitless potential, a natural curiosity, and a unique way of seeing the world. It has always been my belief that education should honour that individuality and provide children with the freedom, confidence, and support to become the very best version of themselves.</p>
                                    <p>The values that guided Little Angels for so many years continue to guide us today: respect for the child, meaningful relationships, and a commitment to seeing each child not for who they are expected to be, but for who they already are.</p>
                                    <p>Every child arrives with a spark uniquely their own. At Bright Beginnings Montessori, we believe that spark deserves to be nurtured — not rushed, not compared, but celebrated.</p>
                                    <p>Rooted in an authentic Montessori environment, our classrooms are more than learning spaces — they are a second home. A place of warmth, wonder, and discovery, where children feel safe to explore, ask questions, and grow into confident, capable individuals.</p>
                                    <p>To every family who walks through our doors — thank you for trusting us with your most precious gift. Together, we are nurturing bright beginnings, one child at a time.</p>
                                    <p class="mb-0">Welcome to our family.</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

<!--TIMELINE-->


<section class="calendar pt-60 pb-60 calendar-enhanced">
    <div class="container">
        <div class="row">


            <div class="col-md-6 mb-4" data-aos="fade-left">
                

                <div class="event-cnd"> 
                     <span class="section-kicker mb-3"><span class="dot" aria-hidden="true"></span>Event Calendar</span>
                <!--<h1 class="mt-0 mb-3 section-heading">Calendar</h1>-->
                    <div class="in-cnd">
                        <div id="calendar"></div>
                    </div>
                </div>
            </div>
 <div class="col-md-6 mb-4 aos-init aos-animate" data-aos="fade-right">
              
                <div class="calendar-hero h-100">
                   <img src="{{ asset('Front/images/children-playing.jpg
') }}" alt="">
                    <div class="calendar-hero-ov">
                        <span class="calendar-hero-chip"><span class="dot" aria-hidden="true"></span>Highlights</span>
                        <h3 class="calendar-hero-title m-0">A year full of learning, sports &amp; culture</h3>
                        <p class="calendar-hero-sub m-0 text-white">See what’s next on the event calendar and never miss a key date.</p>
                    </div>
                </div>
            </div>


         

    </div>
    </div>

</section>


<!--EXPLORE-->
<section class="explore section-100 explore-enhanced" id='gallery-sec'>
    <div class="container">
        <div class="row d-md-flex d-flex align-items-center">
           <div class="col-md-6 col-6" data-aos="fade-right">
                <span class="section-kicker"><span class="dot" aria-hidden="true"></span>Explore</span>
                <h1 class="pb-3 mt-0 section-heading" data-aos="fade-right" data-aos-delay="50">Gallery</h1>
            </div>
            <div class="col-md-6 col-6 text-end" data-aos="fade-left">
                <a href="#" class="main-btn">View All</a>
            </div>

            <div class="col-md-12">
                <div class="row nopad">

                    @foreach ($galleries as $g_index => $gallery)
                        <div class="col-md-3" data-aos="fade-up" data-aos-delay=" @if ($g_index == 0) 50 @elseif($g_index == 1)100 @elseif($g_index == 2)200 @else 250 @endif">
                            <div class="hg-img efx position-relative gallery-tile"><a href="#"><img src="{{ url('upload/' . $gallery->image) }}" alt="">
                                    <span class="w-100 gallery-label" >{{ $gallery->title }}</span>
                                </a>

                            </div>
                        </div>
                    @endforeach
                    
                     
                        
                </div>
            </div>
        </div>
    </div>
</section>

<!--ENVIRONMENTS-->
<section class="facilities section-100 image-bg facilities-enhanced" id='fclty'>
    <div class="facilities-cards">
        <div class="container">
            <div class="row d-md-flex d-flex align-items-center">
              <div class="col-md-6 col-6" data-aos="fade-right">
                    <span class="section-kicker"><span class="dot" aria-hidden="true"></span>Our</span>
                    <h1 class="pb-3 mt-0 section-heading" data-aos="fade-right" data-aos-delay="50">Environments</h1>
                </div>
                <div class="col-md-6 col-6 text-end" data-aos="fade-left">
                    <a href="#" class="main-btn">View All</a>
                </div>
                <div class="col-md-12">
                    <div class="slick slick-3 mb-4">

                        @foreach ($facilities as $g_index => $facility)
                            <div class="ne h-100">
                                <div class="item efx h-100" data-aos="fade-up" data-aos-delay="{{ $g_index * 100 }}">
                                    <div class="efx-img"><img src="{{ url('upload/' . $facility->img) }}" alt=""></div>
                                    <div class="ov-content">
                                        <div class="details ">
                                            <h5>{{ $facility->title ?? $facility->name ?? '' }}</h5>
                                            
                                            <!-- using strip_tags() to remove hidden admin margins and wrap in the template's aligned p tag -->
                                            <p class="mb-0">
                                                {!! strip_tags($facility->description ?? $facility->discription ?? $facility->content ?? '') !!}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach

                    </div>
                    
                    <div class="carrow d-flex justify-content-center mt-3 gap-3">
                        <a class="prev" href="#"><i data-feather="arrow-left-circle"></i></a>
                        <a class="next" href="#"><i data-feather="arrow-right-circle"></i></a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>



<section class="facilities news-events-enhanced">


    <div class="container">
        <div class="row d-md-flex d-flex ">
            <div class="col-md-6 col-6">

                 <div class="col-md-6 col-6">
                <div class="pb-3 mt-0 in-cnt-pd" data-aos="fade-right">
                    <span class="section-kicker"><span class="dot" aria-hidden="true"></span>Updates</span>
                    <h1 class="section-heading">News &amp; Events</h1>
                </div>
            </div>
            </div>
            <div class="col-md-6 col-6 text-end" data-aos="fade-left">
                <a href="#" class="main-btn">View All</a>
            </div>
            <div class="col-md-12">
                <div class="row g-4">

                    @foreach ($newses as $newse)
                        <div class="col-md-3">
                            <div class="card h-100">
                                <div class="card-body news-card">
                             <div class="news-thumb">
                                        <img src="{{ url('upload/' . $newse->thumb_img) }}" alt="" style="border-radius: 8px">
                                    </div>
                                    <div class="pt-3">
                                        <h4>{{ $newse->news_title }}</h4>
                                        <p>{{ \Carbon\Carbon::parse($newse->news_date)->format('d m, Y') }}</p>
                                        <a href="#" class="main-btn mt-2" style="font-size: 14px;">Read
                                            more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

        </div>
    </div>




    </div>
</section>


@include('front.layouts.footer')
