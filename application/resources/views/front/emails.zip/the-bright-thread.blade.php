@section('title', 'Careers - indian school - Best International school in Qatar | Doha')
@section('description', 'Join the Noble Indian School team in Doha! Explore exciting career opportunities at one of the best international schools, dedicated to academic excellence and growth.')
@section('career', 'active')
@include('front.layouts.header')
<style>
    /* Page Specific Styles */
    .bright-thread-page {
        font-family: 'Nunito', sans-serif;
        color: #1a2b4c;
        background-color: #ffffff;
    }

    /* ==========================================
       NEW HERO BANNER (CENTERED HEADING) 
       ========================================== */
    .bright-banner {
        position: relative;
        width: 100vw;
        margin-left: calc(-50vw + 50%);
        max-width: 100vw;
        height: 450px; 
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        background-attachment: fixed;
    }

    .banner-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.4); 
        z-index: 1;
    }

    .banner-text {
        position: relative;
        z-index: 2;
        text-align: center;
        width: 100%;
    }

    .banner-title {
        font-family: 'Georgia', serif; 
        color: #ffffff;
        font-size: 3rem;
        font-weight: 700;
        margin: 0;
        text-transform: capitalize;
        text-shadow: 2px 2px 10px rgba(0,0,0,0.4);
    }

    @media (max-width: 768px) {
        .banner-title {
            font-size: 1.8rem;
        }
        .bright-banner {
            height: 300px;
        }
    }

    /* ========================================== */

    .hero-section {
        padding: 4rem 0 4rem;
        background: #fdfdfc;
    }

    /* INTRO BOX WITH HOVER EFFECT */
    .intro-box {
        background: linear-gradient(135deg, rgba(157, 116, 180, 0.05) 0%, rgba(255, 255, 255, 1) 100%);
        border: 1px solid rgba(157, 116, 180, 0.15);
        border-radius: 24px;
        padding: 4rem;
        box-shadow: 0 15px 40px rgba(0,0,0,0.04);
        transition: transform 0.4s cubic-bezier(0.165, 0.84, 0.44, 1), box-shadow 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
    }

    .intro-box:hover {
        transform: translateY(-8px);
        box-shadow: 0 25px 50px rgba(0,0,0,0.08);
    }

    .intro-image {
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        width: 100%;
        height: 100%;
        min-height: 380px;
        object-fit: cover;
        transition: transform 0.4s ease;
    }

    .intro-box:hover .intro-image {
        transform: scale(1.02);
    }

    @media (max-width: 991px) {
        .intro-box {
            padding: 2.5rem;
        }
        .intro-image {
            min-height: 250px;
            margin-top: 2rem;
        }
    }

    .subtitle-label {
        color: #9D74B4;
        font-weight: 700;
        letter-spacing: 2px;
        text-transform: uppercase;
        font-size: 0.9rem;
        margin-bottom: 1rem;
        display: block;
    }

    .lead-text {
        font-size: 1.4rem;
        font-weight: 700;
        color: #9D74B4;
        line-height: 1.6;
        margin-bottom: 2rem;
    }

    .body-text {
        font-size: 1.15rem;
        line-height: 1.8;
        color: #475569;
        margin-bottom: 1.5rem;
    }

    /* Highlight Quote Box */
    .highlight-quote {
        background: rgba(157, 116, 180, 0.05); 
        border-left: 5px solid #9D74B4;
        padding: 2.5rem;
        border-radius: 0 20px 20px 0;
        margin: 3rem auto;
        box-shadow: 0 10px 30px rgba(0,0,0,0.02);
    }

    /* ==========================================
       HOW IT WORKS GRID (NEW DESIGN)
       ========================================== */
    .how-it-works-section {
        position: relative;
        overflow: hidden; /* Keeps floating icons contained horizontally */
    }

    /* Floating Decor Animation */
    .floating-icon {
        position: absolute;
        z-index: 0;
        opacity: 0.9;
        pointer-events: none; /* Prevents icons from blocking clicks */
        animation: floatAnim 6s ease-in-out infinite;
    }

    .floating-icon.sun {
        top: 5%;
        left: -3%;
        width: 140px;
        height: 140px;
    }

    .floating-icon.star {
        bottom: 8%;
        left: 5%;
        width: 80px;
        height: 80px;
        animation-delay: 1.5s; /* Offset animation timing */
    }

    .floating-icon.flask {
        top: 30%;
        right: -2%;
        width: 110px;
        height: 110px;
        animation-delay: 3s; /* Offset animation timing */
    }

    @keyframes floatAnim {
        0% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(-20px) rotate(5deg); }
        100% { transform: translateY(0px) rotate(0deg); }
    }

    /* Ensure content is above floating icons */
    .how-it-works-section .container {
        position: relative;
        z-index: 2; 
    }

    .how-it-works-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2.5rem 3rem; 
        margin-top: 3rem;
    }

    .how-it-works-item {
        position: relative;
        padding: 2.5rem 2rem 2.5rem 4rem; 
        background: #fff;
        border-radius: 16px;
        border: 1px solid #E2E8F0; 
        box-shadow: 0 8px 25px rgba(0,0,0,0.03);
        margin-left: 1.5rem; 
        transition: all 0.3s ease;
    }

    .how-it-works-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.06);
    }

    .how-it-works-icon-wrapper {
        position: absolute;
        left: -1.5rem; 
        top: 2rem;
        width: 60px;
        height: 60px;
        background: #fff;
        border: 2px solid rgba(157, 116, 180, 0.2);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 8px 20px rgba(0,0,0,0.04);
        transition: all 0.3s ease; 
    }

    .how-it-works-icon {
        color: #9D74B4; 
        transition: color 0.3s ease;
    }

    /* Make icon background solid purple and icon white ONLY on hover */
    .how-it-works-item:hover .how-it-works-icon-wrapper {
        background: #9D74B4;
        border-color: #9D74B4;
        box-shadow: 0 8px 20px rgba(157, 116, 180, 0.3);
        transform: scale(1.1);
    }

    .how-it-works-item:hover .how-it-works-icon {
        color: #ffffff;
    }

    .how-it-works-title {
        font-weight: 800;
        font-size: 1.2rem;
        margin-bottom: 0.8rem;
        color: #1a2b4c;
    }

    @media (max-width: 768px) {
        .how-it-works-grid {
            grid-template-columns: 1fr;
            gap: 2rem;
            margin-left: 0;
        }
        .how-it-works-item {
            margin-left: 1rem;
            padding: 2rem 1.5rem 2rem 3rem; 
        }
        .how-it-works-icon-wrapper {
            left: -1rem;
            width: 50px;
            height: 50px;
            top: 1.5rem;
        }
    }

    /* Table Section */
    .comparison-section {
        background: #fbfaf9;
        padding: 6rem 0;
        border-top: 1px solid #f0f0f0;
    }

    .comparison-label {
        font-size: 0.85rem;
        text-transform: uppercase;
        letter-spacing: 2px;
        color: #64748B;
        font-weight: 700;
        margin-bottom: 1.5rem;
        display: block;
    }

    .comparison-table {
        background: #fff;
        border-radius: 12px;
        border: 1px solid #E2E8F0;
        width: 100%;
        border-collapse: collapse;
        box-shadow: 0 4px 20px rgba(0,0,0,0.02);
        overflow: hidden;
    }

    .comparison-table td {
        padding: 1.5rem 2rem;
        border-bottom: 1px solid #E2E8F0;
        font-size: 1.1rem;
        transition: all 0.3s ease;
    }

    .comparison-table tbody tr {
        transition: all 0.3s ease;
    }

    .comparison-table tbody tr:hover td {
        background-color: rgba(157, 116, 180, 0.03); 
    }

    .comparison-table tbody tr:hover td:last-child {
        color: #9D74B4;
        transform: translateX(5px); 
    }

    .comparison-table tr:last-child td {
        border-bottom: none;
    }

    .comparison-table td:first-child {
        color: #64748B;
        width: 40%;
        border-right: 1px solid #E2E8F0;
    }

    .comparison-table td:last-child {
        color: #1a2b4c;
        font-weight: 700;
        width: 60%;
    }

    .final-quotes-section {
        padding: 5rem 0;
        text-align: center;
    }

    @media (max-width: 768px) {
        .comparison-table td {
            display: block;
            width: 100% !important;
            border-right: none !important;
        }
        .comparison-table td:first-child {
            border-bottom: none;
            padding-bottom: 0.5rem;
        }
        .comparison-table td:last-child {
            padding-top: 0.5rem;
            border-bottom: 1px solid #E2E8F0;
        }
        .comparison-table tbody tr:hover td:last-child {
            transform: translateX(0px); 
        }
    }
</style>

<div class="bright-thread-page">
    
    <!-- NEW HERO BANNER -->
    <section class="bright-banner" style="background: url('{{ asset('Front/images/brightban.jpg') }}') center top / cover no-repeat;">
        <div class="banner-overlay"></div>
        <div class="banner-text">
            <h1 class="banner-title">The Bright Thread</h1>
        </div>
    </section>

    <!-- Introduction Section (Split Box Layout) -->
    <section class="hero-section">
        <div class="container">
            <div class="intro-box">
                <div class="row align-items-center">
                    
                    <!-- Left Side: Content -->
                    <div class="col-lg-7 text-start pe-lg-5">
                        <span class="subtitle-label">Our Teaching Philosophy</span>
                        
                        <div class="lead-text mt-3" style="font-size: 1.6rem;">
                            "The Bright Thread — Because Every Child Is a One-of-a-Kind Story"
                        </div>

                        <p class="body-text">
                            Not a curriculum. Not a checklist. A commitment — to seeing each child as a whole, complex, extraordinary individual, and building their learning around who they already are.
                        </p>
                        <p class="body-text">
                            It answers one essential question we ask about every single child in our care:
                        </p>
                        
                        <div class="highlight-quote" style="margin: 2rem 0 0 0; padding: 2.5rem;">
                            <h4 class="fst-italic mb-0" style="color: #9D74B4; line-height: 1.6; font-weight: 700; font-size: 1.25rem;">
                                "What is the thread that, if we follow it, will lead this child to their fullest potential?"
                            </h4>
                        </div>
                    </div>

                    <!-- Right Side: Image -->
                    <div class="col-lg-5 mt-4 mt-lg-0">
                        <img src="{{ asset('Front/images/lege.jpg') }}" class="intro-image" alt="Teaching Philosophy">
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- Partnership & Image Section -->
    <section class="py-5">
        <div class="container">
            <div class="row align-items-center mb-5">
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <h2 class="fw-bold mb-4" style="color: #1a2b4c;">The Bright Thread & Montessori — <br>A Perfect Partnership</h2>
                    <p class="body-text">
                        Maria Montessori showed us that children are not empty vessels — they are natural learners, driven from within. The Montessori method gives us the structure: proven materials, trained guides, a prepared environment. 
                    </p>
                    <p class="body-text">
                        The Bright Thread gives us the intention: ensuring the method is applied to your child, specifically.
                    </p>
                    <p class="body-text fw-bold" style="color: #9D74B4;">
                        Together, they create something rare — a system that is both rigorously proven and deeply personal.
                    </p>
                </div>
                <div class="col-lg-6">
                    <img src="{{ asset('Front/images/lab1.jpg') }}" class="img-fluid w-100 shadow-lg" style="border-radius: 20px;" alt="Montessori Partnership">
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section (WITH SVG FLOATING DECORATIONS) -->
    <section class="how-it-works-section py-5">
        
        <!-- DECORATIVE FLOATING ICONS (Custom Hand-Drawn Style SVGs) -->
        
        <!-- SUN ICON -->
        <div class="floating-icon sun">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
                <!-- Sun fill -->
                <circle cx="50" cy="50" r="28" fill="#FDE047"/>
                <!-- Rays -->
                <path d="M50 8 L50 16 M50 84 L50 92 M8 50 L16 50 M84 50 L92 50 M20 20 L26 26 M74 74 L80 80 M20 80 L26 74 M74 20 L80 26" stroke="#FDE047" stroke-width="4" stroke-linecap="round"/>
                <!-- Eyes -->
                <circle cx="40" cy="45" r="2.5" fill="#4B5563"/>
                <circle cx="60" cy="45" r="2.5" fill="#4B5563"/>
                <!-- Smile -->
                <path d="M45 53 Q50 58 55 53" stroke="#4B5563" stroke-width="2.5" stroke-linecap="round" fill="none"/>
                <!-- Cheeks -->
                <circle cx="33" cy="50" r="3.5" fill="#FDA4AF" opacity="0.8"/>
                <circle cx="67" cy="50" r="3.5" fill="#FDA4AF" opacity="0.8"/>
            </svg>
        </div>

        <!-- STAR ICON -->
        <div class="floating-icon star">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
                <!-- Offset yellow fill -->
                <path d="M50 15 L61 38 L88 38 L66 54 L74 80 L50 64 L26 80 L34 54 L12 38 L39 38 Z" fill="#FEF08A" transform="translate(6, 6)"/>
                <!-- Grey outline -->
                <path d="M50 12 L63 39 L92 37 L68 56 L78 85 L50 66 L22 85 L32 56 L8 37 L37 39 Z" stroke="#6B7280" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"/>
            </svg>
        </div>

        <!-- FLASK ICON -->
        <div class="floating-icon flask">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
                <!-- Offset blue fill -->
                <path d="M40 20 L40 45 L20 80 Q15 90 25 90 L75 90 Q85 90 80 80 L60 45 L60 20 Z" fill="#BAE6FD" transform="translate(-4, 4)"/>
                <!-- Grey outline -->
                <path d="M35 15 L65 15 M40 15 L40 45 L20 80 Q15 88 25 88 L75 88 Q85 88 80 80 L60 45 L60 15" stroke="#6B7280" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"/>
                <!-- Liquid curve inside -->
                <path d="M22 75 Q50 82 78 75" stroke="#6B7280" stroke-width="4" stroke-linecap="round"/>
                <!-- Measurement marks -->
                <line x1="40" y1="25" x2="48" y2="25" stroke="#6B7280" stroke-width="3" stroke-linecap="round"/>
                <line x1="40" y1="33" x2="48" y2="33" stroke="#6B7280" stroke-width="3" stroke-linecap="round"/>
                <line x1="40" y1="41" x2="48" y2="41" stroke="#6B7280" stroke-width="3" stroke-linecap="round"/>
            </svg>
        </div>


        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <h2 class="fw-bold mb-5 text-center" style="color: #1a2b4c;">How the Bright Thread Works</h2>
                    
                    <div class="how-it-works-grid">
                        
                        <!-- Box 1 -->
                        <div class="how-it-works-item">
                            <div class="how-it-works-icon-wrapper">
                                <div class="how-it-works-icon">
                                    <!-- Eye Icon -->
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                </div>
                            </div>
                            <h3 class="how-it-works-title">We observe first</h3>
                            <p class="body-text mb-0" style="font-size: 1.05rem;">
                                Before guiding, we watch. What does this child return to? Where do they lose track of time? Observation is where every Bright Thread begins.
                            </p>
                        </div>

                        <!-- Box 2 -->
                        <div class="how-it-works-item">
                            <div class="how-it-works-icon-wrapper">
                                <div class="how-it-works-icon">
                                    <!-- Person Icon -->
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                </div>
                            </div>
                            <h3 class="how-it-works-title">We build an individual picture</h3>
                            <p class="body-text mb-0" style="font-size: 1.05rem;">
                                Not a report card — a living portrait. Daily observations, material choices, developmental stage, emotional needs, and your insight as a parent.
                            </p>
                        </div>

                        <!-- Box 3 -->
                        <div class="how-it-works-item">
                            <div class="how-it-works-icon-wrapper">
                                <div class="how-it-works-icon">
                                    <!-- Path Icon -->
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
                                </div>
                            </div>
                            <h3 class="how-it-works-title">We follow the child</h3>
                            <p class="body-text mb-0" style="font-size: 1.05rem;">
                                Children are never rushed past a concept or held back from flying. They move on when they're ready. Curiosity is the engine — not an external schedule.
                            </p>
                        </div>

                        <!-- Box 4 -->
                        <div class="how-it-works-item">
                            <div class="how-it-works-icon-wrapper">
                                <div class="how-it-works-icon">
                                    <!-- Heart Icon -->
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                                </div>
                            </div>
                            <h3 class="how-it-works-title">We involve you</h3>
                            <p class="body-text mb-0" style="font-size: 1.05rem;">
                                Your child's thread runs through your home too. Regular check-ins and open conversations ensure you're never a bystander in their journey.
                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Comparison Table Section -->
    <section class="comparison-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <span class="comparison-label">What Makes This Different</span>
                    
                    <table class="comparison-table">
                        <tbody>
                            <tr>
                                <td>Other approaches</td>
                                <td>The Bright Thread</td>
                            </tr>
                            <tr>
                                <td>A fixed plan for all children</td>
                                <td>A living picture unique to each child</td>
                            </tr>
                            <tr>
                                <td>Labelling by ability</td>
                                <td>Honouring each child's current place in their journey</td>
                            </tr>
                            <tr>
                                <td>Keeping pace with others</td>
                                <td>Unfolding at their own pace</td>
                            </tr>
                            <tr>
                                <td>Standardised testing</td>
                                <td>Deep observation and individual progress tracking</td>
                            </tr>
                        </tbody>
                    </table>
                    
                </div>
            </div>
        </div>
    </section>

    <!-- Final Quotes Section -->
    <section class="final-quotes-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h3 class="fw-bold mb-5" style="color: #9D74B4; line-height: 1.6;">
                        "Your child is not like any other child who has ever walked through our doors. We think that's the whole point."
                    </h3>
                    
                    <div style="width: 60px; height: 3px; background: #0DBEB9; margin: 0 auto 3rem auto;"></div>

                    <h4 class="fst-italic" style="color: #1a2b4c;">"Follow the child."</h4>
                    <p class="fw-bold text-uppercase mt-3" style="letter-spacing: 2px; color: #475569;">— Maria Montessori</p>
                </div>
            </div>
        </div>
    </section>

</div>

@include('front.layouts.footer')
