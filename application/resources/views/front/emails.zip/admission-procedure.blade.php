@section('title', 'Admission – Bright Beginnings Montessori')
@section('description', 'Learn about the admission process, age criteria, and enrollment details for Bright Beginnings Montessori.')
@section('admission', 'active')
@include('front.layouts.header')

<div class="page-top"></div>

<!-- Custom Styles for Premium Admission Page -->
<style>
    /* Premium Background */
    .admission-page-wrapper {
        background-color: #f4faff;
        background-image: 
            linear-gradient(rgba(13, 190, 185, 0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(13, 190, 185, 0.04) 1px, transparent 1px);
        background-size: 40px 40px;
        background-position: center top;
        padding-top: 5rem;
        padding-bottom: 5rem;
    }

    /* Premium White Card Wrapper */
    .premium-card {
        background: #ffffff;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.03);
        border: 1px solid rgba(13, 190, 185, 0.1);
        overflow: hidden;
    }

    /* Premium Hover Accordion Styles (Matching About Page) */
    .premium-accordion .accordion-item {
        border-radius: 12px !important;
        margin-bottom: 15px;
        transition: all 0.3s ease-in-out;
        box-shadow: 0 4px 6px rgba(0,0,0,0.02);
        overflow: hidden;
        border: 1px solid transparent !important;
    }

    /* 1. Purple Theme */
    .premium-accordion .accordion-item:nth-child(3n+1) {
        background-color: rgba(157, 116, 180, 0.12) !important;
        border-color: rgba(157, 116, 180, 0.3) !important;
    }
    .premium-accordion .accordion-item:nth-child(3n+1):hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 24px rgba(157, 116, 180, 0.15);
        border-color: rgba(157, 116, 180, 0.5) !important;
    }
    
    /* 2. Surf/Teal Theme */
    .premium-accordion .accordion-item:nth-child(3n+2) {
        background-color: rgba(13, 190, 185, 0.12) !important;
        border-color: rgba(13, 190, 185, 0.3) !important;
    }
    .premium-accordion .accordion-item:nth-child(3n+2):hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 24px rgba(13, 190, 185, 0.15);
        border-color: rgba(13, 190, 185, 0.5) !important;
    }

    /* 3. Gold Theme */
    .premium-accordion .accordion-item:nth-child(3n+3) {
        background-color: rgba(196, 192, 104, 0.12) !important;
        border-color: rgba(196, 192, 104, 0.3) !important;
    }
    .premium-accordion .accordion-item:nth-child(3n+3):hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 24px rgba(196, 192, 104, 0.15);
        border-color: rgba(196, 192, 104, 0.5) !important;
    }

    /* Accordion Button Text Styling - EXACT LOGO PURPLE */
    .premium-accordion .accordion-button {
        font-weight: 700;
        font-size: 1.15rem;
        color: #9D74B4 !important; /* Logo Purple */
        background: transparent !important;
        padding: 1.25rem 1.5rem;
        transition: all 0.3s ease-in-out;
        border-radius: 12px !important;
        box-shadow: none !important;
    }

    .premium-accordion .accordion-button:hover {
        color: #8a659e !important;
    }

    .premium-accordion .accordion-button:not(.collapsed) {
        color: #9D74B4 !important; 
        border-bottom-left-radius: 0 !important;
        border-bottom-right-radius: 0 !important;
    }
    
    .premium-accordion .accordion-button::after {
        filter: none;
    }

    /* Ensure content area is white so text is readable */
    .premium-accordion .accordion-collapse {
        border-top: 1px solid rgba(0, 0, 0, 0.05);
        background-color: #ffffff;
    }
    .premium-accordion .accordion-body {
        background-color: #ffffff !important;
        padding: 2rem;
    }

    /* Content Typography inside accordion */
    .premium-accordion .accordion-body p {
        color: #64748b;
        line-height: 1.7;
        margin-bottom: 1rem;
    }
    .premium-accordion .accordion-body h5 {
        color: #1a2b4c;
        font-weight: 700;
        margin-top: 1.5rem;
        margin-bottom: 1rem;
    }
    .premium-accordion .accordion-body ul li {
        color: #64748b;
        margin-bottom: 0.75rem;
        position: relative;
        padding-left: 1.5rem;
        list-style-type: none;
    }
    .premium-accordion .accordion-body ul li::before {
        content: "•";
        color: #0DBEB9;
        font-weight: bold;
        display: inline-block; 
        width: 1em;
        margin-left: -1em;
        position: absolute;
        left: 0;
    }
</style>

<section class="admission-page-wrapper">
    <div class="container">
        
        <!-- Header Title -->
        <div class="row mb-4">
            <div class="col-md-12 text-center" data-aos="fade-up">
                <span class="text-uppercase fw-bold" style="color: #0DBEB9; letter-spacing: 2px;">Join Our Family</span>
                <h1 class="fw-bold display-5 mt-2" style="color: #9D74B4;">Admission Procedures</h1>
                <div style="width: 60px; height: 4px; background-color: #9D74B4; margin: 0 auto; border-radius: 2px;" class="mt-3"></div>
            </div>
        </div>

        <div class="row g-md-5 mt-1">
            <div class="col-md-12 ">
                <div class="premium-card">
                    <div class="card-body p-4 p-md-5">
                         <div class="in-cnt-pd" data-aos="fade-up">
                 
                            <!-- PERFECTLY CENTERED PARAGRAPH -->
                            <p class="text-center mb-5 mx-auto d-block" style="color: #64748b; font-size: 1.1rem; max-width: 800px;">
                                Welcome to Bright Beginnings! We are thrilled that you are considering our Montessori program for your child's early education. Please review the simple steps below to join our vibrant learning community.
                            </p>
                    
                            <div class="accordion premium-accordion" id="accordionAdmission">
                              
                              <!-- Admission Process -->
                              <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    1. Admission Process
                                  </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionAdmission">
                                  <div class="accordion-body">
                                     <p>At <strong>Bright Beginnings</strong>, we ensure a smooth, transparent, and welcoming admission process for both you and your child. We accept applications year-round, subject to seat availability.</p>
                                     
                                     <ul class="m-0 p-0 mt-3">
                                         <li><strong>Step 1 – Enquiry & School Tour:</strong> Families are invited to visit our campus, explore our Montessori environment, and meet our team.</li>
                                         <li><strong>Step 2 – Application Submission:</strong> Complete the admission form and submit the required documents.</li>
                                         <li><strong>Step 3 – Child Observation / Meet & Greet:</strong> A short age-appropriate observation session helps us understand your child's readiness and needs.</li>
                                         <li><strong>Step 4 – Admission Confirmation:</strong> Once approved, parents will receive an admission offer along with fee details.</li>
                                         <li><strong>Step 5 – Orientation & First Day Preparation:</strong> Families receive onboarding information to ensure a smooth transition into our environment.</li>
                                     </ul>
                                  </div>
                                </div>
                              </div>
                              
                              <!-- NEW Age Criteria & Programs -->
                              <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    2. Age Criteria & Programs
                                  </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionAdmission">
                                  <div class="accordion-body">
                                     
                                     <!-- Premium Program Layout -->
                                     <div class="row fw-bold pb-2 mb-3 mt-2" style="border-bottom: 2px solid rgba(13, 190, 185, 0.2); color: #1a2b4c; font-size: 1.1rem;">
                                         <div class="col-8">Program</div>
                                         <div class="col-4 text-end">Age</div>
                                     </div>
                                     
                                     <!-- Table Row -->
                                     <div class="row mb-4 align-items-center">
                                         <div class="col-8">
                                             <strong style="color: #9D74B4; font-size: 1.15rem;">Montessori Early Childhood Program</strong>
                                         </div>
                                         <div class="col-4 text-end fw-bold" style="color: #64748b; font-size: 1.05rem;">
                                             2.5 – 6 Years
                                         </div>
                                     </div>
                                     
                                     <!-- Description Paragraph -->
                                     <p class="mb-0 mt-3" style="font-size: 1.05rem;">
                                         Children are placed in a mixed-age Montessori environment where younger children learn through observation and older children develop leadership, responsibility, and confidence.
                                     </p>
                                     
                                  </div>
                                </div>
                              </div>
                              
                              <!-- Required Documents -->
                              <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                   3. Required Documents
                                  </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionAdmission">
                                  <div class="accordion-body">
                                    <ul class="m-0 p-0">
                                         <li>Completed Admission Form</li>
                                         <li>Child's Passport Copy</li>
                                         <li>Child's Iqama / Residency Copy</li>
                                         <li>Parent's Iqama and Passport Copy</li>
                                         <li>Two Passport-size Photographs</li>
                                         <li>Immunization / Vaccination Record</li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>

@include('front.layouts.footer')
