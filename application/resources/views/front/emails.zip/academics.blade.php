@section('title', 'Academics -- indian school - Best International school in Qatar | Doha')
@section('description', 'Explore the academic programs at Noble Indian School in Doha, offering a strong NCERT curriculum, innovative teaching methods, and a focus on student success and growth.')
@section('academics', 'active')
@include('front.layouts.header')


<div class="page-top"></div>
<section class="about section-100 pt-30 ">
  <div class="container">
    <div class="row ">
      <div class="col-md-12">
        <img src="{{ url('upload/' . $academic->banner) }}" class="about-img mb-3 mb-md-5" alt="">
      </div>
    </div>
    <div class="row  g-md-5">
      <div class="col-md-12">
        <div class="in-cnt-pd" data-aos="fade-right">

          <h1 class="pb-2 mt-0 fw-600"> Academics</h1>

          <div class="accordion" id="accordionExample">

            @foreach($academicData as $k => $r)
            <div class="accordion-item">
              <h2 class="accordion-header" id="heading-{{$k}}">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-{{$k}}" aria-expanded="false" aria-controls="collapse-{{$k}}">{{$r->title}}</button>
              </h2>
              <div id="collapse-{{$k}}" class="accordion-collapse collapse" aria-labelledby="heading-{{$k}}" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  {!! $r->description !!}
                </div>
              </div>
            </div>
            @endforeach
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                  The Philosophy
                </button>
              </h2>
              <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <p>Noble aims to provide academic excellence in a caring and structured environment. Each student is considered as an individual and as such we encourage them to understand and develop the uniqueness of their contribution to both school and society. We aim to build self-confidence and give all students a sense of success and morality in their achievement.</p>
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingTwo">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                  The Curriculum
                </button>
              </h2>
              <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                <div class="accordion-body">

                  <p>
                    The school follows the NCERT (National Council of Education, Research and Training) curriculum -
                    <a href="https://ncert.nic.in/syllabus.php?ln=" target="_blank">NCERT Syllabus</a>.</br>
                    NCERT is an autonomous organization under the Government of India that develops syllabi, textbooks, and teaching-learning materials.
                  </p>

                  <b>Kindergarten</b>
                  <p>
                    The students from kindergarten learn English, Mathematics, EVS, and a Second language (Any one language from the following – Arabic, Hindi, Malayalam).
                    Qatar History and Islamic Studies are also taught as compulsory subjects.
                  </p>

                  <b>Grades 1 to 10</b>
                  <p>
                    Students will learn English, Mathematics, Social Science (Grades 6 to 10), and Science/EVS in grades 1 to 10.
                    In addition to that, they also learn any one language from Arabic, French, Hindi, Malayalam, Urdu, and Tamil as a Second Language.</br>
                    The students of grades 4 to 8 have to opt for any one language from the above list as a third language.</br>
                    Qatar History and Islamic Studies are offered as compulsory subjects.</br>
                    Art and Craft, Music, Dance, Physical Education, and Computer Science are also taught as co-curricular subjects.</br>
                    The students will be regrouped by their selected second language and third language for those classes.
                  </p>

                  <b>Grades 11 and 12</b>
                  <p>
                    The students will learn any 5 subjects from a wide range of science or commerce subjects.</br>
                    In addition to that, the Arab National students will learn Arabic as an additional language.</br>
                    The students will also learn Islamic Studies/Value Education.
                  </p>

                  <p>
                    Topics, paragraphs, references, quotations, and diagrams that are against the principles of Islam and the laws of the State of Qatar, if found in the material, will be deleted.
                  </p>
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingThree">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                  Affiliation details
                </button>
              </h2>
              <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <p>Noble International School is affiliated to the Central Board of Secondary Education (CBSE), New Delhi, India.</br>
                    Affiliation Number: 6330010
                  </p>
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header" id="headingFoure">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFoure" aria-expanded="false" aria-controls="collapseFoure">
                  Evaluation Policy
                </button>
              </h2>
              <div id="collapseFoure" class="accordion-collapse collapse" aria-labelledby="headingFoure" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <p>
                    Noble International School runs classes from Grade 1 to Grade 12 and is affiliated to the Central Board of Secondary Education (CBSE), New Delhi, India.
                    The curriculum designed and developed by the National Council of Educational Research and Training, New Delhi ensures quality education to all its students and prepares them to take on the mantle of leadership in the knowledge society.
                    Evaluation at Noble International School focuses on mastery of content and meeting learning targets and content standards set forth by teachers at the beginning of each term.
                  </p></br>
                  <p>
                    The kindergarten follows continuous evaluation through monthly tests and Term-End tests are conducted in October and March.
                  </p></br>
                  <p>
                    For Grades 1 to 12, the curriculum is divided into two terms – Term 1 and Term 2 and the term-end assessment will be conducted at the end of each term (October & March).
                    The periodic tests are conducted in June & January. Frequent class tests are conducted to encourage the children to work continuously.
                  </p></br>
                  <p>
                    The Central Board of Secondary Education (CBSE) conducts and supervises centralized board examinations for Grades 10 and 12 at the end of each academic year.
                  </p></br>
                  <p>
                    The school will amend changes to the policy, if required, to match the guidelines laid by the Central Board of Secondary Education.
                  </p>
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header" id="headingFive">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                  Scholastic area
                </button>
              </h2>
              <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <b>Grades 1 to 8</b>


                  <p>
                    The assessment structure and examination for grades 1 to 8 will comprise two terms as explained below.
                  </p>

                  <h5 class="mt-3">Term 1</h5>


                  <table>
                    <thead>
                      <tr>
                        <th>Assessment Type</th>
                        <th>Marks</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Periodic Test & Multiple Assessment</td>
                        <td>10 marks</td>
                      </tr>
                      <tr>
                        <td>Portfolio</td>
                        <td>5 marks</td>
                      </tr>
                      <tr>
                        <td>Regularity, Assignment Completion, Neatness, and Upkeep of Notebook</td>
                        <td>-</td>
                      </tr>
                      <tr>
                        <td>Subject Enrichment Activity</td>
                        <td>5 marks</td>
                      </tr>
                    </tbody>
                  </table>

                  <div class="table-responsive">
                    <table class="table table-striped mt-3">
                      <thead>
                        <tr>
                          <th scope="col">Subject</th>
                          <th scope="col">Activity</th>

                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Languages</td>
                          <td>Speaking and Listening Skills</td>
                        </tr>
                        <tr>
                          <td>Science</td>
                          <td>Practical Lab work</td>
                        </tr>
                        <tr>
                          <td>Mathematics</td>
                          <td>Mathematical activities</td>
                        </tr>

                        <tr>
                          <td>Social Science</td>
                          <td>Map work and Project work</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <p>Half Yearly Examination<br />
                    The marks allotment for half yearly examination is as given below;</p>

                  <div class="table-responsive">
                    <table class="table table-striped mt-3">
                      <thead>
                        <tr>
                          <th scope="col"></th>
                          <th scope="col">Grades 1 to 6 (max. marks)</th>
                          <th scope="col">Grades 7 to 8 (max. marks)</th>

                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th>Major subjects</th>
                          <td>40</td>
                          <td>80</td>
                        </tr>
                        <tr>
                          <th>Minor subjects</th>
                          <td>20</td>
                          <td>20</td>
                        </tr>

                      </tbody>
                    </table>


                    <b>Compulsory Subjects</b>
                    <p>
                      The examination in Qatar History and Islamic Studies are conducted as per the guidelines issued by MoE&HE

                    </p>
                  </div>
                  <h4 class="mt-3">Term 2</h4>
                  <h4 class="mt-3">Term 2 will have the same assessment pattern</h4>
                  <p>Syllabus coverage for Term 2 will be as below:</p>

                  <div class="table-responsive">
                    <table class="table table-striped mt-3">
                      <thead>
                        <tr>
                          <th scope="col">Grades</th>
                          <th scope="col">Syllabus</th>

                        </tr>
                      </thead>
                      <tbody>
                        <tr>

                          <td>1 to 5</td>
                          <td>Entire syllabus of Term 2</td>
                        </tr>
                        <tr>
                          <td>6</td>
                          <td>10% of Term 1(significant topics) + entire syllabus of Term 2</td>
                        </tr>
                        <tr>
                          <td>7</td>
                          <td>20% of Term 1(significant topics) + entire syllabus of Term 2</td>
                        </tr>

                        <tr>
                          <td>8</td>
                          <td>30% of Term 1(significant topics) + entire syllabus of Term 2</td>
                        </tr>

                      </tbody>
                    </table>

                    <h4 class="mt-3">Co Scholastic Activities</h4>
                    <p>For the holistic development of the student ,co-curricular activities in the following areas be carried out by the teachers and will be graded term-wise on a 3-point grading scale.
                    </p>
                    <ul class="mt-3 p-0 m-0">
                      <li class=""><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg> Work Education</li>
                      <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg> Art Education ( Visual and performing Art)</li>
                      <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg> Health and Physical Education</li>
                      <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg>Discipline (Attendance, Neatness of uniform and Punctuality)
                      </li>
                    </ul>
                    <p>
                      All the students are awarded in Health and Physical Education, Performing and Fine Arts as per the following grades.
                    </p>

                    <table class="table table-striped mt-3">
                      <thead>
                        <tr>
                          <th scope="col">Performance Level</th>
                          <th scope="col">Corresponding Grade</th>

                        </tr>
                      </thead>
                      <tbody>
                        <tr>

                          <td>Excellent</td>
                          <td>A</td>
                        </tr>
                        <tr>
                          <td>Very Good</td>
                          <td>B</td>
                        </tr>
                        <tr>
                          <td>Good</td>
                          <td>C</td>
                        </tr>

                        <tr>
                          <td>Average</td>
                          <td>D</td>
                        </tr>

                        <tr>
                          <td>Below Average</td>
                          <td>E</td>
                        </tr>

                      </tbody>
                    </table>

                    <h4 class="mt-3">Classes 9 and 10</h4>
                    <p>In classes IX and X there will be three periodic written examinations conducted throughout the academic year. The average of the best two exams will be considered for the purpose of gradient learning. These examinations will include one midterm examination and two additional exams, namely pre-midterm and post-midterm examinations. The syllabus for the midterm examination will include the pre-midterm syllabus while the post-midterm syllabus will include both the pre-midterm and midterm syllabus. All three examinations are mandatory. In the event that a student is absent for an exam, there will be no provision for holding the tests at a later date.
                    </P>.<br />
                    <b>Internal assessment will be a part of evaluation for main subjects and will comprise:</b><br />
                    <table>
                      <thead>
                        <tr>
                          <th>Assessment Type</th>
                          <th>Marks</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Periodic Test & Multiple Assessment</td>
                          <td>10 marks</td>
                        </tr>
                        <tr>
                          <td>Portfolio</td>
                          <td>5 marks</td>
                        </tr>
                        <tr>
                          <td>Regularity, Assignment Completion, Neatness, and Upkeep of Notebook</td>
                          <td>-</td>
                        </tr>
                        <tr>
                          <td>Subject Enrichment Activity</td>
                          <td>5 marks</td>
                        </tr>
                      </tbody>
                    </table>
                    </p>

                    <table class="table table-striped mt-3">
                      <thead>
                        <tr>
                          <th scope="col">Subject</th>
                          <th scope="col">Activity</th>

                        </tr>
                      </thead>
                      <tbody>
                        <tr>

                          <td>Languages</td>
                          <td>Speaking and Listening Skills</td>
                        </tr>
                        <tr>
                          <td>Science</td>
                          <td>Practical Lab work</td>
                        </tr>
                        <tr>
                          <td>Mathematics</td>
                          <td>Mathematical activities</td>
                        </tr>

                        <tr>
                          <td>Social Science</td>
                          <td>Map work and Project work</td>
                        </tr>


                      </tbody>
                    </table>

                    <b>Annual Examination(Main subjects) - 80 marks</b><br />
                    At the end of the academic year, the Board will organize the final examination for grade 10. The question paper will be sent by the board with multiple choice questions and case-based/situation-based questions, open-ended answers-type questions, and essay-type questions. The duration of the examination will be 3 hours and it will cover the entire syllabus. For grade 9 the school will conduct the examinations by following the same examination pattern of grade 10.
                    </p>
                    <b>Compulsory Subjects:</b>
                    <p></p>The examinations in Qatar History and Islamic Studies are conducted at the end of each term as per the guidelines issued by MoE&HE.</p>



                    <h4 class="mt-3">Co Scholastic Activities</h4>
                    <p>For the holistic development of the student ,co-curricular activities in the following areas be carried out by the teachers and will be graded term-wise on a 3-point grading scale.
                    </p>

                    <ul class="p-0 m-0">
                      <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg> Work Education</li>
                      <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg> Art Education ( Visual and performing Art)</li>
                      <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg> Health and Physical Education</li>
                      <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg> Discipline (Attendance, Neatness of Uniform and Punctuality)

                      </li>
                    </ul>
                    <p>All the students are awarded in health and physical education, performing and fine arts as per the following grades</p>
                    <table class="table table-striped mt-3">
                      <thead>
                        <tr>
                          <th scope="col">Performance Level</th>
                          <th scope="col">Corresponding Grade</th>

                        </tr>
                      </thead>
                      <tbody>
                        <tr>

                          <td>Excellent</td>
                          <td>A</td>
                        </tr>
                        <tr>
                          <td>Very Good</td>
                          <td>B</td>
                        </tr>
                        <tr>
                          <td>Good</td>
                          <td>C</td>
                        </tr>

                        <tr>
                          <td>Average</td>
                          <td>D</td>
                        </tr>

                        <tr>
                          <td>Below Average</td>
                          <td>E</td>
                        </tr>
                      </tbody>
                    </table>


                    <h4 class="mt-3">Classes 11 and 12</h4>

                    <h5 class="mt-3">SCHOLASTIC AREA</h5>
                    <p>The students of grades 11 and 12 can choose any 5 subjects from the following list.</br>
                      The marks split up for the individual subjects are as follows</p>

                    <table class="table table-striped mt-3">
                      <thead>
                        <tr>
                          <th scope="col">PS. Nol</th>
                          <th scope="col">Subject</th>
                          <th scope="col">Theory
                            (Max. Mark)</th>
                          <th scope="col">Practical/Project/IA
                            (Max. Mark)</th>

                        </tr>
                      </thead>
                      <tbody>
                        <tr>

                          <td>1</td>
                          <td>English, Mathematics, Economics, Business Studies, Accountancy</td>
                          <td>80</td>
                          <td>20</td>
                        </tr>
                        <tr>
                          <td>2</td>
                          <td>Physics, Chemistry, Biology, Informatics Practices</td>
                          <td>70</td>
                          <td>30</td>
                      </tbody>
                    </table>

                    <b>Practical Examination (20/30 marks)</b>
                    <p>
                      The Practical Examinations/Project/Internal Assessments are conducted by the school as per provisions given in the
                      Scheme of Studies/Examination Bye-Laws prescribed by CBSE. These assessments will be conducted by the school itself
                      for grade 11 whereas the CBSE board will conduct the practical assessments and project evaluation by appointing external
                      examiners.
                    </p>

                    <b>Annual Examination (80 marks)</b>
                    <p>
                      At the end of the academic year, the Board will organize the final examination for grade 12. The question paper will
                      be sent by the board as per the pattern provided by the board.
                    </p>

                    <b>Compulsory Subjects:</b>
                    <p>The examinations in Qatar History and Islamic Studies are conducted at the end of each term as per the guidelines issued by MoE&HE.</p>

                    <b>CO-SCHOLASTIC ACTIVITIES</b>
                    <p>For the co-scholastic development of the student, co-curricular activities in the following areas are carried out by the teachers and will be graded on a 5-point grading scale.</p>
                    <ul class="mt-3 p-0 m-0">
                      <li class=""><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg> Work Education</li>
                      <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg> Art Education ( Visual and performing Art)</li>
                      <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg> Health and Physical Education</li>
                      <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                          <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        </svg>Discipline (Attendance, Neatness of uniform and Punctuality)
                      </li>
                    </ul>
                    <p>All the students are awarded in health and physical education, performing and fine arts as per the following grades</p>
                    <table class="table table-striped mt-3">
                      <thead>
                        <tr>
                          <th scope="col">Performance Level</th>
                          <th scope="col">Corresponding Grade</th>

                        </tr>
                      </thead>
                      <tbody>
                        <tr>

                          <td>Excellent</td>
                          <td>A</td>
                        </tr>
                        <tr>
                          <td>Very Good</td>
                          <td>B</td>
                        </tr>
                        <tr>
                          <td>Good</td>
                          <td>C</td>
                        </tr>

                        <tr>
                          <td>Average</td>
                          <td>D</td>
                        </tr>

                        <tr>
                          <td>Below Average</td>
                          <td>E</td>
                        </tr>
                      </tbody>
                    </table>

                  </div>


                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header" id="headingSix">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                  Grading System
                </button>
              </h2>
              <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <div class="table-responsive">
                    <table class="table table-striped mt-3">

                      <tbody>
                        <tr>
                          <th>Marks Range</th>
                          <td>91-100</td>
                          <td>81-90</td>
                          <td>71-80</td>
                          <td>61-70</td>
                          <td>51-60</td>
                          <td>41-50</td>
                          <td>33-40 </td>
                          <td>21-32</td>
                          <td>00-20</td>
                        </tr>

                        <tr>
                          <th>Grade</th>
                          <td>A 1</td>
                          <td>A 2</td>
                          <td>B 1</td>
                          <td>B 2</td>
                          <td>C 1</td>
                          <td>C 2</td>
                          <td>D </td>
                          <td>E 1</td>
                          <td>E 2</td>
                        </tr>


                      </tbody>
                    </table>
                  </div>
                  <p>The performance of a child in scholastic area will be assessed in terms of marks. Marks will be converted into grades as per the following pattern:</p>
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header" id="headingSeven">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                  Attendance
                </button>
              </h2>
              <div id="collapseSeven" class="accordion-collapse collapse" aria-labelledby="headingSeven" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <ul class="p-0 m-0">
                    <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                        <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                      </svg> No pupil shall be eligible for promotion unless he/she puts in an attendance of 80% during an academic year.</li>

                    <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                        <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                      </svg> Every absence must be enlisted in the leave record page of school diary and signed by parent/guardian.</li>
                    <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                        <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                      </svg> Absence for more than three days should be informed to the principal in writing.</li>
                    <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                        <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                      </svg> No leave is granted on examination days, the first and last working days except on medical ground.
                    </li>
                    <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                        <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                      </svg> Leave application on medical ground should be supported by a medical certificate.</li>
                    <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dot" viewBox="0 0 16 16">
                        <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                      </svg> Absence for a period of 15 days or more without submitting a leave note will result in the removal of the pupils name from the rolls.</li>
                  </ul>
                </div>
              </div>
            </div>

          </div>
        </div>


      </div>
      <!--<div class="col-md-4" data-aos="fade-left">-->
      <!--    <div class="imp-list">-->
      <!--        <h6> <img src="{{ asset('Front/images/icons/calendar.svg') }}" class="d-inline me-2 "-->
      <!--                alt=""> Important Date</h6>-->
      <!--        @foreach ($newses as $newse)-->
      <!--            <div class="flex mb-3">-->
      <!--                <div class="ps-3">-->
      <!--                    <img class="star-img " src="{{ asset('Front/images/icons/star.svg') }}" alt="">-->
      <!--                </div>-->
      <!--                <div class="px-3">-->
      <!--                    <h5>{{\Carbon\Carbon::parse($newse->date)->format('d m,Y')}}</h5>-->
      <!--                <p>{{$newse->title}}</p>-->
      <!--                </div>-->
      <!--            </div>-->
      <!--        @endforeach-->
      <!--    </div>-->
      <!--</div>-->
    </div>
  </div>
</section>

@include('front.layouts.footer')