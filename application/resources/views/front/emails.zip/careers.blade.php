@section('title', 'Careers - indian school - Best International school in Qatar | Doha')
@section('description', 'Join the Noble Indian School team in Doha! Explore exciting career opportunities at one of the best international schools, dedicated to academic excellence and growth.')
@section('career', 'active')
@include('front.layouts.header')
<style>
    /* Page Specific Styles */
    .career-page {
        font-family: 'Nunito', sans-serif;
        color: #1a2b4c;
        background-color: #ffffff;
    }

    /* ==========================================
       HERO BANNER (CENTERED HEADING) 
       ========================================== */
    .career-banner {
        position: relative;
        width: 100%;
        height: 450px; 
        margin: 0;
        padding: 0;
        display: block;
    }

    .banner-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.4); 
    }

    .banner-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 10;
        text-align: center;
        width: 100%;
    }

    .main-title {
        font-family: 'Georgia', serif; 
        color: #ffffff;
        font-size: 3rem; /* Decreased font size */
        font-weight: 700;
        margin: 0;
        text-transform: capitalize;
        text-shadow: 2px 2px 10px rgba(0,0,0,0.4);
    }

    /* ==========================================
       VACANCIES SECTION
       ========================================== */
    .career-content-section {
        padding: 6rem 0; 
        background-color: #ffffff;
    }

    /* Vacancy Cards */
    .vacancy-card {
        background: #fff;
        border-radius: 15px;
        border: 1px solid #E2E8F0;
        padding: 2.5rem; 
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        height: 100%;
    }

    .vacancy-card:hover {
        box-shadow: 0 15px 35px rgba(0,0,0,0.05);
        transform: translateY(-5px);
        border-color: #9D74B4;
    }

    .vacancy-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
        background: linear-gradient(180deg, #9D74B4, #0DBEB9);
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .vacancy-card:hover::before {
        opacity: 1;
    }

    .job-title {
        font-size: 1.4rem; 
        font-weight: 800;
        color: #1a2b4c;
        margin-bottom: 0.5rem;
    }

    .job-meta {
        display: flex;
        gap: 15px;
        margin-bottom: 1.2rem;
        font-size: 0.9rem;
        color: #64748B;
        font-weight: 600;
        flex-wrap: wrap;
    }

    .job-meta span {
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .job-desc {
        color: #475569;
        font-size: 1.05rem;
        line-height: 1.6;
        margin-bottom: 1.5rem;
        flex-grow: 1;
    }

    .btn-apply {
        display: inline-block;
        background: transparent;
        color: #9D74B4;
        border: 2px solid #9D74B4;
        padding: 10px 25px; 
        border-radius: 50px;
        font-weight: 700;
        text-decoration: none;
        transition: all 0.3s ease;
        text-align: center;
        font-size: 1rem;
    }

    .vacancy-card:hover .btn-apply {
        background: #9D74B4;
        color: #fff;
    }

    /* Empty State (Matched to Reference Box Size) */
    .empty-state {
        background-color: #ffffff;
        border: 1px dashed #cbd5e1;
        border-radius: 24px;
        padding: 3rem; 
        width: 100%;
        margin: 0 auto;
        box-shadow: 0 10px 40px rgba(0,0,0,0.03);
    }

    .empty-state-img {
        width: 100%;
        height: 100%;
        min-height: 260px;
        object-fit: cover;
        border-radius: 16px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.06);
    }

    .empty-state-title {
        color: #9D74B4; 
        font-weight: 800;
        font-size: 1.8rem; /* Matched the size of your reference image */
        margin-bottom: 1.2rem;
        line-height: 1.4;
    }

    .empty-state-text {
        color: #64748B;
        font-size: 1.15rem; 
        line-height: 1.8;
    }

    /* Responsive adjustments */
    @media (max-width: 991px) {
        .career-banner { height: 300px; }
        .main-title { font-size: 1.8rem; } /* Decreased mobile font size */
        .career-content-section { padding: 4rem 0; }
        .empty-state { padding: 2.5rem; }
    }
</style>

<div class="career-page">
    
    <!-- Hero Banner (Image & Centered Heading) -->
    <section class="career-banner" style="background: url('{{ asset('Front/images/brightban.jpg') }}') center top / cover no-repeat;">
        <div class="banner-overlay"></div>
        <div class="banner-text">
            <h1 class="main-title">Careers</h1>
        </div>
    </section>

    <!-- Vacancies Section (Centered) -->
    <section class="career-content-section">
        <div class="container">
            <div class="row justify-content-center">
                
                <!-- Perfectly sized container to match the reference box -->
                <div class="col-lg-10">
                    
                    @if(isset($vacancies) && count($vacancies) > 0)
                        <h2 class="fw-bold mb-4 text-center" style="color: #1a2b4c;">Current Openings</h2>
                        
                        <!-- Active Vacancies -->
                        <div class="row g-4">
                            @foreach($vacancies as $vacancy)
                                <div class="col-12">
                                    <div class="vacancy-card">
                                        <h3 class="job-title">{{ $vacancy->title }}</h3>
                                        <div class="job-meta">
                                            <span>
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                                                {{ $vacancy->location }}
                                            </span>
                                            <span>
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                                                {{ $vacancy->job_type }}
                                            </span>
                                        </div>
                                        <p class="job-desc">
                                            {{ Str::limit($vacancy->description, 120) }}
                                        </p>
                                        <div class="mt-auto pt-3">
                                            <a href="{{ route('career.apply', $vacancy->id) }}" class="btn-apply">Apply Now</a>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        
                    @else
                        <!-- No Openings State -->
                        <div class="empty-state">
                            <div class="row align-items-center text-center text-md-start">
                                <!-- Left Side: Image (Proportioned to match reference) -->
                                <div class="col-md-5 mb-4 mb-md-0">
                                    <img src="{{ asset('Front/images/lege.jpg') }}" class="empty-state-img" alt="Careers">
                                </div>
                                
                                <!-- Right Side: Content -->
                                <div class="col-md-7 ps-md-5">
                                    <h3 class="empty-state-title">No new openings at Bright Beginnings now.</h3>
                                    <p class="empty-state-text mb-0">
                                        We are not actively hiring at the moment. However, we are always happy to connect with passionate educators! Feel free to send your resume to us for future opportunities.
                                    </p>
                                </div>
                            </div>
                        </div>
                    @endif

                </div>

            </div>
        </div>
    </section>

</div>

@include('front.layouts.footer')
