@section('title', 'Careers - indian school - Best International school in Qatar | Doha')
@section('description', 'Join the Noble Indian School team in Doha! Explore exciting career opportunities at one of the best international schools, dedicated to academic excellence and growth.')
@section('career', 'active')
@include('front.layouts.header')

<style>
    /* Page Specific Styles */
    .why-choose-page {
        font-family: 'Nunito', sans-serif;
        color: #1a2b4c;
        background-color: #ffffff;
    }

    /* ==========================================
       NEW HERO BANNER (CENTERED HEADING) 
       ========================================== */
    .why-banner {
        position: relative;
        width: 100vw;
        margin-left: calc(-50vw + 50%);
        max-width: 100vw;
        height: 450px; 
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        background-attachment: fixed;
    }

    .banner-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.4); 
        z-index: 1;
    }

    .banner-text {
        position: relative;
        z-index: 2;
        text-align: center;
        width: 100%;
    }

    .banner-title {
        font-family: 'Georgia', serif; 
        color: #ffffff;
        font-size: 3rem; /* Decreased font size */
        font-weight: 700;
        margin: 0;
        text-transform: capitalize;
        text-shadow: 2px 2px 10px rgba(0,0,0,0.4);
    }

    @media (max-width: 768px) {
        .banner-title {
            font-size: 1.8rem; /* Decreased font size for mobile */
        }
        .why-banner {
            height: 300px;
        }
    }

    /* ========================================== */

    .hero-section {
        padding: 3rem 0 2rem; 
        background: #fdfdfc;
    }

    .subtitle-label {
        color: #9D74B4;
        font-weight: 700;
        letter-spacing: 2px;
        text-transform: uppercase;
        font-size: 0.9rem;
        margin-bottom: 1rem;
        display: block;
    }

    .lead-text {
        font-size: 1.5rem;
        font-weight: 800;
        color: #1a2b4c;
        line-height: 1.6;
    }

    .body-text {
        font-size: 1.15rem;
        line-height: 1.8;
        color: #475569;
        margin-bottom: 1.5rem;
    }

    /* Highlight Quote Box */
    .highlight-quote {
        background: rgba(157, 116, 180, 0.05);
        border-left: 5px solid #9D74B4;
        padding: 2.5rem;
        border-radius: 0 20px 20px 0;
        margin: 1.5rem auto;  
        max-width: 800px; 
        box-shadow: 0 10px 30px rgba(0,0,0,0.02);
    }

    /* Features Grid Section Settings */
    .features-section {
        position: relative; /* For floating icons */
        overflow: hidden;   /* For floating icons */
        padding: 0 0 5rem; 
        background: #fdfdfc;
    }

    /* Ensure content is above floating icons */
    .features-section .container {
        position: relative;
        z-index: 2; 
    }

    /* Floating Decor Animation */
    .floating-icon {
        position: absolute;
        z-index: 0;
        opacity: 0.9;
        pointer-events: none; 
        animation: floatAnim 6s ease-in-out infinite;
    }

    .floating-icon.sun {
        top: 5%;
        left: -3%;
        width: 140px;
        height: 140px;
    }

    .floating-icon.star {
        bottom: 15%;
        left: 5%;
        width: 80px;
        height: 80px;
        animation-delay: 1.5s; 
    }

    .floating-icon.flask {
        top: 40%;
        right: -2%;
        width: 110px;
        height: 110px;
        animation-delay: 3s; 
    }

    @keyframes floatAnim {
        0% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(-20px) rotate(5deg); }
        100% { transform: translateY(0px) rotate(0deg); }
    }

    .features-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 2rem; 
        margin-top: 1.5rem;
    }

    /* Card styling for each feature item */
    .features-item {
        background: #fff;
        border-radius: 20px;
        padding: 1.5rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.04);
        transition: all 0.3s ease;
        display: flex;
        flex-direction: column;
    }

    .features-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(0,0,0,0.08);
    }

    /* Top image inside the card */
    .features-image {
        width: 100%;
        height: 220px;
        object-fit: cover;
        border-radius: 12px;
        margin-bottom: 1.5rem;
    }

    .features-content {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
    }

    .features-title {
        font-weight: 800;
        font-size: 1.25rem;
        margin-bottom: 1rem;
        color: #1a2b4c;
    }

    /* ==========================================
       FINAL QUOTES SECTION (SPLIT BOX LAYOUT)
       ========================================== */
    .final-quotes-section {
        padding: 5rem 0 7rem;
        background: #ffffff; 
        border-top: 1px solid #f0f0f0;
    }

    .enroll-box {
        background: linear-gradient(135deg, rgba(157, 116, 180, 0.05) 0%, rgba(255, 255, 255, 1) 100%);
        border: 1px solid rgba(157, 116, 180, 0.15);
        border-radius: 24px;
        padding: 4rem;
        box-shadow: 0 15px 40px rgba(0,0,0,0.04);
    }

    .enroll-image {
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        width: 100%;
        height: 350px;
        object-fit: cover;
    }

    .enroll-btn {
        display: inline-block;
        background: linear-gradient(90deg, #8F65B8, #7445A5);
        color: #fff;
        padding: 14px 45px;
        border-radius: 50px;
        font-weight: 700;
        font-size: 1.2rem;
        text-decoration: none;
        box-shadow: 0 8px 20px rgba(116, 69, 165, 0.3);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .enroll-btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 12px 25px rgba(116, 69, 165, 0.4);
        color: #fff;
    }

    /* Responsive Grid */
    @media (max-width: 992px) {
        .features-grid {
            grid-template-columns: repeat(2, 1fr);
        }
        .enroll-box {
            padding: 2.5rem;
        }
        .enroll-image {
            height: 250px;
        }
    }

    @media (max-width: 768px) {
        .features-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="why-choose-page">
    
    <!-- NEW HERO BANNER (Full Width with Centered Text) -->
    <section class="why-banner" style="background: url('{{ asset('Front/images/brightban.jpg') }}') center top / cover no-repeat;">
        <div class="banner-overlay"></div>
        <div class="banner-text">
            <h1 class="banner-title">Why Choose Us?</h1>
        </div>
    </section>

    <!-- Introduction Section -->
    <section class="hero-section text-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <span class="subtitle-label">Discover Bright Beginnings</span>
                    
                    <div class="highlight-quote text-start">
                        <h4 class="fst-italic mb-0" style="color: #1a2b4c; line-height: 1.6; font-weight: 700;">
                            “Education is a natural process carried out by the child and is not acquired by listening to words but by experiences in the environment” 
                        </h4>
                        <p class="fw-bold text-uppercase mt-4 mb-0" style="letter-spacing: 1px; color: #9D74B4;">– Dr. Maria Montessori</p>
                    </div>

                    <!-- Changed mt-5 to mt-4 to reduce the gap -->
                    <div class="lead-text mt-4 mb-0 text-center">
                        Bright Beginnings Montessori <br>
                        <span style="color: #9D74B4;">Where Curiosity Is the Curriculum</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Grid Section -->
    <section class="features-section">

        <!-- DECORATIVE FLOATING ICONS (Custom Hand-Drawn Style SVGs) -->
        
        <!-- SUN ICON -->
        <div class="floating-icon sun">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
                <!-- Sun fill -->
                <circle cx="50" cy="50" r="28" fill="#FDE047"/>
                <!-- Rays -->
                <path d="M50 8 L50 16 M50 84 L50 92 M8 50 L16 50 M84 50 L92 50 M20 20 L26 26 M74 74 L80 80 M20 80 L26 74 M74 20 L80 26" stroke="#FDE047" stroke-width="4" stroke-linecap="round"/>
                <!-- Eyes -->
                <circle cx="40" cy="45" r="2.5" fill="#4B5563"/>
                <circle cx="60" cy="45" r="2.5" fill="#4B5563"/>
                <!-- Smile -->
                <path d="M45 53 Q50 58 55 53" stroke="#4B5563" stroke-width="2.5" stroke-linecap="round" fill="none"/>
                <!-- Cheeks -->
                <circle cx="33" cy="50" r="3.5" fill="#FDA4AF" opacity="0.8"/>
                <circle cx="67" cy="50" r="3.5" fill="#FDA4AF" opacity="0.8"/>
            </svg>
        </div>

        <!-- STAR ICON -->
        <div class="floating-icon star">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
                <!-- Offset yellow fill -->
                <path d="M50 15 L61 38 L88 38 L66 54 L74 80 L50 64 L26 80 L34 54 L12 38 L39 38 Z" fill="#FEF08A" transform="translate(6, 6)"/>
                <!-- Grey outline -->
                <path d="M50 12 L63 39 L92 37 L68 56 L78 85 L50 66 L22 85 L32 56 L8 37 L37 39 Z" stroke="#6B7280" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"/>
            </svg>
        </div>

        <!-- FLASK ICON -->
        <div class="floating-icon flask">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
                <!-- Offset blue fill -->
                <path d="M40 20 L40 45 L20 80 Q15 90 25 90 L75 90 Q85 90 80 80 L60 45 L60 20 Z" fill="#BAE6FD" transform="translate(-4, 4)"/>
                <!-- Grey outline -->
                <path d="M35 15 L65 15 M40 15 L40 45 L20 80 Q15 88 25 88 L75 88 Q85 88 80 80 L60 45 L60 15" stroke="#6B7280" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"/>
                <!-- Liquid curve inside -->
                <path d="M22 75 Q50 82 78 75" stroke="#6B7280" stroke-width="4" stroke-linecap="round"/>
                <!-- Measurement marks -->
                <line x1="40" y1="25" x2="48" y2="25" stroke="#6B7280" stroke-width="3" stroke-linecap="round"/>
                <line x1="40" y1="33" x2="48" y2="33" stroke="#6B7280" stroke-width="3" stroke-linecap="round"/>
                <line x1="40" y1="41" x2="48" y2="41" stroke="#6B7280" stroke-width="3" stroke-linecap="round"/>
            </svg>
        </div>

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    
                    <div class="features-grid">
                        
                        <!-- Feature 1 -->
                        <div class="features-item">
                            <img src="{{ asset('Front/images/authentic.jpeg') }}" alt="Authentic AMI-Approved Materials" class="features-image">
                            <div class="features-content">
                                <h3 class="features-title">Authentic AMI-Approved Materials</h3>
                                <p class="body-text mb-0" style="font-size: 1.05rem;">
                                    Purposeful, hands-on materials designed by Maria Montessori to foster independence, concentration, and deep understanding.
                                </p>
                            </div>
                        </div>

                        <!-- Feature 2 -->
                        <div class="features-item">
                            <img src="{{ asset('Front/images/brightthread.jpeg') }}" alt="The Bright Thread Philosophy" class="features-image">
                            <div class="features-content">
                                <h3 class="features-title">The Bright Thread Philosophy</h3>
                                <p class="body-text mb-0" style="font-size: 1.05rem;">
                                    Every child follows a unique learning journey, guided according to their interests, strengths, and developmental readiness.
                                </p>
                            </div>
                        </div>

                        <!-- Feature 3 -->
                        <div class="features-item">
                            <img src="{{ asset('Front/images/readwrite.jpeg') }}" alt="Read Write Inc Phonics" class="features-image">
                            <div class="features-content">
                                <h3 class="features-title">Read Write Inc Phonics</h3>
                                <p class="body-text mb-0" style="font-size: 1.05rem;">
                                    A structured and engaging literacy programme from the UK that builds confident readers, writers, and communicators.
                                </p>
                            </div>
                        </div>

                        <!-- Feature 4 -->
                        <div class="features-item">
                            <img src="{{ asset('Front/images/joyful.jpeg') }}" alt="Warm, Joyful Prepared Environment" class="features-image">
                            <div class="features-content">
                                <h3 class="features-title">Warm, Joyful Prepared Environment</h3>
                                <p class="body-text mb-0" style="font-size: 1.05rem;">
                                    Beautiful, purposeful spaces where children feel safe, respected, and inspired to learn.
                                </p>
                            </div>
                        </div>

                        <!-- Feature 5 -->
                        <div class="features-item">
                            <img src="{{ asset('Front/images/based.jpeg') }}" alt="Inquiry-Based Discovery" class="features-image">
                            <div class="features-content">
                                <h3 class="features-title">Inquiry-Based Discovery</h3>
                                <p class="body-text mb-0" style="font-size: 1.05rem;">
                                    We encourage children to ask questions, investigate ideas, and develop a genuine curiosity about the world.
                                </p>
                            </div>
                        </div>

                        <!-- Feature 6 -->
                        <div class="features-item">
                            <img src="{{ asset('Front/images/handson.jpeg') }}" alt="Hands-On, Not Screen-On" class="features-image">
                            <div class="features-content">
                                <h3 class="features-title">Hands-On, Not Screen-On</h3>
                                <p class="body-text mb-0" style="font-size: 1.05rem;">
                                    Young children learn best through real experiences, movement, exploration, and meaningful interactions.
                                </p>
                            </div>
                        </div>

                        <!-- Feature 7 -->
                        <div class="features-item">
                            <img src="{{ asset('Front/images/highattention.jpeg') }}" alt="Low Ratios, High Attention" class="features-image">
                            <div class="features-content">
                                <h3 class="features-title">Low Ratios, High Attention</h3>
                                <p class="body-text mb-0" style="font-size: 1.05rem;">
                                    Smaller guide-child ratios allow our Montessori Guides to truly know, support, and nurture each child.
                                </p>
                            </div>
                        </div>

                        <!-- Feature 8 -->
                        <div class="features-item">
                            <img src="{{ asset('Front/images/wearegui.jpeg') }}" alt="We're Guides, Not Teachers" class="features-image">
                            <div class="features-content">
                                <h3 class="features-title">We're Guides, Not Teachers</h3>
                                <p class="body-text mb-0" style="font-size: 1.05rem;">
                                    Our Montessori Guides observe, facilitate, and empower children to become confident, independent learners.
                                </p>
                            </div>
                        </div>

                        <!-- Feature 9 -->
                        <div class="features-item">
                            <img src="{{ asset('Front/images/outdoor.jpeg') }}" alt="Outdoor learning & Nature play" class="features-image">
                            <div class="features-content">
                                <h3 class="features-title">Outdoor learning & Nature play</h3>
                                <p class="body-text mb-0" style="font-size: 1.05rem;">
                                    Daily outdoor experiences promote physical development, creativity, resilience, and a connection with nature.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Final Quotes Section (Now a Split Layout Box) -->
    <section class="final-quotes-section">
        <div class="container">
            <div class="enroll-box">
                <div class="row align-items-center">
                    
                    <!-- Left Side: Image -->
                    <div class="col-lg-5 mb-4 mb-lg-0">
                        <img src="{{ asset('Front/images/lege.jpg') }}" alt="Enrollment" class="enroll-image">
                    </div>

                    <!-- Right Side: Content -->
                    <div class="col-lg-7 px-lg-5 text-start">
                        <h3 class="fw-bold mb-4" style="color: #9D74B4; line-height: 1.5; font-size: 2.2rem;">
                            "Your child's story is waiting to be written. Let's write the first page together."
                        </h3>
                        
                        <!-- Small teal divider line -->
                        <div style="width: 60px; height: 3px; background: #0DBEB9; margin-bottom: 2.5rem; border-radius: 2px;"></div>

                        <a href="{{ route('admission') }}" class="enroll-btn">
                            Enroll Now
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </section>

</div>

@include('front.layouts.footer')
